# =======================================
# DISASTROUS DEFAULTS
# =======================================
# Christian Gouriéroux, Alain Monfort,
# Jean-Paul Renne and Sarah Mouabbi
# Contact: jean-paul.renne@unil.ch
# =======================================
# This script contains procedures
# aimed at solving for the macro-model.
# =======================================




run.solve.model <- function(Model,
                            nb.iter=100,
                            print.sol.quality=1,
                            dampen.factor=.7){
  Model.solved <- Model
  
  Mu.c <- Model$Mu.c
  
  Mu.u.vector <- .0001*c(1/(1-delta)*Mu.c$A,
                         1/(1-delta)*Mu.c$B,
                         1/(1-delta)*Mu.c$C)
  
  Mu.u.i <- Mu.u.vector
  
  for(j in 1:nb.iter){
    grad.f <- grad.f.2.solve(Mu.u.i,Model)
    #Mu.u.i <- Mu.u.i - .4*solve(grad.f) %*% f.2.solve(Mu.u.i,Model)
    if(sum(is.na(grad.f))>0){
      Mu.u.i <- Mu.u.i
    }else{
      Mu.u.i <- Mu.u.i - dampen.factor*ginv(grad.f) %*% f.2.solve(Mu.u.i,Model)
    }
  }
  min.fun2min.4.sdf <- f.2.minimize(Mu.u.i,Model)
  Model.solved$min.fun2min.4.sdf <- min.fun2min.4.sdf
  
  if(print.sol.quality==1){
    print("=================================")
    print("Solving for s.d.f.")
    print(paste("Intial value of function: ",toString(f.2.minimize(Mu.u.vector,Model))))
    print(paste("Minimized function: ",toString(min.fun2min.4.sdf)))
    print("=================================")
  }
  
  # Prices of risk:
  Model.solved$Delta <- list(
    A = - Mu.c$A + (1 - Model$gamma)*Mu.u.i[1:n.F],
    B = - Mu.c$B + (1 - Model$gamma)*Mu.u.i[(n.F+1):(n.F+J)],
    C = - Mu.c$C + (1 - Model$gamma)*Mu.u.i[(n.F+J+1):(n.F+2*J)]
  )
  
  # Specification of the s.d.f.:
  # First, compute the LT of (1-gamma).mu.u.1:
  LT.aux <- ABCD(list(
    A = (1 - Model$gamma)*Mu.u.i[1:n.F],
    B = (1 - Model$gamma)*Mu.u.i[(n.F+1):(n.F+J)],
    C = (1 - Model$gamma)*Mu.u.i[(n.F+J+1):(n.F+2*J)]),Model)
  # Second, compute mu.m.0:
  mu.m.0 <- log(Model$delta) - Mu.c$D - LT.aux$D
  # Third, compute mu.m.1:
  mu.m.1 <- Model.solved$Delta
  # Fourth, cimpute mu.m.2:
  mu.m.2 <- list(
    A = - LT.aux$A,
    B = - LT.aux$B,
    C = - LT.aux$C
  )
  
  Model.solved$mu.m.0 <- mu.m.0
  Model.solved$mu.m.1 <- mu.m.1
  Model.solved$mu.m.2 <- mu.m.2
  
  # Resulting specification of the risk-free short-term rate:
  # Preliminary step: compute the LT of the prices of risk:
  LT.aux <- ABCD(mu.m.1,Model)
  Model.solved$Eta <- list(
    A = - LT.aux$A - mu.m.2$A,
    B = - LT.aux$B - mu.m.2$B,
    C = - LT.aux$C - mu.m.2$C,
    D = - LT.aux$D - mu.m.0 + (1 - Model$gamma)*(1 - Model$delta)*Model$sigma.c^2
  )
  
  moments <- compute.moments(Model)
  
  
  if(!is.null(Model$Mu.d)){
    # ========================================
    # Solve for equity index prices

    z.bar.i <- Model$z.bar
    eps.z <- .00000001
    
    A.1.vector.ini <- .001*c(1/(1-delta)*Mu.c$A,
                             1/(1-delta)*Mu.c$B,
                             1/(1-delta)*Mu.c$C)
    
    for(nb.iter.z in 1:3){
      
      for(CASE in c("baseline","disturbed")){
        if(CASE == "baseline"){
          z.bar <- z.bar.i
        }else{
          z.bar <- z.bar.i + eps.z
        }
        Model.solved$z.bar <- z.bar
        
        A.1.i <- A.1.vector.ini
        
        for(j in 1:nb.iter){
          grad.f <- grad.f.2.solve.4equity(A.1.i,Model.solved)
          if(sum(is.na(grad.f))>0){
          }else{
            A.1.i <- A.1.i - dampen.factor*ginv(grad.f) %*% f.2.solve.4equity(A.1.i,Model.solved)
          }
        }
        
        Model.solved$A.1 <- list(
          A = matrix(A.1.i[1:n.F],ncol=1),
          B = matrix(A.1.i[(n.F+1):(n.F+J)],ncol=1),
          C = matrix(A.1.i[(n.F+J+1):(n.F+2*J)],ncol=1)
        )
        
        # Now solve for A.0:
        kappa.1 <- c(exp(z.bar)/(1 + exp(z.bar)))
        kappa.0 <- c(log(1 + exp(z.bar)) - kappa.1*z.bar)
        
        aux.1 <- ABCD(list(
          A = kappa.1 * Model.solved$A.1$A + Model.solved$Mu.d$A + Model.solved$Delta$A,
          B = kappa.1 * Model.solved$A.1$B + Model.solved$Mu.d$B + Model.solved$Delta$B,
          C = kappa.1 * Model.solved$A.1$C + Model.solved$Mu.d$C + Model.solved$Delta$C
        ),Model.solved)
        
        aux.2 <- ABCD(Model.solved$Delta,Model.solved)
        
        Model.solved$A.0 <- 1/(kappa.1 - 1)*(
          -kappa.0 - Model.solved$Mu.d$D + Model.solved$Eta$D + aux.2$D - aux.1$D
        )
        
        z.bar.bar <- Model.solved$A.0 + t(moments$unc.mean) %*%
          rbind(Model.solved$A.1$A,Model.solved$A.1$B)
        
        f <- z.bar - z.bar.bar
        if(CASE == "baseline"){
          f0 <- f
        }else{
          f1 <- f
        }
      }
      
      df <- (f1 - f0)/eps.z
      z.bar.i <- z.bar.i - f0/df
      if(print.sol.quality==1){
        print(paste("z.bar.i = ",toString(z.bar.i)," (z.bar.bar.i = ",toString(z.bar.bar),")"))
      }
    }
    
    min.fun2min.4.r_s <- f.2.minimize.4equity(A.1.i,Model.solved)
    
    if(print.sol.quality==1){
      print("=================================")
      print("Solving for equity returns")
      print(paste("Intial value of function: ",
                  toString(f.2.minimize.4equity(A.1.vector.ini,Model.solved))))
      print(paste("Minimized function: ",toString(min.fun2min.4.r_s)))
      print("=================================")
    }
    
    Model.solved$z.bar.bar <- z.bar.bar
    Model.solved$z.bar <- z.bar.i
    
    Model.solved$kappa.0 <- kappa.0
    Model.solved$kappa.1 <- kappa.1
    
    Model.solved$min.fun2min.4.r_s <- min.fun2min.4.r_s
    
  }
  
  
  return(Model.solved)
}



# ==========================================
# Function used to solve for s.d.f

f.2.solve <- function(Mu.u.vector,Model){
  # Specification of Delta(u_t):
  # Du_t = A' F_t + B' N_t + C' N_{t-1} + 
  #        A_1' F_{t-1} + B_1' N_{t-1} + C_1' N_{t-2} + 
  
  gamma <- Model$gamma # risk aversion
  delta <- Model$delta # rate of preference for present
  Mu.c  <- Model$Mu.c
  
  J <- dim(Model$c.matrix)[1] # Number of segments
  n.F <- dim(Model$beta.matrix)[1] # number of Factors (dimension of F)
  
  Mu.u <- list(
    A = matrix(Mu.u.vector[1:n.F],ncol=1),
    B = matrix(Mu.u.vector[(n.F+1):(n.F+J)],ncol=1),
    C = matrix(Mu.u.vector[(n.F+J+1):(n.F+2*J)],ncol=1)
  )
  aux <- ABCD(list(
    A = (1-gamma)*Mu.u$A,
    B = (1-gamma)*Mu.u$B,
    C = (1-gamma)*Mu.u$C
  ),Model)
  f.vector <- c(
    delta/(1 - gamma)/(1 - delta)*aux$A + 1/(1 - delta)*(Mu.c$A - Mu.u$A),
    delta/(1 - gamma)/(1 - delta)*aux$B + 1/(1 - delta)*(Mu.c$B - Mu.u$B),
    delta/(1 - gamma)/(1 - delta)*aux$C + 1/(1 - delta)*(Mu.c$C - Mu.u$C)
  )
  return(f.vector)
}

f.2.minimize <- function(Mu.u.vector,Model){
  f.vect <- f.2.solve(Mu.u.vector,Model)
  return(sum((100000*f.vect)^2))
}

grad.f.2.solve <- function(Mu.u.vector,Model,eps=1e-10){
  n.u <- length(Mu.u.vector)
  f.0 <- f.2.solve(Mu.u.vector,Model)
  grad.f <- NULL
  for(i in 1:n.u){
    Mu.u.disturb <- Mu.u.vector
    Mu.u.disturb[i] <- Mu.u.disturb[i] + eps
    f.1 <- f.2.solve(Mu.u.disturb,Model)
    grad.f <- cbind(grad.f,(f.1 - f.0)/eps)
  }
  return(grad.f)
}



# ==========================================
# Function used to solve for equity price

f.2.solve.4equity <- function(A.1.vector,Model){
  # Specification of Delta(u_t):
  # Du_t = A' F_t + B' N_t + C' N_{t-1} + 
  #        A_1' F_{t-1} + B_1' N_{t-1} + C_1' N_{t-2} + 
  
  gamma <- Model$gamma # risk aversion
  delta <- Model$delta # rate of preference for present
  Mu.c  <- Model$Mu.c
  
  z.bar <- Model$z.bar
  kappa.1 <- c(exp(z.bar)/(1 + exp(z.bar)))
  kappa.0 <- c(log(1 + exp(z.bar)) - kappa.1*z.bar)
  
  J <- dim(Model$c.matrix)[1] # Number of segments
  n.F <- dim(Model$beta.matrix)[1] # number of Factors (dimension of F)
  
  A.1 <- list(
    A = matrix(A.1.vector[1:n.F],ncol=1),
    B = matrix(A.1.vector[(n.F+1):(n.F+J)],ncol=1),
    C = matrix(A.1.vector[(n.F+J+1):(n.F+2*J)],ncol=1)
  )
  
  aux.1 <- ABCD(list(
    A = kappa.1 * A.1$A + Model$Mu.d$A + Model$Delta$A,
    B = kappa.1 * A.1$B + Model$Mu.d$B + Model$Delta$B,
    C = kappa.1 * A.1$C + Model$Mu.d$C + Model$Delta$C
  ),Model)
  aux.2 <- ABCD(Model$Delta,Model)
  
  f.vector <- c(
    aux.1$A - (A.1$A + Model$Eta$A + aux.2$A),
    aux.1$B - (A.1$B + Model$Eta$B + aux.2$B),
    aux.1$C - (A.1$C + Model$Eta$C + aux.2$C)
  )
  return(f.vector)
}

f.2.minimize.4equity <- function(A.1.vector,Model){
  f.vect <- f.2.solve.4equity(A.1.vector,Model)
  return(sum((100000000*f.vect)^2))
}

grad.f.2.solve.4equity <- function(A.1.vector,Model,eps=1e-10){
  n.u <- length(A.1.vector)
  f.0 <- f.2.solve.4equity(A.1.vector,Model)
  grad.f <- NULL
  for(i in 1:n.u){
    A.1.disturb <- A.1.vector
    A.1.disturb[i] <- A.1.disturb[i] + eps
    f.1 <- f.2.solve.4equity(A.1.disturb,Model)
    grad.f <- cbind(grad.f,(f.1 - f.0)/eps)
  }
  return(grad.f)
}



simul.Model.with.prices <- function(Model,
                                    targets,
                                    nb.sim,
                                    mult.fact = 2,
                                    max.H = 10){
  # max.H is expressed in years: maturity of plotted CDS.
  
  J <- dim(Model$c.matrix)[1]
  
  par(mfrow=c(4,2))
  par(plt=c(.1,.9,.1,.8))
  
  res.simul <- simul.Model(Model,nb.sim)
  
  plot(res.simul$F[,J+2],type="l",
       main="F1 (red) and F2 (black)")
  lines(res.simul$F[,J+1],col="red")
  
  plot(res.simul$F[,1],type="l",col="black",ylim=c(0,max(res.simul$F[,1:J])),
       main="Z factors")
  for(i in 1:J){
    lines(res.simul$F[,i],col=i)
  }
  #lines(res.simul$F[,3],col="red",lty=2)
  
  plot(res.simul$N[,1],type="l",col="black",ylim=c(0,max(res.simul$N)),
       main="N factors")
  for(i in 1:J){
    lines(res.simul$N[,i],col=i)
  }
  
  X <- list(F=res.simul$F,N=res.simul$N,N_1=res.simul$N_1)
  X$N   <- 0 * X$N
  X$N_1 <- 0 * X$N_1
  
  delta.c.simul <- (res.simul$F) %*% Model$Mu.c$A +
    (res.simul$N) %*% Model$Mu.c$B +
    (res.simul$N_1) %*% Model$Mu.c$C + Model$Mu.c$D
  plot(delta.c.simul,type="l")
  par(new=TRUE)
  plot(cumsum(delta.c.simul),type="l",xaxt="n",yaxt="n",col="red",
       main="Consumption")
  #lines(1:nb.sim,Mu.c$D*(1:nb.sim),col="red")
  abline(h=0,lty=3)
  
  
  # Select maturities:
  H <- matrix(c(1,4,10),ncol=1)
  
  # Compute risk-free bond prices and yields:
  RF.bonds <- Price.RF.bonds(Model,H,X)
  
  # Specification of the growth rate of dividends:
  Model$Mu.d  <- list(
    A = mult.fact*Model$Mu.c$A,
    B = mult.fact*Model$Mu.c$B,
    C = mult.fact*Model$Mu.c$C,
    D = Model$Mu.c$D
  )
  
  Model <- run.solve.model(Model)
  
  # Compute average of returns:
  moments <- compute.moments(Model)
  r_s.avg <- Model$q*(Model$kappa.0 + Model$A.0*(Model$kappa.1 - 1) + Model$Mu.d$D +
                  t((Model$kappa.1-1)*c(Model$A.1$A,Model$A.1$B) + c(Model$Mu.d$A,Model$Mu.d$B)) %*% moments$unc.mean)
  
  # Compute average risk-free short-term rate
  r.avg <- Model$q*(Model$Eta$D + 
                sum(c(Model$Eta$A,Model$Eta$B)*moments$unc.mean))
  
  delta.g.d.simul <- (res.simul$F) %*% Model$Mu.d$A +
    (res.simul$N) %*% Model$Mu.d$B +
    (res.simul$N_1) %*% Model$Mu.d$C + Model$Mu.d$D
  
  # Compute simulated equity returns:
  X_1 <- list(
    F   = rbind(X$F[1,],  X$F[1:(nb.sim-1),]),
    N   = rbind(X$N[1,],  X$N[1:(nb.sim-1),]),
    N_1 = rbind(X$N_1[1,],X$N_1[1:(nb.sim-1),])
  )
  
  r.s <- (X$F - X_1$F) %*% Model$A.1$A +
    (X$N - X_1$N) %*% Model$A.1$B +
    (X$N_1 - X_1$N_1) %*% Model$A.1$C +
    Model$Mu.d$D +
    X$F %*% Model$Mu.d$A +
    X$N %*% Model$Mu.d$B +
    X$N_1 %*% Model$Mu.d$C
  
  plot(cumprod(exp(r.s)),type="l",main="Equity")
  par(new=TRUE)
  plot(r.s,type="l",col="red",yaxt="n")
  
  moments <- compute.moments(Model)
  z.bar.bar <- Model$A.0 +
    t(Model$A.1$A) %*% Model$A.1$A +
    t(Model$A.1$B) %*% Model$A.1$B
  
  # max.H expressed in years
  
  v <- c(1,rep(0,J-1))
  cds.p.fast.Q <- cds.pricing.fast(Model,max.H,X,v,du)
  Model.P <- Model
  Model.P$Delta <- NULL
  cds.p.fast.P <- cds.pricing.fast(Model.P,max.H,X,v,du)
  
  matur <- 10*Model$q
  plot(cds.p.fast.Q[,matur],type="l",ylim=c(0,max(cds.p.fast.Q[,matur],cds.p.fast.P[,matur])),
       main="CDS")
  lines(cds.p.fast.P[,matur],col="red")
  
  plot(cds.p.fast.Q[,Model$q*targets$maturities.4.slope[2]]-
         cds.p.fast.Q[,Model$q*targets$maturities.4.slope[1]],type="l",
       main="CDS TS slope")
  
  return(1)
}

