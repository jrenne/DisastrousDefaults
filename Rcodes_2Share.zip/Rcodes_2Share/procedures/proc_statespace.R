# =======================================
# DISASTROUS DEFAULTS
# =======================================
# Christian Gouriéroux, Alain Monfort,
# Jean-Paul Renne and Sarah Mouabbi
# Contact: jean-paul.renne@unil.ch
# =======================================
# This version: October 2020
# =======================================
# This script contains procedures
# aimed at building the state-space model
# used for the estimation.
# =======================================


prepare.state.space <- function(Model,
                                DATASET,
                                indic.smooth=0){
  # vec.stdv is the vector of standard deviations of measurement errors.
  # There are three latent variables: x_t, y_t and n_{1,t}
  
  T <- dim(DATASET$observables)[1]
  vec.1 <- matrix(1,T,1)
  
  n.F <- dim(Model$zeta.F)[1]
  J <- dim(Model$zeta.n)[1]
  
  # compute unconditional moments for Model:
  res.moments <- compute.moments(Model)
  
  nu_t <- vec.1 %*% matrix(
    c(res.moments$MU[(J+1):(n.F+1)], # x_{t}, y_{t}, n^s
      c(0,0)), # x_{t-1}, y_{t-1}
    nrow=1)
  H.aux <- res.moments$PHI[(J+1):(n.F+1),(J+1):(n.F+1)]
  H     <- matrix(0,n.F-J+3,n.F-J+3)
  H[1:(n.F-J+1),1:(n.F-J+1)] <- H.aux
  H[(n.F-J+2):(n.F-J+3),1:2] <- diag(2)
  
  # Initialization of the filter:
  rho_0 <- c(res.moments$unc.mean[(J+1):(n.F+1)],
             res.moments$unc.mean[(J+1):(J+2)])
  Sigma_0.aux <- res.moments$unc.var[(J+1):(n.F+1),(J+1):(n.F+1)]
  Sigma_0     <- matrix(0,n.F-J+3,n.F-J+3)
  Sigma_0[1:(n.F-J+1),1:(n.F-J+1)] <- Sigma_0.aux
  Sigma_0[(n.F-J+2):(n.F-J+3),(n.F-J+2):(n.F-J+3)] <- res.moments$unc.var[(J+1):(J+2),(J+1):(J+2)]
  Sigma_0[(n.F-J+2):(n.F-J+3),1:(n.F-J+1)] <- H.aux[1:2,1:2] %*% Sigma_0[1:2,1:(n.F-J+1)]
  Sigma_0[1:(n.F-J+1),(n.F-J+2):(n.F-J+3)] <- Sigma_0[1:(n.F-J+1),1:2] %*% t(H.aux[1:2,1:2])
  
  v <- c(1,rep(0,J-1)) # consider only first type of entities (systemic ones)
  
  # ============
  eps <- .000001
  # ============
  
  m.F1 <- res.moments$unc.mean[n.F-1]
  m.F2 <- res.moments$unc.mean[n.F]
  s.F1 <- sqrt(res.moments$unc.var[n.F-1,n.F-1])
  s.F2 <- sqrt(res.moments$unc.var[n.F,n.F])
  nb.values  <- 5
  nb.std.dev <- 8
  values.F1 <- seq(param.4.grid,m.F1+nb.std.dev*s.F1,by=(m.F1+nb.std.dev*s.F1)/nb.values)
  values.F2 <- seq(param.4.grid,m.F2+nb.std.dev*s.F2,by=(m.F2+nb.std.dev*s.F2)/nb.values)
  matrix.values.F1 <- matrix(values.F1,nb.values,nb.values)
  matrix.values.F2 <- t(matrix(values.F2,nb.values,nb.values))
  All.F1.F2 <- rbind(
    cbind(c(matrix.values.F1),c(matrix.values.F2)),
    cbind(c(matrix.values.F1)+eps,c(matrix.values.F2)),
    cbind(c(matrix.values.F1),c(matrix.values.F2)+eps)
  )
  X.complete <- list(
    F = cbind(matrix(0,dim(All.F1.F2)[1],J),All.F1.F2),
    N   = matrix(0,dim(All.F1.F2)[1],J),
    N_1 = matrix(0,dim(All.F1.F2)[1],J)
  )
  res.prices.0 <- compute.prices.for.given.X(Model,X.complete,v,
                                             DATASET)
  
  G.1 <- (res.prices.0$all.prices[(nb.values^2+1):(2*nb.values^2),] -
            res.prices.0$all.prices[1:(nb.values^2),])/eps
  G.2 <- (res.prices.0$all.prices[(2*nb.values^2+1):(3*nb.values^2),] -
            res.prices.0$all.prices[1:(nb.values^2),])/eps
  all.G <- array(0,c(dim(res.prices.0$all.prices)[2],
                     n.F-J+3, # number of latent factors
                     nb.values^2))
  all.G[,1,] <- c(t(G.1))
  all.G[,2,] <- c(t(G.2))
  all.mu_t <- array(t(
    res.prices.0$all.prices[1:(nb.values^2),] -
      G.1 * (matrix(matrix.values.F1,ncol=1) %*% matrix(1,1,dim(G.1)[2])) -
      G.2 * (matrix(matrix.values.F2,ncol=1) %*% matrix(1,1,dim(G.1)[2]))
  ),
  c(dim(res.prices.0$all.prices)[2],1,nb.values^2))
  
  # Add consumption and defaults:
  all.G.plus <- array(0,c(dim(res.prices.0$all.prices)[2]+3, # The three addit var are: delta(c), n_{1,t} and stock returns
                          n.F-J+3, # number of latent factors
                          nb.values^2))
  n1 <- dim(all.G.plus)[1]
  n2 <- dim(all.G.plus)[2]
  n3 <- dim(all.G.plus)[3]
  
  all.G.plus[1:(n1-3),1:n2,1:n3] <- c(all.G)
  all.G.plus[n1-2,,] <- c(Model$Mu.c$A[(n.F-1):(n.F)],Model$Mu.c$B[1],0,0) # recall: the latent variables are x,y,n^s,x_1,y_1
  all.G.plus[n1-1,,]   <- c(0,0,1,0,0) # The observed variable is n_{1,t}; the latent variables are x,y,n^s,x_1,y_1
  all.G.plus[n1,1,]   <- 100 * (Model$A.1$A[J+1] + Model$Mu.d$A[J+1]) # This is how stock returns load on x_{t}
  all.G.plus[n1,2,]   <- 100 * (Model$A.1$A[J+2] + Model$Mu.d$A[J+2]) # This is how stock returns load on y_{t}
  all.G.plus[n1,4,]   <- 100 * (-Model$A.1$A[J+1]) # This is how stock returns load on x_{t-1}
  all.G.plus[n1,5,]   <- 100 * (-Model$A.1$A[J+2]) # This is how stock returns load on y_{t-1}
  
  all.mu_t.plus <- array(NaN,c(n1,1,n3))
  all.mu_t.plus[1:(n1-3),1,1:n3] <- c(all.mu_t)
  all.mu_t.plus[n1-2,1,1:n3] <- Model$Mu.c$D # This is for delta(c)
  all.mu_t.plus[n1-1,1,1:n3] <- 0 # This is for n_{1,t}.
  all.mu_t.plus[n1  ,1,1:n3] <- 100*Model$Mu.d$D # This is for the stock returns
  
  # At that stage, M is a vector containing the std dev of measurement errors:
  M <- DATASET$vec.stdv
  # Sigma_c:
  M[n1-2] <- Model$sigma.c
  # n_{1,t}:
  M[n1-1] <- .00001
  
  all.G    <- all.G.plus
  all.mu_t <- all.mu_t.plus
  
  vec.indices <- 1:(n.F+J)^2
  mat.indices <- matrix(vec.indices,n.F+J,n.F+J)
  indices <- c(mat.indices[(J+1):(n.F+1),(J+1):(n.F+1)])
  N <- list(
    alpha = res.moments$ALPHA[indices],
    beta  = res.moments$BETA[indices,(J+1):(n.F+1)]
  )
  
  if(is.na(sum(all.G))){
    res.KF <- list(loglik=-1000000000000)
  }else{
    res.KF <- Kalman_filter(DATASET$observables,
                            nu_t,H,N,all.mu_t,all.G,M,Sigma_0,rho_0,indic_pos=1,
                            values.factors.EKF = cbind(c(matrix.values.F1),
                                                       c(matrix.values.F2)))
    if(indic.smooth==1){
      res.KS <- Kalman_smoother(DATASET$observables,
                                nu_t,H,N,all.mu_t,all.G,M,Sigma_0,rho_0,indic_pos=1,
                                values.factors.EKF = cbind(c(matrix.values.F1),
                                                           c(matrix.values.F2)))
      res.KF$r_smooth <- res.KS$r_smooth
      res.KF$S_smooth <- res.KS$S_smooth
    }
  }
  
  return(res.KF)
}





compute.prices.for.given.X <- function(Model,X.complete,v,
                                       DATASET){
  
  select.tranches <- 1:length(DATASET$vec.a.b.4.tranches)
  
  T <- dim(X.complete$F)[1]
  
  # ==========================================
  # Compute itraxx for all maturities:
  
  all.modeled.itraxx <- compute.model.implied.itraxx(X.complete,v,
                                                     Model,DATASET)
  all.modeled.itraxx <- matrix(all.modeled.itraxx,
                               nrow=T)
  
  # ==========================================
  # Compute model-implied IV:
  
  K.over.P <- rep(1-DATASET$decrease.in.percent.4.stock.options/100,T)
  
  option.prices <- Equity.option.pricing(Model,
                                         DATASET$H.in.years.4.stock.options,
                                         X.complete,
                                         v,
                                         K.over.P,
                                         min.log.v=-10,max.v=10000,step=.01)
  
  all.model.implied.vol <- NULL
  count <- 0
  for(h in DATASET$H.in.years.4.stock.options){
    count <- count + 1
    all.model.implied.vol <- cbind(all.model.implied.vol,
                                   compute.implied.vol(relative.prices = option.prices$Put[,count],
                                                       K.over.S = K.over.P,
                                                       maturities.in.years=h,
                                                       riskfree.rates = 0,
                                                       nb.iterations = 10))
  }
  
  # ==========================================
  # Compute model-implied tranche prices
  
  res.tranche.pricing <- Tranche.pricing(Model,
                                         max.H = max(DATASET$H.in.years.4.tranches),
                                         X.complete,
                                         v,
                                         DATASET$vec.a.b.4.tranches,
                                         U=NaN,
                                         du=0.0001,
                                         min.log.v=-8,
                                         max.v=40,
                                         step=.02)
  
  columns.2.keep <- DATASET$H.in.years.4.tranches*DATASET$q
  
  all.model.implied.tranches <-
    matrix(res.tranche.pricing$S.a.b[,columns.2.keep,select.tranches],
           T,length(DATASET$H.in.years.4.tranches)*length(select.tranches))
  
  return(list(
    all.modeled.itraxx         = all.modeled.itraxx,
    all.model.implied.vol      = all.model.implied.vol,
    all.model.implied.tranches = all.model.implied.tranches,
    all.prices                 = cbind(all.modeled.itraxx,
                                       all.model.implied.vol,
                                       all.model.implied.tranches)))
}



make.THETA0 <- function(THETA,
                        THETA.FULL,
                        Filter){
  THETA0 <- THETA.FULL
  THETA0 <- sign(THETA0)*pmin(abs(THETA0),30)
  THETA0[Filter==1] <- THETA
  return(THETA0)
}


make.Model <- function(THETA,
                       THETA.FULL,
                       Model,
                       DATASET,
                       targets,
                       nb.iter=100,
                       print.sol.quality=0,
                       dampen.factor=.5){
  THETA0 <- make.THETA0(THETA,
                        THETA.FULL,
                        Filter)
  
  # THETA organized as follows:
  
  theta0 <- rep(NaN,11)
  
  # [1]: Share of variance of Delta c that is accounted for by volatile component:
  theta0[1] <- exp(THETA0[1])/(1 + exp(THETA0[1]))
  
  # [2]: c_1
  theta0[2] <- min(exp(THETA0[2])/(1 + exp(THETA0[2])),0.49)
  
  # [3]: mu_y
  theta0[3] <- exp(THETA0[3])
  
  # [4]: mu_{c,w}
  if(THETA0[4]<=-30){
    # In this case, there will be no macro effect of defaults
    theta0[4] <- 0
  }else{
    theta0[4] <- -exp(THETA0[4])
  }
  
  # [5]: mu_w
  theta0[5] <- exp(THETA0[5])
  
  # [6]: mu_{c,x}
  theta0[6] <- -exp(THETA0[6])
  
  # [7]: mu_{d,w}/mu_{c,w} (=chi) = mu_{d,x}/mu_{c,x} = mu_{d,y}/mu_{c,y}
  theta0[7] <- exp(THETA0[7])
  
  # [8]: rho_x
  theta0[8] <- exp(THETA0[8])/(1+exp(THETA0[8]))
  
  # [9]: rho_y
  theta0[9] <- exp(THETA0[9])/(1+exp(THETA0[9]))
  
  # [10]: Var(x)
  theta0[10] <- exp(THETA0[10])
  
  # [11]: mu_{c,y}
  theta0[11] <- -exp(THETA0[11])
  
  Model <- make.Model.aux(theta0,
                          Model,
                          DATASET,targets,
                          nb.iter,
                          print.sol.quality,dampen.factor)
  return(Model)
}


make.Model.aux <- function(theta,
                           Model,
                           DATASET,
                           targets,
                           nb.iter=100,
                           print.sol.quality=0,
                           dampen.factor=.5){
  # theta0 organized as follows:
  # [1]: Share of variance of Delta c that is accounted for by volatile component
  # [2]: c_1
  # [3]: mu_y
  # [4]: mu_{c,w}
  # [5]: mu_w
  # [6]: mu_{c,x}
  # [7]: chi
  # [8]: rho_x
  # [9]: rho_y
  # [10]: Var(x)
  # [11]: mu_{c,y}
  
  n.F <- dim(Model$zeta.F)[1]
  J <- dim(Model$zeta.n)[1]
  
  Model.aux <- Model
  
  Model.aux$sigma.c <- targets$stdv.delta.c.yoy * sqrt(theta[1]/DATASET$q)
  
  # The "counter" factors are the first J factors in F:
  # each column of the matrix gives the exposures of one factor.
  Model.aux$zeta.F <- matrix(0,n.F,n.F)
  
  rho_1 <- theta[8]
  rho_2 <- theta[9]
  
  mu_1 <- select.var.F1*(1-rho_1)
  
  var.F1 <- theta[10]
  mu_1 <- var.F1*(1-rho_1)
  
  zeta_11F <- rho_1/mu_1
  nu_1 <- (1-rho_1)/mu_1
  
  mu_2 <- theta[3]
  zeta_22F <- rho_2/mu_2
  
  zeta_12F <- (rho_1 - rho_2)/mu_2
  nu_2 <- (1 - rho_1)/mu_2
  
  Model.aux$zeta.F[J+1,J+1] <- zeta_11F
  Model.aux$zeta.F[J+2,J+2] <- zeta_22F
  Model.aux$zeta.F[J+1,J+2] <- zeta_12F
  
  Model.aux$mu     <- rep(1,n.F)
  Model.aux$mu[J+1] <- mu_1
  Model.aux$mu[J+2] <- mu_2
  Model.aux$nu     <- rep(0,n.F)
  Model.aux$nu[J+1] <- nu_1
  Model.aux$nu[J+2] <- nu_2
  
  Model.aux$beta.matrix <- matrix(0,n.F,J)
  Model.aux$beta.matrix[J+2,] <- theta[1] # exposure to F_2
  Model.aux$beta.matrix[J+2,] <- 1 # exposure to F_2
  
  # Mutual and Self-excitation (each column corresponds to the exposure of one sector):
  Model.aux$c.matrix    <- matrix(0,J,J) # mutual excitation
  Model.aux$c.matrix[1:(J-1),1:(J-1)] <- theta[2] # self-excitation (between systemic)
  Model.aux$c.matrix[1:(J-1),1:(J-1)] <- theta[2] # self-excitation (between systemic)
  Model.aux$c.matrix[1:(J-1),J] <- 0 # cross-excitation (systemic -> non-systemic)
  Model.aux$c.matrix[1:(J-1),J] <- Model.aux$c.matrix[1:(J-1),1] # cross-excitation (systemic -> non-systemic)
  
  # In the following, computations imposing targets$target.default.rate:
  moments.aux <- compute.moments(Model.aux)
  
  # Take row corresponding to n_1:
  vec.aux <- c(1,rep(0,J-1)) - Model.aux$c.matrix[,1]
  E.n <- rep(DATASET$I.iTraxx * targets$target.default.rate / DATASET$q,J)
  exp2F_2 <- sum(vec.aux * E.n)/
    (moments.aux$MU[n.F] + (moments.aux$PHI[1:n.F,1:n.F]%*%moments.aux$unc.mean[1:n.F])[n.F])
  Model.aux$beta.matrix[J+2,] <- exp2F_2
  
  moments.aux <- compute.moments(Model.aux)
  
  rho_Z <- 0
  mu_Z <- theta[5]
  Model.aux$mu[1:J] <- mu_Z
  
  diag(Model.aux$zeta.F[1:J,1:J]) <- rho_Z/mu_Z
  
  Model.aux$zeta.n <- matrix(0,J,n.F)
  diag(Model.aux$zeta.n[1:J,1:J]) <- (1-rho_Z)/mu_Z/moments.aux$unc.mean[(J+2+1):(J+2+J)]
  
  moments <- compute.moments(Model.aux)
  
  
  # ==================================
  # Specification of consumption growth:
  
  Mu.c = list(
    A= matrix(c(rep(theta[4],J-1),0,c(theta[6],theta[11])),ncol=1),
    B= matrix(c(0,rep(0,J-1)),ncol=1),
    C= matrix(c(0,rep(0,J-1)),ncol=1),
    D= 0)
  
  V <- moments$unc.var
  PHI <- moments$PHI
  Var.X.q <- DATASET$q * V
  for(j in 1:(DATASET$q-1)){
    Var.X.q <- Var.X.q + 2 * (DATASET$q-j) * (PHI%^%j %*% V + V %*% t(PHI%^%j))
  }
  
  var.delta.c.one.year.no.sigmac.before.adjust <-
    t(Mu.c$A) %*% Var.X.q[1:n.F,1:n.F] %*% Mu.c$A
  targetted.variance.Mu.c <- (targets$stdv.delta.c.yoy)^2 - DATASET$q*(Model.aux$sigma.c)^2
  adjustment.stdv.factor <- c(sqrt(targetted.variance.Mu.c / var.delta.c.one.year.no.sigmac.before.adjust))
  
  Mu.c$A <- Mu.c$A * adjustment.stdv.factor
  Mu.c$B <- Mu.c$B * adjustment.stdv.factor
  
  Mu.c$C <- - Mu.c$B
  Mu.c$D <- targets$mu.c.annual/DATASET$q - sum(
    c(Mu.c$A,Mu.c$B) * moments$unc.mean
  )
  
  Model.aux$Mu.c  <- Mu.c
  
  # ==================================
  # Specification of dividend growth rate:
  
  mult.fact <- theta[7] # This is chi
  
  Model.aux$Mu.d  <- list(
    A = mult.fact*Model.aux$Mu.c$A,
    B = mult.fact*Model.aux$Mu.c$B,
    C = mult.fact*Model.aux$Mu.c$C,
    D = NaN)
  
  Model.aux$Mu.d$D <- targets$mu.c.annual/DATASET$q -
    sum(moments$unc.mean*c(Model.aux$Mu.d$A,Model.aux$Mu.d$B))
  
  
  # ==================================
  
  Model.solved <- run.solve.model(Model.aux,nb.iter,print.sol.quality,dampen.factor)
  
  return(Model.solved)
}


loglik.KF <- function(theta,
                      THETA.FULL,
                      Model,
                      DATASET,targets,
                      nb.iter=100,
                      indic.vector=0 # if indic.vector = 1 then gives the time vector of loglik components
){
  
  Model.solved <- make.Model(theta,
                             THETA.FULL,
                             Model,
                             DATASET,targets,
                             nb.iter)
  
  if(is.na(Model.solved$min.fun2min.4.sdf)|is.na(Model.solved$min.fun2min.4.r_s)){
    logl <- 1000000000000
  }else if((abs(Model.solved$min.fun2min.4.sdf)<1)&(abs(Model.solved$min.fun2min.4.r_s)<1)){
    res.KF <- prepare.state.space(Model.solved,
                                  DATASET)
    logl <- - res.KF$loglik
  }else{
    logl <- abs(Model.solved$min.fun2min.4.sdf + Model.solved$min.fun2min.4.r_s)
  }
  
  if(indic.vector == 1){
    logl <- list(
      vector = res.KF$loglik.vector,
      scalar = res.KF$loglik)
  }
  
  return(logl)
}




autocov <- function(X,n){
  # X is a Txk matrix
  # returns an estimator of E(X_{t-n}X_t)
  T <- dim(X)[1]
  k <- dim(X)[2]
  vec.1 <- matrix(1,1,k)
  mean.X <- apply(X,2,mean)
  X.1 <- X[1:(T-n),] - t(matrix(mean.X,k,T-n))
  X.2 <- X[(n+1):T,] - t(matrix(mean.X,k,T-n))
  return(
    matrix(1/T * apply((X.1 %x% vec.1) * (vec.1 %x% X.2),2,sum),k,k)
  )
}


NW.Weights <- function(q){
  if(q==0){
    weights <- 0
  }else{
    weights <- 1 - (1:q)/(q+1)
  }
  return(weights)
}


NW.LongRunVariance <- function(X,q){
  gamma0 <- autocov(X,0)
  LRV <- gamma0
  if(q>0){
    weights <- NW.Weights(q)
    for(i in 1:q){
      LRV <- LRV + weights[i] * (autocov(X,i) + t(autocov(X,i)))
    }
  }
  return(LRV)
}


function.compute.param.4.stdv.computation <- function(THETA,
                                                      THETA.FULL,
                                                      Model,
                                                      DATASET,targets,
                                                      nb.iter=100,
                                                      dampen.factor=.5){
  
  Model.solved.aux <- make.Model(THETA,
                                 THETA.FULL,
                                 Model,
                                 DATASET,targets,
                                 nb.iter,
                                 print.sol.quality=0,
                                 dampen.factor)
  
  latex.names.of.param <- NULL
  vector.of.param <- NULL
  
  latex.names.of.param <- c(latex.names.of.param,"$c_{i}\\quad i \\in \\{1,2\\}$")
  vector.of.param <- c(vector.of.param,Model.solved.aux$c.matrix[1,1])
  
  latex.names.of.param <- c(latex.names.of.param,"$\\beta_{i}\\quad i \\in \\{1,2\\}$")
  vector.of.param <- c(vector.of.param,Model.solved.aux$beta.matrix[J+2,1])
  
  latex.names.of.param <- c(latex.names.of.param,"$\\mu_w$")
  vector.of.param <- c(vector.of.param,Model.solved.aux$mu[1])
  
  latex.names.of.param <- c(latex.names.of.param,"$\\xi_w$")
  vector.of.param <- c(vector.of.param,Model.solved.aux$zeta.n[1,1])
  
  latex.names.of.param <- c(latex.names.of.param,"$\\mu_x$")
  vector.of.param <- c(vector.of.param,Model.solved.aux$mu[J+1])
  
  latex.names.of.param <- c(latex.names.of.param,"$\\mu_y$")
  vector.of.param <- c(vector.of.param,Model.solved.aux$mu[J+2])
  
  latex.names.of.param <- c(latex.names.of.param,"$\\rho_x$")
  vector.of.param <- c(vector.of.param,Model.solved.aux$zeta.F[J+1,J+1]*Model.solved.aux$mu[J+1])
  
  latex.names.of.param <- c(latex.names.of.param,"$\\rho_y$")
  vector.of.param <- c(vector.of.param,Model.solved.aux$zeta.F[J+2,J+2]*Model.solved.aux$mu[J+2])
  
  latex.names.of.param <- c(latex.names.of.param,"$\\mu_{c,x} $")
  vector.of.param <- c(vector.of.param,Model.solved.aux$Mu.c$A[J+1])
  
  latex.names.of.param <- c(latex.names.of.param,"$\\mu_{c,y} $")
  vector.of.param <- c(vector.of.param,Model.solved.aux$Mu.c$A[J+2])
  
  latex.names.of.param <- c(latex.names.of.param,"$\\mu_{c,w} $")
  vector.of.param <- c(vector.of.param,Model.solved.aux$Mu.c$A[1])
  
  latex.names.of.param <- c(latex.names.of.param,"$\\mu_{d,x} $")
  vector.of.param <- c(vector.of.param,Model.solved.aux$Mu.d$A[J+1])
  
  latex.names.of.param <- c(latex.names.of.param,"$\\mu_{d,y} $")
  vector.of.param <- c(vector.of.param,Model.solved.aux$Mu.d$A[J+2])
  
  latex.names.of.param <- c(latex.names.of.param,"$\\mu_{d,w} $")
  vector.of.param <- c(vector.of.param,Model.solved.aux$Mu.d$A[1])
  
  latex.names.of.param <- c(latex.names.of.param,"$\\chi $")
  vector.of.param <- c(vector.of.param,Model.solved.aux$Mu.d$A[1]/Model.solved.aux$Mu.c$A[1])
  
  latex.names.of.param <- c(latex.names.of.param,"$\\sigma_c $")
  vector.of.param <- c(vector.of.param,Model.solved.aux$sigma.c)
  
  return(list(
    vector.of.param = vector.of.param,
    latex.names.of.param = latex.names.of.param
  ))
}


grad.function.compute.param.4.stdv.computation <- function(THETA,
                                                           THETA.FULL,
                                                           Model,eps,
                                                           DATASET,targets,
                                                           nb.iter,
                                                           dampen.factor=.5){
  
  grad.matrix <- NULL
  f.0 <- function.compute.param.4.stdv.computation(THETA,
                                                   THETA.FULL,
                                                   Model,
                                                   DATASET,targets,
                                                   nb.iter,
                                                   dampen.factor)$vector.of.param
  for(i in 1:length(THETA)){
    THETA.i <- THETA
    THETA.i[i] <- THETA.i[i] + eps[i]
    f.i <- function.compute.param.4.stdv.computation(THETA.i,
                                                     THETA.FULL,
                                                     Model,
                                                     DATASET,targets,
                                                     nb.iter,
                                                     dampen.factor)$vector.of.param
    grad.matrix <- cbind(grad.matrix,(f.i - f.0)/eps[i])
  }
  return(grad.matrix)
}
