# =======================================
# DISASTROUS DEFAULTS
# =======================================
# Christian Gouriéroux, Alain Monfort,
# Jean-Paul Renne and Sarah Mouabbi
# Contact: jean-paul.renne@unil.ch
# =======================================
# This script contains procedures
# aimed at pricing the different 
# financial instruments considered
# in the paper.
# =======================================




ABCD <- function(v,Model){
  
  # A is associated with F(t), B with N(t) and C with N(t-1):
  v_A = v$A
  v_B = v$B
  v_C = v$C
  
  beta.matrix <- Model$beta.matrix
  c.matrix <- Model$c.matrix
  gamma.vec <- Model$gamma.vec
  
  J <- dim(Model$c.matrix)[1] # Number of segments
  n.F <- dim(Model$beta.matrix)[1] # number of Factors (dimension of F)
  
  # Number of simultaneous evaluations of the function:
  n_u = NCOL(v_A)
  if(NCOL(v_B)!=n_u){
    stop("inconsistent number of columns (v_A,v_B,v_C)")
  }
  if(NCOL(v_C)!=n_u){
    stop("inconsistent number of columns (v_A,v_B,v_C)")
  }
  
  # Computation of recurrent sums:
  # aux_b is the sum over j (in 1:J) of (exp(v_Bj)-1)*beta_j:
  aux_b = ((exp(v_B) - 1) %x% array(1,c(1,1,n.F))) *
    ( array(t(beta.matrix),c(J,1,n.F))  %x% array(1,c(1,n_u,1)) )
  aux_b = t(apply(aux_b,c(2,3),sum))
  # aux_c is the sum over j (in 1:J) of (exp(v_Bj)-1)*c_j:
  aux_c = ((exp(v_B) - 1) %x% array(1,c(1,1,J))) *
    ( array(t(c.matrix),c(J,1,J)) %x% array(1,c(1,n_u,1)) )
  aux_c = t(apply(aux_c,c(2,3),sum))
  # aux_g is the sum over j (in 1:J) of (exp(v_Bj)-1)*gamma_j:
  aux_g = (exp(v_B) - 1) * ( matrix(gamma.vec,ncol=1) %x% matrix(1,1,n_u) )
  aux_g = t(apply(aux_g,2,sum))

  aa.bb.cc.dd.F <- aa.bb.cc.dd(aux_b + v_A,Model)
  
  A = aa.bb.cc.dd.F$aa
  B = aa.bb.cc.dd.F$bb + aux_c + v_B + v_C
  C = aa.bb.cc.dd.F$cc - aux_c
  D = aa.bb.cc.dd.F$dd + aux_g
  
  y = list(A=A,B=B,C=C,D=D)
  return(y)
}


ABCDh <- function(u,H,Model,u2=NULL,indic.for.one.year=0){
  # H is a matrix (vector) containing the requested maturities
  # If indic.for.one.year=q, then what is computed is the
  #     LT of u'X_{t+h-q}+u'X_{t+h-q+1}+...+u'X_{t+h-1}+u_2'X_{t+h-1}
  u_A = u$A
  u_B = u$B
  u_C = u$C
  u_D = u$D
  
  n.F = NROW(u_A)
  n_u = NCOL(u_A)
  J   = NROW(u_B)
  
  if(NCOL(u_B)!=n_u){
    stop("inconsistent number of columns (u_A,u_B,u_C,u_D)")
  }
  if(NCOL(u_C)!=n_u){
    stop("inconsistent number of columns (u_A,u_B,u_C,u_D)")
  }
  if(NCOL(u_D)!=n_u){
    stop("inconsistent number of columns (u_A,u_B,u_C,u_D)")
  }
  
  # Prices of risk:
  if(is.null(Model$Delta)){
    # If no Delta specification is provided, then
    # prices of risk are set to 0.
    Model$Delta <- NULL
    Model$Delta$A <- matrix(0,n.F,1)
    Model$Delta$B <- matrix(0,J,1)
    Model$Delta$C <- matrix(0,J,1)
  }
  
  delta.A <- Model$Delta$A  %*% matrix(1,1,n_u)
  delta.B <- Model$Delta$B  %*% matrix(1,1,n_u)
  delta.C <- Model$Delta$C  %*% matrix(1,1,n_u)
  
  # Specification of the short-term riskfree rate:
  if(is.null(Model$Eta)){
    # If no short-term rate specification is provided, then
    # the short-term rate is set to 0.
    Model$Eta <- NULL
    Model$Eta$A <- matrix(0,n.F,1)
    Model$Eta$B <- matrix(0,J,1)
    Model$Eta$C <- matrix(0,J,1)
    Model$Eta$D <- matrix(0,1,1)
  }
  
  eta1_A <- Model$Eta$A %*% matrix(1,1,n_u)
  eta1_B <- Model$Eta$B %*% matrix(1,1,n_u)
  eta1_C <- Model$Eta$C %*% matrix(1,1,n_u)
  eta0   <- Model$Eta$D %*% matrix(1,1,n_u)
  
  ABCD_delta = ABCD(Model$Delta,Model)
  
  ABCD_delta.A = ABCD_delta$A %*% matrix(1,1,n_u)
  ABCD_delta.B = ABCD_delta$B %*% matrix(1,1,n_u)
  ABCD_delta.C = ABCD_delta$C %*% matrix(1,1,n_u)
  ABCD_delta.D = ABCD_delta$D %*% matrix(1,1,n_u)
  
  # H contains the required maturities (in ascending order)
  nb_matur = max(dim(H))
  
  A_all = array(rep(0,n.F*nb_matur*n_u),c(n.F,n_u,nb_matur))
  B_all = array(rep(0,  J*nb_matur*n_u),c(  J,n_u,nb_matur))
  C_all = array(rep(0,  J*nb_matur*n_u),c(  J,n_u,nb_matur))
  D_all = array(rep(0,  1*nb_matur*n_u),c(  1,n_u,nb_matur))
  
  # Initialization of the recursive algorithm:
  if(is.null(u2)){
    A_aux = u_A
    B_aux = u_B
    C_aux = u_C
    D_aux = u_D
    addit.D = 0
  }else{
    D_aux = 0
    addit.D = u2$D
  }
  
  # count is the number of requested maturities that have been treated:
  count = 0
  
  for (h in 1:max(H)){
    if(is.null(u2)){
      v =list(A = A_aux + delta.A,
              B = B_aux + delta.B,
              C = C_aux + delta.C)
    }else{
      # The payoff is exp(u_1'X_{t+1}+...+u_1'X_{t+h-1}+u_2'X_{t+h}) or
      #               exp(u_1'X_{t+h-q+1}+...+u_1'X_{t+h-1}+u_2'X_{t+h}) if indic.stop.for.one.year=q
      if(h==1){
        v =list(A = u2$A + delta.A,
                B = u2$B + delta.B,
                C = u2$C + delta.C)
      }else{
        if(indic.for.one.year==0){
          v =list(A = A_aux + delta.A + u_A,
                  B = B_aux + delta.B + u_B,
                  C = C_aux + delta.C + u_C)
          addit.D = u_D
        }else{
          # In this case we are just interested in a linear combi. over q periods 
          if(h<=indic.for.one.year){
            v =list(A = A_aux + delta.A + u_A,
                    B = B_aux + delta.B + u_B,
                    C = C_aux + delta.C + u_C)
            addit.D = u_D
          }else{
            v =list(A = A_aux + delta.A,
                    B = B_aux + delta.B,
                    C = C_aux + delta.C)
            addit.D = 0
          }
        }
      }
    }
    ABCD_aux = ABCD(v,Model)
    A_aux = ABCD_aux$A - ABCD_delta.A - eta1_A
    B_aux = ABCD_aux$B - ABCD_delta.B - eta1_B
    C_aux = ABCD_aux$C - ABCD_delta.C - eta1_C
    D_aux = ABCD_aux$D - ABCD_delta.D - eta0 + D_aux + addit.D
    
    if(sum(h==H)>0){
      count = count+1
      A_all[,,count] = A_aux
      B_all[,,count] = B_aux
      C_all[,,count] = C_aux
      D_all[,,count] = D_aux
    }
  }
  y = list(A=A_all,
           B=B_all,
           C=C_all,
           D=D_all)
  return(y)
}


pp <- function(Model,u,H,X,indic_cumul=0,indic.for.one.year=0){
  
  if(indic_cumul == 0){
    ABCD.H <- ABCDh(u,H,Model)
  }else{
    ABCD.H <- ABCDh(u,H,Model,u,indic.for.one.year)
  }
  nb_matur = max(dim(H))
  n_u      = ncol(u$A)
  nb_periods = nrow(X$F)
  
  # -------------------
  # THE NEXT LINES ARE ADDED TO COMPUTE THE DISTRIBUTION OF DELTA(c):
  if(is.null(u$E)){
  }else{
    # In this case, as if there was an additional Gaussian term "u$D * N(0,1)"
    if(indic.for.one.year==0){
      # only once
      ABCD.H$D <- ABCD.H$D + array(u$E^2/2,c(1,n_u,nb_matur))
    }else{
      # "q" times
      ABCD.H$D <- ABCD.H$D + array(indic.for.one.year*u$E^2/2,c(1,n_u,nb_matur))
    }
  }
  # -------------------
  
  p = array(0,c(nb_periods,n_u,nb_matur))
  for (i in 1:nb_matur){
    A.i = ABCD.H$A[,,i]
    B.i = ABCD.H$B[,,i]
    C.i = ABCD.H$C[,,i]
    D.i = ABCD.H$D[,,i]
    p[,,i] = exp(X$F %*% A.i + X$N %*% B.i + X$N_1 %*% C.i + matrix(1,nb_periods,1) %*% D.i)
  }
  return(p)
}



Price.RF.bonds <- function(Model,H,X=NULL){
  
  n.F <- dim(Model$zeta.F)[1]
  n.N <- dim(Model$zeta.n)[1]
  
  n.H <- length(H)
  
  u <- list(
    A = matrix(0,n.F,1),
    B = matrix(0,n.N,1),
    C = matrix(0,n.N,1),
    D = 0
  )
  res.ABCD <- ABCDh(u,H,Model)
  A <- matrix(res.ABCD$A,n.F,n.H)
  B <- matrix(res.ABCD$B,n.N,n.H)
  C <- matrix(res.ABCD$C,n.N,n.H)
  D <- matrix(res.ABCD$D,1,n.H)
  
  
  if(!is.null(X)){
    T <- dim(X$F)[1]
    vec.1 <- matrix(1,T,1)
    prices <- exp(
      X$F %*% A +
        X$N %*% B +
        X$N_1 %*% C +
        vec.1 %*% D
    )
    yields <- -log(prices) * (vec.1 %*% matrix(1/H,nrow=1))
  }else{
    prices <- NaN
    yields <- NaN
  }
  
  return(
    list(
      prices = prices,
      yields = yields,
      A = A,
      B = B,
      C = C,
      D = D
    )
  )
}

# For stock prices:
varphi <- function(Model,H,X,a=1){
  # This function provides the date-t prices of
  # the payoffs exp(a*(r*_{t+1}+...+r*_{t+h}))
  # H is a vector (matrix) containing the considered maturities.
  
  if(length(a)==1){
    a.vec <- matrix(a,nrow=1)
    u2 <- list(
      A = Model$Mu.d$A*a + Model$A.1$A*a,
      B = Model$Mu.d$B*a + Model$A.1$B*a,
      C = Model$Mu.d$C*a + Model$A.1$C*a,
      D = Model$Mu.d$D*a
    )
    u1 <- Model$Mu.d
  }else{
    a.vec <- matrix(a,nrow=1)
    u2 <- list(
      A = Model$Mu.d$A %*% a.vec + Model$A.1$A %*% a.vec,
      B = Model$Mu.d$B %*% a.vec + Model$A.1$B %*% a.vec,
      C = Model$Mu.d$C %*% a.vec + Model$A.1$C %*% a.vec,
      D = Model$Mu.d$D %*% a.vec
    )
    u1 <- list(
      A = Model$Mu.d$A %*% a.vec,
      B = Model$Mu.d$B %*% a.vec,
      C = Model$Mu.d$C %*% a.vec,
      D = Model$Mu.d$D %*% a.vec
    )
  }
  
  ABCD.H <- ABCDh(u1,H,Model,u2)
  nb_matur = max(dim(H))
  n_u      = ncol(u1$A)
  nb_periods = nrow(X$F)
  
  p = array(0,c(nb_periods,n_u,nb_matur))
  
  for (i in 1:nb_matur){
    A.i = ABCD.H$A[,,i]
    B.i = ABCD.H$B[,,i]
    C.i = ABCD.H$C[,,i]
    D.i = ABCD.H$D[,,i]
    p[,,i] = exp(X$F %*% (A.i - Model$A.1$A %*% a.vec) +
                   X$N %*% (B.i - Model$A.1$B %*% a.vec) +
                   X$N_1 %*% (C.i - Model$A.1$C %*% a.vec) +
                   matrix(1,nb_periods,1) %*% D.i)
  }
  return(p)
}


g <- function(Model,a,b,y,H,X,min.log.v=-8,max.v=10000,step=.01,indic_cumul=0,
              indic.for.one.year=0){
  # can be used for several simultaneous maturities but one a & b.
  # if indic_cumul == 1, the condition is
  #    b'(X_{t+1}+...+X_{t+h}) < y
  nb_periods = nrow(X$F)
  nb_matur = max(dim(H))
  
  max.x <- log(max.v)
  v <- matrix(exp(seq(min.log.v,max.x,by=step)),nrow=1)
  
  dim.v <- length(v)
  nv = matrix(1,1,dim.v)
  extended.v <- cbind(0,v,max.v)
  dim.ext.v <- dim.v + 2
  weights <- matrix(.5*(extended.v[2:(dim.ext.v-1)]-extended.v[1:(dim.ext.v-2)])+
                      .5*(extended.v[3:dim.ext.v]-extended.v[2:(dim.ext.v-1)]),nrow=1)
  
  v3d = array(1,c(1,1,nb_matur))%x%(matrix(1,nb_periods,1)%*%v)
  ab = list(A=(a$A %*% nv) + 1i*(b$A %*% v),
            B=(a$B %*% nv) + 1i*(b$B %*% v),
            C=(a$C %*% nv) + 1i*(b$C %*% v),
            D=(a$D %*% nv) + 1i*(b$D %*% v))
  
  if(is.null(b$E)){
    # standard case
  }else{
    #case where additional Gaussian term
    ab$E <- 1i*(b$E %*% v)
  }
  
  pp.Model.ab.H.X <- pp(Model,ab,H,X,
                        indic_cumul,indic.for.one.year)
  pp.Model.a.H.X  <- pp(Model,a,H,X)
  
  Result <- array(NaN,c(nb_periods,length(y),nb_matur))
  
  count <- 0
  for(Y in y){
    count <- count + 1
    integral = Im( pp.Model.ab.H.X * exp(-1i*Y*v3d) )/v3d
    #plot(v,c(integral)*c(weights),type="l")
    
    integral = array(
      apply(integral,c(1,3),function(x){x%*%t(weights)}),
      c(nb_periods,1,nb_matur))
    Result[,count,] <- pp.Model.a.H.X/2 - (1/pi)*integral
  }
  
  return(Result)
}

cds.pricing <- function(Model,max.H,X,v,du = 0.0001,min.log.v=-8,max.v=10000,step=.01){
  # v is the vector specifiying how N* is obtained:
  #      that is, we have N* = v'N.
  # I* is the total number of entities (i.e. we should have N*<=I*).
  # q is the time frequency of the model. For instance, for a monthly model, q=12.
  # Therefore, it is implicitly assumed that there is always one payment per period.
  # max.H is expressed in years. Hence qH is the maximum number of payments
  #      associated with the premium legs.
  # CDS premiums are expressed in annualized terms (s.t. S/q is paid on every period).
  # CDS premiums are computed for each of the J sectors.
  
  I.star <- sum(v * Model$I)
  
  T <- dim(X$F)[1]
  n.F <- dim(X$F)[2] # Number of factors F
  J <- dim(X$N)[2] # number of sectors
  
  all.H.not.in.years <- matrix(1:(Model$q*max.H),ncol=1)
  
  # Compute E(sum(N_k.I{N_k<I_j}))
  
  a.u   <- list(A = matrix(0,n.F,1),
                B = matrix(du*v,ncol=1),
                C = matrix(0,J,1),
                D = matrix(0,1,1))
  a.u_1 <- list(A = matrix(0,n.F,1),
                B = matrix(0,J,1),
                C = matrix(du*v,ncol=1),
                D = matrix(0,1,1))
  a.0   <- list(A = matrix(0,n.F,1),
                B = matrix(0,J,1),
                C = matrix(0,J,1),
                D = matrix(0,1,1))
  b     <- list(A = matrix(0,n.F,1),
                B = matrix(v,ncol=1),
                C = matrix(0,J,1),
                D = matrix(0,1,1))
  b_1   <- list(A = matrix(0,n.F,1),
                B = matrix(0,J,1),
                C = matrix(v,ncol=1),
                D = matrix(0,1,1))
  
  opt_prices.u     <- g(Model,a.u,b,y=I.star,all.H.not.in.years,X,min.log.v,max.v,step)
  opt_prices.u_1   <- g(Model,a.u_1,b_1,y=I.star,all.H.not.in.years,X,min.log.v,max.v,step)
  opt_prices.0     <- g(Model,a.0,b,y=I.star,all.H.not.in.years,X,min.log.v,max.v,step)
  opt_prices.0_1   <- g(Model,a.0,b_1,y=I.star,all.H.not.in.years,X,min.log.v,max.v,step)
  
  numer <- matrix(((opt_prices.u - opt_prices.0) - (opt_prices.u_1 - opt_prices.0_1))/du + I.star*(opt_prices.0_1-opt_prices.0),
                  T,max(all.H.not.in.years))
  denum <- matrix(I.star*opt_prices.0 - (opt_prices.u - opt_prices.0)/du,
                  T,max(all.H.not.in.years))
  
  cumsum.numer <- t(apply(numer,c(1),cumsum))
  cumsum.denum <- t(apply(denum,c(1),cumsum))
  
  S <- Model$q*(1-Model$RR)*(cumsum.numer/cumsum.denum)
  
  return(S)
}


cds.pricing.fast <- function(Model,max.H,X,v,du = 0.0001){
  # v is the vector specifiying how N* is obtained:
  #      that is, we have N* = v'N.
  # I* is the total number of entities (i.e. we should have N*<=I*).
  # q is the time frequency of the model. For instance, for a monthly model, q=12.
  # Therefore, it is implicitly assumed that there is always one payment per period.
  # max.H is expressed in years. Hence qH is the maximum number of payments
  #      associated with the premium legs.
  # CDS premiums are expressed in annualized terms (s.t. S/q is paid on every period).
  # CDS premiums are computed for each of the J sectors.
  
  
  I.star <- sum(v * Model$I)
  
  T <- dim(X$F)[1]
  n.F <- dim(X$F)[2] # Number of factors F
  J <- dim(X$N)[2] # number of sectors
  
  all.H.not.in.years <- matrix(1:(Model$q*max.H),ncol=1)
  
  # Compute E(sum(N_k.I{N_k<I_j}))
  
  a.u   <- list(A = matrix(0,n.F,3),
                B = cbind(matrix(du*v,ncol=1),matrix(0,J,1),matrix(0,J,1)),
                C = cbind(matrix(0,J,1),matrix(du*v,ncol=1),matrix(0,J,1)),
                D = matrix(0,1,3))
  
  p.u   <- pp(Model,a.u,matrix(all.H.not.in.years,ncol=1),X)
  
  numer <- matrix((p.u[,1,] - p.u[,2,])/du,
                  T,max(all.H.not.in.years))
  denum <- matrix(I.star*p.u[,3,] - (p.u[,1,] - p.u[,3,])/du,
                  T,max(all.H.not.in.years))
  
  cumsum.numer <- t(apply(numer,c(1),cumsum))
  cumsum.denum <- t(apply(denum,c(1),cumsum))
  
  S <- Model$q*(1-Model$RR)*(cumsum.numer/cumsum.denum)
  
  return(S)
}


compute.model.implied.itraxx <- function(X.complete,v,
                                         Model,DATASET,du = 0.0001){
  cds.p.fast.Q <- cds.pricing.fast(Model,
                                   max(DATASET$H.in.years.4.itraxx.indices),
                                   X.complete,v,du)
  cds.fitted <- cbind(cds.p.fast.Q[,DATASET$q*DATASET$H.in.years.4.itraxx.indices])
  return(cds.fitted)
}


index.pricing.fast <- function(Model,max.H,X,v,du = 0.0001){
  # v is the vector specifiying how N* is obtained:
  #      that is, we have N* = v'N.
  # I* is the total number of entities (i.e. we should have N*<=I*).
  # q is the time frequency of the model. For instance, for a monthly model, q=12.
  # Therefore, it is implicitly assumed that there is always one payment per period.
  # max.H is expressed in years. Hence qH is the maximum number of payments
  #      associated with the premium legs.
  # CDS premiums are expressed in annualized terms (s.t. S/q is paid on every period).
  # CDS premiums are computed for each of the J sectors.
  
  I.star <- sum(v * Model$I)
  
  T <- dim(X$F)[1]
  n.F <- dim(X$F)[2] # Number of factors F
  J <- dim(X$N)[2] # number of sectors
  
  all.H.not.in.years <- matrix(1:(Model$q*max.H),ncol=1)
  
  # Compute E(sum(N_k.I{N_k<I_j}))
  
  a.u   <- list(A = matrix(0,n.F,1),
                B = matrix(du*v,ncol=1),
                C = matrix(0,J,1),
                D = matrix(0,1,1))
  a.u_1 <- list(A = matrix(0,n.F,1),
                B = matrix(0,J,1),
                C = matrix(du*v,ncol=1),
                D = matrix(0,1,1))
  a.0   <- list(A = matrix(0,n.F,1),
                B = matrix(0,J,1),
                C = matrix(0,J,1),
                D = matrix(0,1,1))
  
  p.0   <- pp(Model,a.0,matrix(all.H.not.in.years,ncol=1),X)
  p.u   <- pp(Model,a.u,matrix(all.H.not.in.years,ncol=1),X)
  p.u_1 <- pp(Model,a.u_1,matrix(all.H.not.in.years,ncol=1),X)
  
  numer <- matrix((p.u - p.u_1)/du,
                  T,max(all.H.not.in.years))
  denum <- matrix(I.star*p.0 - (p.u - p.0)/du,
                  T,max(all.H.not.in.years))
  
  cumsum.numer <- t(apply(numer,c(1),cumsum))
  cumsum.denum <- t(apply(denum,c(1),cumsum))
  
  S <- Model$q*(1-Model$RR)*(cumsum.numer/cumsum.denum)
  
  return(S)
}



Tranche.pricing <- function(Model,max.H,X,v,vec.a.b,
                                U=NaN,du = 0.0001,
                                min.log.v=-8,max.v=10000,step=.01){
  # v is the vector specifiying how N* is obtained:
  #      that is, we have N* = v'N.
  # I* is the total number of entities (i.e. we should have N*<=I*).
  # q is the time frequency of the model. For instance, for a monthly model, q=12.
  # Therefore, it is implicitly assumed that there is always one payment per period.
  # max.H is expressed in years. Hence qH is the maximum number of payments
  #      associated with the premium legs.
  # CDS premiums are expressed in annualized terms (s.t. S/q is paid on every period).
  # CDS premiums are computed for each of the J sectors.
  # vec.a.b determines the attachment and detachment points:
  #      if vec.a.b = [.03,.06] (say) then only tranches 0%-3% and 3%-6% is priced
  #      if vec.a.b = [.03,.06,.20] (say) then three tranches are priced: 0%-3% 3%-6% and 6%-20%.
  # U is the matrix of upfront payments, expressed as a fraction of notional.
  #      its dimension is (with obvious notations): nb.matur * nb.of.tranches matrix
  
  I.star <- sum(v * Model$I)
  
  T <- dim(X$F)[1]
  n.F <- dim(X$F)[2] # Number of factors F
  J <- dim(X$N)[2] # number of sectors
  
  all.H.not.in.years <- matrix(1:(Model$q*max.H),ncol=1)
  
  vec.a.b.bar <- vec.a.b * I.star/(1-Model$RR)
  if(is.na(U)){
    vec.U.bar <- 0*vec.a.b.bar
  }else{
    vec.U.bar <- U * I.star/(1-Model$RR)
  }
  
  a.u    <- list(A = matrix(0,n.F,1),
                 B = matrix(du*v,ncol=1),
                 C = matrix(0,J,1),
                 D = matrix(0,1,1))
  a.u_01 <- list(A = matrix(0,n.F,1),
                 B = matrix(du*v,ncol=1),
                 C = matrix(-du*v,ncol=1),
                 D = matrix(0,1,1))
  a.0    <- list(A = matrix(0,n.F,1),
                 B = matrix(0,J,1),
                 C = matrix(0,J,1),
                 D = matrix(0,1,1))
  b      <- list(A = matrix(0,n.F,1),
                 B = matrix(v,ncol=1),
                 C = matrix(0,J,1),
                 D = matrix(0,1,1))
  
  S.a.b <- array(NaN,c(T,Model$q*max.H,length(vec.a.b)))
  
  opt_prices.u.4.all.a.b <-
    g(Model,a.u,b,vec.a.b.bar,all.H.not.in.years,X,min.log.v,max.v,step)
  
  opt_prices.u_01.4.all.a.b <-
    g(Model,a.u_01,b,vec.a.b.bar,all.H.not.in.years,X,min.log.v,max.v,step)
  
  opt_prices.0.4.all.a.b <-
    g(Model,a.0,b,vec.a.b.bar,all.H.not.in.years,X,min.log.v,max.v,step)
  
  
  count <- 0
  for(a.or.b in vec.a.b.bar){
    
    count <- count + 1

    if(count==1){
      a.bar <- 0
    }else{
      a.bar <- vec.a.b.bar[count-1]
    }
    b.bar <- vec.a.b.bar[count]
    
    opt_prices.u.b <- opt_prices.u.4.all.a.b[,count,]
    if(count == 1){
      opt_prices.u.a <- 0*opt_prices.u.4.all.a.b[,count,]
    }else{
      opt_prices.u.a <- opt_prices.u.4.all.a.b[,count-1,]
    }
    
    opt_prices.u_01.b <- opt_prices.u_01.4.all.a.b[,count,]
    if(count == 1){
      opt_prices.u_01.a <- 0*opt_prices.u_01.4.all.a.b[,count,]
    }else{
      opt_prices.u_01.a <- opt_prices.u_01.4.all.a.b[,count-1,]
    }
    
    opt_prices.0.b <- opt_prices.0.4.all.a.b[,count,]
    if(count == 1){
      opt_prices.0.a <- 0*opt_prices.0.4.all.a.b[,count,]
    }else{
      opt_prices.0.a <- opt_prices.0.4.all.a.b[,count-1,]
    }
    
    numer <- matrix(((opt_prices.u_01.b - opt_prices.0.b) -
                       (opt_prices.u_01.a - opt_prices.0.a))/du,
                    T,max(all.H.not.in.years))
    denum <- matrix(
      (b.bar - a.bar)*opt_prices.0.a+
        b.bar*(opt_prices.0.b - opt_prices.0.a)-
        ((opt_prices.u.b - opt_prices.0.b)  -
           (opt_prices.u.a - opt_prices.0.a))/du,
      T,max(all.H.not.in.years))
    
    cumsum.numer <- t(apply(numer,c(1),cumsum))
    cumsum.denum <- t(apply(denum,c(1),cumsum))
    
    S.a.b[,,count] <- Model$q*cumsum.numer/cumsum.denum
    
  }
  
  return(
    list(S.a.b=S.a.b,
         opt_prices.u.4.all.a.b=opt_prices.u.4.all.a.b,
         opt_prices.u_01.4.all.a.b=opt_prices.u_01.4.all.a.b,
         opt_prices.0.4.all.a.b=opt_prices.0.4.all.a.b)
  )
}


Equity.option.pricing <- function(Model,H,X,v,
                                      K.over.P,min.log.v=-10,max.v=10000,step=.01){
  # T is the number of periods (= # lines of X)
  # K is the matrix of Strikes; it is of dimension T * 1, it is used for all maturities.
  # H is a vector (matrix format) of maturities, expressed in years,
  #    Hence, expressed in number of periods, the maturities are of the form qH
  # This function prices Calls and Puts.
  
  T <- nrow(X$F)
  nb_matur <- max(dim(H))
  
  max.x <- log(max.v)
  v <- matrix(exp(seq(min.log.v,max.x,by=step)),nrow=1)
  dim.v <- length(v)
  nv = matrix(1,1,dim.v)
  extended.v <- cbind(0,v,max.v)
  dim.ext.v <- dim.v + 2
  weights <- matrix(.5*(extended.v[2:(dim.ext.v-1)]-extended.v[1:(dim.ext.v-2)])+
                      .5*(extended.v[3:dim.ext.v]-extended.v[2:(dim.ext.v-1)]),nrow=1)
  
  v3d = array(1,c(1,1,nb_matur))%x%(matrix(1,T,1)%*%v)
  
  K.over.P.3d <- array(log(K.over.P),c(T,ncol(v),nb_matur))
  
  AUX <- varphi(Model,
                Model$q*H,# expressed in number of periods
                X,a=c(0,1))
  AUX.1 <- AUX[,2,]
  AUX.0 <- AUX[,1,]
  
  integral <- Im(varphi(Model,
                        Model$q*H,# expressed in number of periods
                        X,a=matrix(1+1i*v,nrow=1)) *
                   exp(-1i*K.over.P.3d*v3d) )/v3d
  
  integral = array(
    apply(integral,c(1,3),function(x){x%*%t(weights)}),
    c(T,1,nb_matur))
  integral <- array(integral,c(T,1,nb_matur))
  integral.1 <- .5*AUX.1 - 1/pi*matrix(integral,T,nb_matur)
  
  integral <- Im(varphi(Model,
                        Model$q*H,# expressed in number of periods
                        X,a=matrix(0+1i*v,nrow=1)) *
                   exp(-1i*K.over.P.3d*v3d) )/v3d
  
  integral = array(
    apply(integral,c(1,3),function(x){x%*%t(weights)}),
    c(T,1,nb_matur))
  integral <- array(integral,c(T,1,nb_matur))
  integral.0 <- .5*AUX.0 - 1/pi*matrix(integral,T,nb_matur)
  
  Call <- AUX.1 - integral.1 - matrix(K.over.P,T,nb_matur) *
    (AUX.0 - integral.0)
  
  Put <- matrix(K.over.P,T,nb_matur) * integral.0 - integral.1
  
  return(list(
    Call=Call,
    Put=Put,
    first = AUX.1 - integral.1,
    second = AUX.0 - integral.0,
    AUX.1 = AUX.1,
    AUX.0 = AUX.0,
    integral.0 = integral.0,
    integral.1 = integral.1
  ))
}


compute.max.Sharpe.ratio <- function(Model.solved){
  
  Model.aux <- Model.solved
  Model.aux$Delta <- NULL
  Model.aux$Eta <- NULL
  
  u1 <- list(
    A = matrix(Model.solved$mu.m.1$A + Model.solved$mu.m.2$A,ncol=1),
    B = matrix(Model.solved$mu.m.1$B + Model.solved$mu.m.2$B,ncol=1),
    C = matrix(Model.solved$mu.m.1$C + Model.solved$mu.m.2$C,ncol=1),
    D = 0)
  u2 <- list(
    A = matrix(Model.solved$mu.m.1$A,ncol=1),
    B = matrix(Model.solved$mu.m.1$B,ncol=1),
    C = matrix(Model.solved$mu.m.1$C,ncol=1),
    D = 0)
  aux1 <- ABCDh(u=u1,  H=matrix(Model.solved$q,1,1),Model.aux,u2=u2)
  
  u1 <- list(
    A = 2*matrix(Model.solved$mu.m.1$A + Model.solved$mu.m.2$A,ncol=1),
    B = 2*matrix(Model.solved$mu.m.1$B + Model.solved$mu.m.2$B,ncol=1),
    C = 2*matrix(Model.solved$mu.m.1$C + Model.solved$mu.m.2$C,ncol=1),
    D = 0)
  u2 <- list(
    A = 2*matrix(Model.solved$mu.m.1$A,ncol=1),
    B = 2*matrix(Model.solved$mu.m.1$B,ncol=1),
    C = 2*matrix(Model.solved$mu.m.1$C,ncol=1),
    D = 0)
  aux2 <- ABCDh(u=u1,H=matrix(Model.solved$q,1,1),Model.aux,u2=u2)
  
  moments <- compute.moments(Model.solved)
  
  X.mean <- list(
    A = moments$unc.mean[1:n.F],
    B = moments$unc.mean[(n.F+1):(n.F+J)],
    C = matrix(0,J)
  )
  
  Max.SR.X.mean <- sqrt(
    exp( matrix(aux2$A,nrow=1)%*%X.mean$A +
           matrix(aux2$B,nrow=1)%*%X.mean$B +
           matrix(aux2$C,nrow=1)%*%X.mean$C + c(aux2$D) ) -
      exp( 2*matrix(aux1$A,nrow=1)%*%X.mean$A +
             2*matrix(aux1$B,nrow=1)%*%X.mean$B +
             2*matrix(aux1$C,nrow=1)%*%X.mean$C + 2*c(aux1$D) )
  )/ exp( matrix(aux1$A,nrow=1)%*%X.mean$A +
            matrix(aux1$B,nrow=1)%*%X.mean$B +
            matrix(aux1$C,nrow=1)%*%X.mean$C + c(aux1$D))
  
  return(Max.SR.X.mean)
}


compute.exp.stock.returns <- function(Model.solved){
  
  Model.aux <- Model.solved
  Model.aux$Delta <- NULL
  Model.aux$Eta <- NULL
  
  u1 <- list(
    A = matrix(Model.solved$A.1$A * (Model.solved$kappa.1 - 1) + Model.solved$Mu.d$A,ncol=1),
    B = matrix(Model.solved$A.1$B * (Model.solved$kappa.1 - 1) + Model.solved$Mu.d$B,ncol=1),
    C = matrix(Model.solved$A.1$C * (Model.solved$kappa.1 - 1) + Model.solved$Mu.d$C,ncol=1),
    D = 0)
  u2 <- list(
    A = matrix(Model.solved$A.1$A * Model.solved$kappa.1 + Model.solved$Mu.d$A,ncol=1),
    B = matrix(Model.solved$A.1$B * Model.solved$kappa.1 + Model.solved$Mu.d$B,ncol=1),
    C = matrix(Model.solved$A.1$C * Model.solved$kappa.1 + Model.solved$Mu.d$C,ncol=1),
    D = 0)
  aux1 <- ABCDh(u=u1,  H=matrix(Model.solved$q,1,1),Model.aux,u2=u2)
  
  moments <- compute.moments(Model.solved)
  
  X.mean <- list(
    A = moments$unc.mean[1:n.F],
    B = moments$unc.mean[(n.F+1):(n.F+J)],
    C = matrix(0,J)
  )
  
  mean.return <- 
    matrix(c(aux1$A) - Model.solved$A.1$A,nrow=1)%*%X.mean$A +
    matrix(c(aux1$B) - Model.solved$A.1$B,nrow=1)%*%X.mean$B +
    matrix(c(aux1$C) - Model.solved$A.1$C,nrow=1)%*%X.mean$C + 
    Model.solved$q * (   Model.solved$kappa.0 +
                           Model.solved$A.0 * (Model.solved$kappa.1 - 1) +
                           Model.solved$Mu.d$D)
  
  aux.rf.yd <- Price.RF.bonds(Model.solved,matrix(Model.solved$q,1,1))
  mean.rf.yd <- -(matrix(aux.rf.yd$A,nrow=1)%*%X.mean$A +
                    matrix(aux.rf.yd$B,nrow=1)%*%X.mean$B +
                    matrix(aux.rf.yd$C,nrow=1)%*%X.mean$C + c(aux.rf.yd$D))
  
  return(list(mean.return = mean.return,
              mean.rf.yd = mean.rf.yd,
              X = 0
  ))
}


