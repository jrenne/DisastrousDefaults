# =======================================
# DISASTROUS DEFAULTS
# =======================================
# Christian Gouriéroux, Alain Monfort,
# Jean-Paul Renne and Sarah Mouabbi
# Contact: jean-paul.renne@unil.ch
# =======================================
# This script contains procedures
# aimed at generating the different outputs
# shown in the paper.
# =======================================


round.fixed.length <- function(X,n){
  # This procedure is used in the automatic creation of Latex tables
  # x is numeric. The output is a string with n numbers after ".", even if they are 0s.
  signX <- sign(X)
  if(signX>=0){
    signX <- NULL
  }else{
    signX <- "-"
  }
  x <- abs(X)
  rounded.abs.X <- round(x,n)
  string.rounded.abs.X <-toString(rounded.abs.X)
  nb.char.string.rounded.abs.X <- nchar(string.rounded.abs.X)
  
  integer.rounded.abs.X <- toString(as.integer(rounded.abs.X))
  nb.char.integer.rounded.abs.X <- nchar(integer.rounded.abs.X)
  
  string.x <- paste(signX,integer.rounded.abs.X,sep="")
  
  if(n>0){
    string.x <- paste(string.x,".",sep="")
    nb.of.available.decimal <- nb.char.string.rounded.abs.X - nb.char.integer.rounded.abs.X - 1
    for(i in 1:n){
      if(i<=nb.of.available.decimal){
        string.x <- paste(string.x,str_sub(string.rounded.abs.X,
                                           nb.char.integer.rounded.abs.X+1+i,
                                           nb.char.integer.rounded.abs.X+1+i),sep="")
      }else{
        string.x <- paste(string.x,"0",sep="")
      }
    }
  }
  return(string.x)
}



compute.proba.NB.def <- function(Model.solved,res.KF){
  y      <- res.KF$r_smooth[,2]
  beta   <- Model.solved$beta.matrix[5,1]
  c.coef <- Model.solved$c.matrix[1,1]
  
  Exp.n.def <- sum(beta*y)
  
  # Compute proba of 0 default:
  P0 <- prod(exp(-beta*y))
  
  # Compute proba of 1 default:
  P1 <- 0
  for(t in 1:length(y)){
    if(t < length(y)){
      P1t <-
        exp(-beta*y[t])*(beta*y[t])* # default on this date
        exp(-(beta*y[t+1]+c.coef * 1))* # no default on next date
        prod(exp(-beta*y[-c(t,t+1)])) # no default on next dates (excluding t and t+1)
    }else{
      P1t <- exp(-beta*y[t])*(beta*y[t])*prod(exp(-beta*y[-t]))
    }
    P1 <- P1 + P1t
  }
  
  # Compute proba of 2 defaults:
  P2.same <- 0 # proba that 2 defaults on one same date
  P2.diff <- 0 # proba that 2 defaults on two different dates
  for(t in 1:length(y)){
    
    # 2 defaults on date t:
    if(t < length(y)){
      P2.same.t <- exp(-beta*y[t])*(beta*y[t])^2/2* # proba of 2 defaults on date t
        exp(-(beta*y[t+1]+c.coef * 2))* # proba of no default on date t+1
        prod(exp(-beta*y[-c(t,t+1)]))
    }else{
      P2.same.t <- exp(-beta*y[t])*(beta*y[t])^2/2* # proba of 2 defaults on date T
        prod(exp(-beta*y[-t])) 
    }
    
    P2.same <- P2.same + P2.same.t
    
    # one default on date t, one default on date s (> t):
    if(t<length(y)){
      # case of defaults on date t and t+1
      P2.diff.t.s <-
        exp(-beta*y[t])*(beta*y[t])* # one default on date t
        exp(-(beta*y[t+1]+c.coef * 1))*(beta*y[t+1]+c.coef * 1)* # one default on date t+1
        prod(exp(-beta*y[-c(t,t+1)])) # no default on other dates
      P2.diff <- P2.diff + P2.diff.t.s
      
      if(t<(length(y)-1)){
        for(s in (t+2):length(y)){# excluding dates t and t+1
          s.and.t <- c(t,s)
          P2.diff.t.s <-
            exp(-beta*y[t])*(beta*y[t])* # default on date t
            exp(-(beta*y[t+1]+c.coef * 1))* # no default on date t+1
            exp(-beta*y[s])*(beta*y[s])* # default on date s
            ifelse(s==length(y),
                   prod(exp(-beta*y[-s.and.t])), # s is the last date of the sample
                   prod(exp(-beta*y[-s.and.t]))) * exp(- c.coef * 1) # s is not the last date of the sample
          P2.diff <- P2.diff + P2.diff.t.s
        }
      }
    }
  }
  P2 <- P2.same + P2.diff
  
  return(list(
    Exp.n.def = Exp.n.def,
    P0 = P0,
    P1 = P1,
    P2 = P2
  ))
}






make.IRFs <- function(Model.solved,nb.sim,shock){
  
  moments <- compute.moments(Model.solved)
  
  # Compute IRFs for state variables:
  x <- shock
  all.res <- matrix(shock,ncol=1)
  for(i in 1:nb.sim){
    x <- moments$PHI %*% x
    all.res <- cbind(all.res,x)
  }
  
  loadings.Delta.c <- c(Model.solved$Mu.c$A,Model.solved$Mu.c$B)
  loadings.g.d     <- c(Model.solved$Mu.d$A,Model.solved$Mu.d$B)
  loadings.z       <- c(Model.solved$A.1$A,Model.solved$A.1$B)
  
  impact.on.cond.var    <- moments$BETA %*% all.res
  
  impact.on.Delta.c        <- matrix(loadings.Delta.c,nrow=1) %*% all.res
  impact.on.cumsum.Delta.c <- cumsum(impact.on.Delta.c)
  impact.on.var.Delta.c <- (matrix(loadings.Delta.c,nrow=1) %x% matrix(loadings.Delta.c,nrow=1)) %*%
    impact.on.cond.var
  
  impact.on.g.d         <- matrix(loadings.g.d,nrow=1) %*% all.res
  impact.on.stock.index <- cumsum(impact.on.g.d) + matrix(loadings.z,nrow=1) %*% all.res
  impact.on.var.r_s     <- (matrix(loadings.g.d+loadings.z,nrow=1) %x% matrix(loadings.g.d+loadings.z,nrow=1)) %*%
    impact.on.cond.var
  
  return(list(
    all.res                  = all.res,
    impact.on.Delta.c        = impact.on.Delta.c,
    impact.on.cumsum.Delta.c = impact.on.cumsum.Delta.c,
    impact.on.var.Delta.c    = impact.on.var.Delta.c,
    impact.on.g.d            = impact.on.g.d,
    impact.on.stock.index    = impact.on.stock.index,
    impact.on.var.r_s        = impact.on.var.r_s,
    impact.on.stdv.var.Delta.c = sqrt(impact.on.var.Delta.c),
    impact.on.stdv.var.r_s     = sqrt(impact.on.var.r_s)
  ))
}


compute.various.moments <- function(Model,DATASET,targets,
                                    du = 0.0001){
  # This function computes static moments

  n.F <- dim(Model$zeta.F)[1]
  J   <- dim(Model$zeta.n)[1]

  moments <- compute.moments(Model) # unconditional moments based associated with Model

  v <- c(1,rep(0,J-1))

  X <- list(
    F = matrix(moments$unc.mean[1:n.F],nrow=1),
    N = matrix(moments$unc.mean[(n.F+1):(n.F+J)],1,J),
    N_1 = matrix(0,1,J)
  )

  max.H <- max(c(targets$maturities.4.slope,
                 targets$maturity.4.ratio)) # in cds pricing formulas, max.H is expressed in years.

  cds.p.fast.Q <- cds.pricing.fast(Model,max.H,X,v,du)

  model.implied.level.cds <- cds.p.fast.Q[DATASET$q*targets$maturity.4.level.cds]

  model.implied.itraxx.short <- cds.p.fast.Q[DATASET$q*targets$maturities.4.slope[1]]
  model.implied.itraxx.long  <- cds.p.fast.Q[DATASET$q*targets$maturities.4.slope[2]]

  Model.P <- Model
  Model.P$Delta <- NULL
  cds.p.fast.P <- cds.pricing.fast(Model.P,max.H,X,v,du)

  model.implied.ratio <- cds.p.fast.Q[DATASET$q*targets$maturity.4.ratio]/
    cds.p.fast.P[DATASET$q*targets$maturity.4.ratio]

  model.implied.slope <- cds.p.fast.Q[DATASET$q*targets$maturities.4.slope[2]] -
    cds.p.fast.Q[DATASET$q*targets$maturities.4.slope[1]]

  cum.delta.N <- 0
  x <- c(moments$unc.mean[1:n.F],
         moments$unc.mean[(n.F+1):(n.F+J)])
  for(i in 1:DATASET$q*targets$horiz.default.rate){
    x <- moments$MU + moments$PHI %*% x
    cum.delta.N <- cum.delta.N + x[n.F+1]
  }
  model.implied.default.rate <- cum.delta.N/DATASET$I.iTraxx

  model.implied.avg.r <- DATASET$q*(Model$Eta$D +
                                      sum(c(Model$Eta$A,Model$Eta$B)*moments$unc.mean)
  )
  model.implied.stdv.r <- sqrt(
    matrix(c(Model$Eta$A,Model$Eta$B),nrow=1) %*% moments$unc.var %*%
      matrix(c(Model$Eta$A,Model$Eta$B),ncol=1)
  )

  return(list(
    model.implied.avg.r        = model.implied.avg.r,
    model.implied.stdv.r       = model.implied.stdv.r,
    model.implied.ratio        = model.implied.ratio,
    model.implied.default.rate = model.implied.default.rate,
    model.implied.level.cds    = model.implied.level.cds,
    model.implied.slope        = model.implied.slope,
    model.implied.itraxx.short = model.implied.itraxx.short,
    model.implied.itraxx.long  = model.implied.itraxx.long
  ))
}

