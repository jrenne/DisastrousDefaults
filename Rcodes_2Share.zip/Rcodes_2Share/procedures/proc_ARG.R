# =======================================
# DISASTROUS DEFAULTS
# =======================================
# Christian Gouriéroux, Alain Monfort,
# Jean-Paul Renne and Sarah Mouabbi
# Contact: jean-paul.renne@unil.ch
# =======================================
# This script contains procedures
# associated with the econometric processes
# considered in the modeling approach
# =======================================



simul_defaults <- function(FF, beta_j, c_j, gamma_j){
  # Warning: F is exogenous
  nb_periods = nrow(FF)
  J = nrow(c_j)
  # Initialization:
  N   = matrix(0,nb_periods,J)
  N_1 = matrix(0,nb_periods,J)
  
  for (i in 3:nb_periods){
    N_1[i,] = N[i-1,]
    poisson_param = FF[i,]%*%beta_j + (N[i-1,]-N_1[i-2,])%*%c_j + gamma_j
    for(j in 1:J){
      N[i,j] = N[i-1,j] + rpois(1,poisson_param[j])
    } 
  }
  return(list(N=N,N_1=N_1))
}


simul_VARG <- function(n,mu,Phi,nu){
  # Important note:
  # Let's denote by z_{i,t} the i^th entry of the simulated vector z_t.
  # We have:
  # z_{i,t} | past values ~ gamma_{nu_i}(phi_i'z_t,mu_i).
  # If the dimension of mu is q x 1, then Phi is a q x q matrix 
  #    whose i^th column is phi_i.
  q <- length(mu)
  mu_z <- mu*nu
  Phi_z <- (matrix(mu,ncol=1) %*% matrix(1,1,q)) * t(Phi)
  mean_z = solve(diag(q) - Phi_z) %*% (nu*mu)
  Gamma_z0 <- mu*mu*nu
  Gamma_z1 <- 2*(matrix(mu*mu,ncol=1)%*%matrix(1,1,q)) * t(Phi)
  var_z <- solve(diag(q*q) - Phi_z %x% Phi_z) %*% c(diag(c(matrix(Gamma_z0,ncol=1) + Gamma_z1 %*% mean_z)))
  var_z <- matrix(var_z,q,q)
  
  ts = matrix(0,n,q)
  ts[1,] = mean_z
  for(i in 2:n){
    Z = rpois(n=q,lambda=t(Phi) %*% ts[i-1,])
    ts[i,] = rgamma(n=q,scale=mu,shape=nu+Z)
  }
  res <- list(mean=mean_z, var=var_z, ts=ts)
  return(res)
}

psi.z <- function(u,mu,Phi,nu){
  # returns alpha(u) and beta(u) that are such that, for all value of z_t:
  # E_t(exp(u.z_{t+1})) = exp( alpha(u) + beta(u)'z_t )
  # u is a matrix of dimension q x n.u, where q is the dimension of z
  q <- length(mu)
  n.u <- dim(u)[2]
  mu.extended <- matrix(mu,q,n.u)
  alpha.u <- - matrix(nu,nrow=1) %*% log(1 - mu.extended*u)
  beta.u  <- Phi %*% ((u * mu.extended)/(1 - (u * mu.extended)))
  return(list(alpha.u=alpha.u,
              beta.u=beta.u))
}

aa.bb.cc.dd <- function(w,Model){
  # This function computes the conditional LT of F_{t+1}
  n.F <- length(w)
  
  zeta.0 <- Model$zeta.0
  zeta.n <- Model$zeta.n
  zeta.F <- Model$zeta.F
  mu     <- Model$mu
  nu     <- Model$nu
  
  aa <- zeta.F %*% ((w * mu)/(1 - (w * mu)))
  bb <- zeta.n %*% ((w * mu)/(1 - (w * mu)))
  cc <- -bb
  
  if(sum(is.na(nu))>0){
    dd <- NaN*matrix(zeta.0,nrow=1) %*% ((w * mu)/(1 - (w * mu)))
  }else{
    if(sum(nu>0)>0){
      dd <- matrix(zeta.0,nrow=1) %*% ((w * mu)/(1 - (w * mu))) - 
        matrix(nu,nrow=1) %*% log(1 - (w * mu))
    }else{
      dd <- matrix(zeta.0,nrow=1) %*% ((w * mu)/(1 - (w * mu)))
    }
  }
  
  return(list(aa=aa,bb=bb,cc=cc,dd=dd))
}

compute.moments <- function(Model){
  # This function computes the unconditional moments associated with a given model (F_t,n_t)
  # It also provides the vector MU and the matrix PHI that are such that
  #         E_t([F_{t+1}',n_{t+1}']') = MU + PHI [F_{t}',n_{t}']'
  # and ALPHA, BETA that are such that:
  #         vec{Var_t([F_{t+1}',n_{t+1}']')} = ALPHA + BETA [F_{t}',n_{t}']'
  
  zeta.0 <- Model$zeta.0
  zeta.n <- Model$zeta.n
  zeta.F <- Model$zeta.F
  mu     <- Model$mu
  nu     <- Model$nu
  
  beta.matrix <- Model$beta.matrix
  c.matrix    <- Model$c.matrix
  gamma.vec   <- Model$gamma.vec
  
  J   <- dim(Model$c.matrix)[1] # Number of segments
  n.F <- dim(Model$beta.matrix)[1] # number of Factors (dimension of F)
  
  mu.F   <- mu * (zeta.0 + nu)
  Phi.FF <- (matrix(mu,ncol=1)%*%rep(1,n.F)) * t(zeta.F)
  Phi.Fn <- (matrix(mu,ncol=1)%*%rep(1,J)) * t(zeta.n)
  
  mu.F.var   <- mu * mu * (nu + 2 * zeta.0)
  Phi.FF.var <- 2 * diag(mu*mu) %*% t(zeta.F)
  Phi.Fn.var <- 2 * diag(mu*mu) %*% t(zeta.n)
  
  MU <- c(mu.F,
              gamma.vec + t(beta.matrix) %*% mu.F)
  
  PHI <- rbind(
    cbind(Phi.FF,Phi.Fn),
    cbind( t(beta.matrix)%*%Phi.FF , t(beta.matrix)%*%Phi.Fn + t(c.matrix))
  )
  
  unc.mean <- solve(diag(n.F+J) - PHI) %*% MU
  
  S.nF <- make.Sn(n.F)
  S.J  <- make.Sn(J)
  I.nF <- diag(n.F)
  
  mat.aux.1 <- rbind(matrix(0,n.F,J),
                     diag(J))
  mat.aux.1 <- mat.aux.1 %x% mat.aux.1
  mat.aux.2 <- rbind(diag(n.F),
                     t(beta.matrix))
  mat.aux.2 <- mat.aux.2 %x% mat.aux.2
  
  ALPHA <- mat.aux.1 %*% S.J %*% (t(beta.matrix) %*% mu.F + gamma.vec) +
    mat.aux.2 %*% S.nF %*% mu.F.var

  BETA.F <- mat.aux.1 %*% S.J %*% t(beta.matrix) %*% Phi.FF +
    mat.aux.2 %*% S.nF %*% Phi.FF.var
  
  BETA.n <- mat.aux.1 %*% S.J %*% (t(beta.matrix) %*% Phi.Fn + t(c.matrix)) +
    mat.aux.2 %*% S.nF %*% Phi.Fn.var
  
  BETA <- cbind(BETA.F,BETA.n)
  
  unc.var <- matrix(
    solve(diag((n.F+J)^2) - PHI %x% PHI) %*%
      (ALPHA + BETA %*% unc.mean),
    n.F+J,n.F+J
  )
  
  return(list(
    MU=MU,PHI=PHI,unc.mean=unc.mean,unc.var=unc.var,
    ALPHA=ALPHA,BETA=BETA)
  )
}

simul.Model <- function(Model,nb.sim,ini.F=NaN,ini.N_1=NaN,ini.N_2=NaN){
  # In this model, the components of F are independent and Gamma_0 distributed
  #     conditionally on Omega_t
  # See paper for the notations
  
  zeta.0 <- Model$zeta.0
  zeta.n <- Model$zeta.n
  zeta.F <- Model$zeta.F
  mu     <- Model$mu
  nu     <- Model$nu
  
  beta.matrix <- Model$beta.matrix
  c.matrix <- Model$c.matrix
  gamma.vec <- Model$gamma.vec
  
  J <- dim(Model$c.matrix)[1] # Number of segments
  n.F <- dim(Model$beta.matrix)[1] # number of Factors (dimension of F)
  
  if(is.na(sum(ini.N_1))){
    ini.N_1.used <- rep(0,J)
  }else{
    ini.N_1.used <- ini.N_1
  }
  
  if(is.na(sum(ini.N_2))){
    ini.N_2.used <- rep(0,J)
  }else{
    ini.N_2.used <- ini.N_2
  }
  
  if(is.na(sum(ini.F))){
    ini.F.used <- rep(0,n.F)
  }else{
    ini.F.used <- ini.F
  }
  
  F.simul <- matrix(ini.F.used,nrow=1)
  N_1.simul <- matrix(ini.N_1.used,nrow=1)
  N.simul <- matrix(0,1,J)
  
  poisson_param.N <- t(beta.matrix) %*% c(F.simul[1,]) +
    t(c.matrix) %*% c(ini.N_1.used-ini.N_2.used) + gamma.vec
  
  N.simul[1,] <- N_1.simul[1,] + rpois(J,poisson_param.N)
  
  for(t in 2:nb.sim){
    N_1.simul <- rbind(N_1.simul,N.simul[t-1,])
    
    poisson_param.F = t(zeta.F) %*% c(F.simul[t-1,]) +
      t(zeta.n) %*% c(N.simul[t-1,]-N_1.simul[t-1,]) + zeta.0
    
    Z = rpois(n=n.F,poisson_param.F)
    F.simul <- rbind(F.simul,rgamma(n=n.F,scale=mu,shape=nu + Z))
    
    poisson_param.N = t(beta.matrix) %*% c(F.simul[t,]) +
      t(c.matrix) %*% c(N.simul[t-1,]-N_1.simul[t-1,]) + gamma.vec
    
    N.simul <- rbind(N.simul,
                     N_1.simul[t,] + rpois(J,poisson_param.N))
  }
  
  return(list(
    F = F.simul,
    N = N.simul,
    N_1 = N_1.simul
  ))
}


make.Sn <- function(n){
  S.n <- 0
  I <- diag(n)
  for(i in 1:n){
    e.i <- matrix(I[,i],ncol=1)
    S.n <- S.n + matrix(e.i %*% t(e.i),ncol=1) %*% t(e.i)
  }
  return(S.n)
}




