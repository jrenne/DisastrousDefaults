# =======================================
# DISASTROUS DEFAULTS
# =======================================
# Christian Gouriéroux, Alain Monfort,
# Jean-Paul Renne and Sarah Mouabbi
# Contact: jean-paul.renne@unil.ch
# =======================================
# This script contains the Kalman
# filter and smoother procedures.
# =======================================



# State-space model specifications: ------------
# Measurement equations:
# y_t   = mu_t+G*rho_t+M*eps_t
# Transition equations:
# rho_t = nu_t + H*rho_t-1 +N*xi_t
# Y_t is a T*ny-dimensional vector
# nu_t and mu_t depend on past only (predetermined at date t)

# ----------------------------------------------
# Outputs:
# .$r   filtered state variables
# .$S  SIGMA t/t T*(nr*nr) covariance matrix of filtered variables
# ----------------------------------------------


Kalman_filter <- function(Y_t,nu_t,H,N,mu_t,G,M,Sigma_0,rho_0,indic_pos=0,
                          values.factors.EKF = NaN){
  
  # Number of observed variables: 
  ny = NCOL(Y_t)
  # Number of unobs. variables:
  nr = NCOL(G)
  # Number of time periods:
  T = NROW(Y_t)
  
  # loglik.vector will contain the vector of date-specific log-likelihood
  loglik.vector <- NULL
  
  #Initilize output matrices:
  rho_tt    = matrix(0,T,nr)	
  rho_tp1_t = matrix(0,T,nr)	
  y_tp1_t   = matrix(0,T,ny)	
  
  Sigma_tt    = matrix(0,T,nr*nr)
  Sigma_tp1_t = matrix(0,T,nr*nr)
  Omega_tt    = matrix(0,T,ny*ny)
  Omega_tp1_t = matrix(0,T,ny*ny)
  
  fitted.obs <- matrix(NaN,T,ny)
  
  #Initilize log-Likelihood:
  logl = ny*T/2*log(2*pi)
  logl = 0
  
  
  #Kalman algorithm:	
  
  for (t in 1:T){
    
    # print(t)
    
    # =========================================
    # Forecasting step (between t-1 and t):
    if(t==1){
      rho_tp1_t[1,] = nu_t[1,] + t(H %*% rho_0)
      R = Rfunction(M,rho_0) #Rfunction defined below (measurement eq.)
      Q = Qfunction(N,rho_0,nr) #Qfunction defined below (transition eq.)
    } else {
      rho_tp1_t[t,] = nu_t[t,] + t(H %*% rho_tt[t-1,])
      R = Rfunction(M,rho_tt[t-1,])
      Q = Qfunction(N,rho_tt[t-1,],nr)
    }
    if(sum(indic_pos==1)>0){
      rho_tp1_t[t,indic_pos==1] = pmax(rho_tp1_t[t,indic_pos==1],0)
    }
    
    if(class(G)[1]=="array"){
      # look for closest state
      
      current.state <- rho_tp1_t[t,1:dim(values.factors.EKF)[2]]
      aux <- values.factors.EKF - t(matrix(c(current.state),
                                           dim(values.factors.EKF)[2],
                                           dim(values.factors.EKF)[1]))
      distance <- apply(abs(aux),1,sum)

      # compute weights based on distance:
      Weights <- 1/distance^2
      Weights <- Weights/sum(Weights)
      
      array.Weights <- array(Weights %x% rep(1,dim(G)[1]*dim(G)[2]),dim(G))
      G.aux <- apply(G*array.Weights,c(1,2),sum)
      
      array.Weights <- array(Weights %x% rep(1,dim(mu_t)[1]*dim(mu_t)[2]),dim(mu_t))
      mu_t.aux <- apply(mu_t*array.Weights,c(1,2),sum)
      
      G.aux.save <- G.aux
      y_tp1_t[t,] <- c(mu_t.aux) + c(G.aux %*% matrix(rho_tp1_t[t,],ncol=1))
      
    }else{
      mu_t.aux <- mu_t[t,]
      G.aux <- G
      G.aux.save <- G.aux
      y_tp1_t[t,] = mu_t.aux + t(G.aux %*% rho_tp1_t[t,])
    }
    
    
    if(t==1){
      aux_Sigma_tp1_t = Q + H %*% Sigma_0 %*% t(H)
    } else {
      aux_Sigma_tp1_t = Q + H %*% matrix(Sigma_tt[t-1,],nr,nr) %*% t(H)
    }
    
    Sigma_tp1_t[t,] = matrix( aux_Sigma_tp1_t ,1,nr*nr)
    omega           = R + G.aux %*% aux_Sigma_tp1_t %*% t(G.aux)
    Omega_tp1_t[t,] = matrix(omega,1,ny*ny)
    
    
    # =========================================
    # Updating step

    # Detect observed variables:
    vec.obs.indices <- which(!is.na(Y_t[t,])) # indices of observed variables
    ny.aux <- length(c(vec.obs.indices)) # number of observed variables
    # Resize matrices accordingly:
    G.aux <- matrix(G.aux[vec.obs.indices,],nrow=ny.aux)
    R.aux <- R[vec.obs.indices,]
    omega <- omega[vec.obs.indices,]
    if(class(R.aux)[1]=="numeric"){
      R.aux <- R.aux[vec.obs.indices]
      omega <- omega[vec.obs.indices]
    }else{
      R.aux <- R.aux[,vec.obs.indices]      
      omega <- omega[,vec.obs.indices]
    }
    R.aux <- matrix(R.aux,ny.aux,ny.aux)
    
    #Compute gain K:
    AUX <- R.aux + G.aux %*% aux_Sigma_tp1_t %*% t(G.aux)
    AUX[abs(AUX)==Inf] <- NaN
    if(sum(is.na(AUX))>0){
      return(list(loglik=-1000000000000))
    }
    res.eig <- eigen(AUX)
    if(sum(Re(res.eig$values)<=0)>0){
      print("ici")
      return(list(loglik=-1000000000000))
    }
    AUX <- matrix(0,length(res.eig$values),length(res.eig$values))
    diag(AUX) <- 1/res.eig$values
    Inv_mat <- (res.eig$vectors) %*% AUX %*% t(res.eig$vectors)
    
    K = aux_Sigma_tp1_t %*% t(G.aux) %*% Inv_mat
    
    lambda_t   = Y_t[t,] - y_tp1_t[t,]
    lambda_t <- matrix(lambda_t[vec.obs.indices],ncol=1)
    rho_tt[t,] = t( rho_tp1_t[t,] + K %*% lambda_t )
    if(sum(indic_pos==1)>0){
      rho_tt[t,indic_pos==1] = pmax(rho_tt[t,indic_pos==1],0)
    }
    Id         = diag(1,nrow=nr,ncol=nr)
    Sigma_tt[t,] = matrix( (Id - K %*% G.aux) %*% aux_Sigma_tp1_t,1,nr*nr)
    
    fitted.obs[t,] = mu_t.aux + G.aux.save %*% rho_tt[t,]

    #calcul de la log-vraisemblance
    if(length(c(omega))==1){
      det.omega <- omega
    }else{
      det.omega <- det(omega)
    }

    res.eig <- eigen(omega)
    AUX <- matrix(0,length(res.eig$values),length(res.eig$values))
    diag(AUX) <- 1/res.eig$values
    Inv_mat <- (res.eig$vectors) %*% AUX %*% t(res.eig$vectors)
    
    loglik.vector <- rbind(loglik.vector,
                           ny.aux/2*log(2*pi) - 1/2*(log(det.omega) +
                                                       t(lambda_t) %*% Inv_mat %*% lambda_t)
    )
    logl <- logl + loglik.vector[t]
    
  }
  
  output = list(r=rho_tt,Sigma_tt=Sigma_tt,loglik=logl,y_tp1_t=y_tp1_t,
                S_tp1_t=Sigma_tp1_t,r_tp1_t=rho_tp1_t,
                loglik.vector = loglik.vector,Omega_tp1_t=Omega_tp1_t,M=M,
                fitted.obs=fitted.obs)
  return(output)
}



Kalman_smoother <- function(Y_t,nu_t,H,N,mu_t,G,M,Sigma_0,rho_0,indic_pos=0,
                            values.factors.EKF = NaN){
  
  output_filter <- Kalman_filter(Y_t,nu_t,H,N,mu_t,G,M,Sigma_0,rho_0,indic_pos,
                                 values.factors.EKF)
  rho_tt        <- output_filter$r
  Sigma_tt      <- output_filter$Sigma_tt
  Sigma_tp1_t   <- output_filter$S_tp1_t
  rho_tp1_t     <- output_filter$r_tp1_t
  Omega_tp1_t   <- output_filter$Omega_tp1_t
  
  # Number of observed variables: 
  ny = NCOL(Y_t)
  # Number of unobs. variables:
  nr = NCOL(G)
  # Number of time periods:
  TT = NROW(Y_t)
  
  if(class(M)=="list"){
    M.aux <- M$sigmas
  }else{
    M.aux <- M
  }
  
  #Initilize output matrices:
  rho_tT        <- matrix(0,TT,nr)
  rho_tT[TT,]   <- rho_tt[TT,]
  Sigma_tT      <- matrix(0,TT,nr*nr)
  Sigma_tT[TT,] <- Sigma_tt[TT,]
  
  for(t in seq(TT-1,1,by=-1)){
    F <- matrix(Sigma_tt[t,],nr,nr) %*% t(H) %*% solve(matrix(Sigma_tp1_t[t+1,],nr,nr))
    rho_tT[t,] <- rho_tt[t,] + t( F %*% (rho_tT[t+1,]-rho_tp1_t[t+1,]) )
    if(sum(indic_pos==1)>0){
      rho_tT[t,indic_pos==1] = pmax(rho_tT[t,indic_pos==1],0)
    }
    Sigma_tT[t,] <- c(Sigma_tt[t,] + F %*%
                        matrix(Sigma_tT[t+1,]-Sigma_tp1_t[t+1,],nr,nr) %*% t(F))
  }
  output = list(r_smooth=rho_tT,S_smooth=Sigma_tT,
                loglik=output_filter$loglik,
                loglik.vector=output_filter$loglik.vector,
                Omega_tp1_t=Omega_tp1_t,
                Sigma_tt=Sigma_tt)
  return(output)
}


Rfunction <- function(M,rho,aux=NaN){
  # compute covariance matrix of measurement errors
  # indices.of.addit.var indicate to which basic measurement eq. relate the addiitonal ones.
  R  <- diag(c(M^2))
  return(R)
}

Qfunction <- function(N,rho,aux=NaN){  # ask if we remove aux
  k <- sqrt(length(N$alpha))
  Q <- matrix(N$alpha + N$beta %*% matrix(rho[1:k],ncol=1),k,k)
  if(!is.na(aux)){
    Q.extended <- matrix(0,aux,aux)
    Q.extended[1:k,1:k] <- Q
    Q <- Q.extended
  }
  return(Q)
}


