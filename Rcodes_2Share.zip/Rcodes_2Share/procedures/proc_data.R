# =======================================
# DISASTROUS DEFAULTS
# =======================================
# Christian Gouriéroux, Alain Monfort,
# Jean-Paul Renne and Sarah Mouabbi
# Contact: jean-paul.renne@unil.ch
# =======================================
# This script contains procedures
# aimed at preparing the dataset.
# =======================================


make.observables.and.vec.stdv <- function(DATASET.input,
                                          indic.plot=1){
  if(indic.plot){
    par(mfrow=c(6,6))
  }
  
  DATASET <- DATASET.input
  
  DATASET$observables <- cbind(
    DATASET$ITRAXX.main,
    DATASET$IV,
    DATASET$ITRAXX.tranches
  )
  
  DATASET$observables <- cbind(DATASET$observables,DATASET.input$delta.c)
  
  vec.stdv <- NULL
  
  # Treat
  for(i in 1:dim(DATASET$observables)[2]){
    aux <- DATASET$observables[,i]
    indices <- which(!is.na(aux))
    vec.dates.aux <- DATASET$Date[indices]
    aux <- aux[indices]
    if(length(aux)>10){
      spl <- smooth.spline(vec.dates.aux,aux,df=max(10,length(aux)/7))
      if(indic.plot){
        plot(vec.dates.aux,aux,type="l")
        lines(spl,col="red")
      }
      vec.stdv <- c(vec.stdv,sd(residuals(spl)))
    }else{
      vec.stdv <- c(vec.stdv,sd(aux))
    }
  }
  
  # Adjust w.r.t. to type of data (itraxx index, stock options, itraxx tranche)
  for(i in 1:length(DATASET$multipl.factors)){
    if(i==1){
      first <- 1
      last <- length(DATASET$H.in.years.4.itraxx.indices)
    }
    if(i==2){
      first <- last + 1
      last <- last + length(DATASET$H.in.years.4.stock.options)
    }
    if(i==3){
      first <- last + 1
      last <- last + length(DATASET$H.in.years.4.tranches)*length(DATASET$vec.a.b.4.tranches)
    }
    vec.stdv[first:last] <- DATASET$multipl.factors[i]*vec.stdv[first:last]
  }
  
  vec.stdv[length(vec.stdv)] <- DATASET$multipl.factors.delta.c*vec.stdv[length(vec.stdv)] # relax constraint on the fit of Delta(c)
  
  DATASET$vec.stdv <- vec.stdv
  
  return(DATASET)
}







compute.all.model.implied.prices <- function(Model.solved,
                                             DATASET,
                                             perfectly.fitted.maturities.in.years,
                                             max.iter.4.X.estim=4,
                                             indic.ZLB=1,
                                             indic.compute.tranches=1){
  J <- dim(Model.solved$zeta.n)[1]
  
  select.tranches <- 1:length(DATASET$vec.a.b.4.tranches)
  
  # First step: compute factors
  F1F2.est <- compute.X(Model.solved,
                        DATASET,
                        perfectly.fitted.maturities.in.years,
                        max.iter=max.iter.4.X.estim)
  
  # Construct X.complete:
  T <- dim(F1F2.est)[1]
  X.complete <- list(
    F   = cbind(matrix(0,T,J),F1F2.est),
    N   = matrix(0,T,J),
    N_1 = matrix(0,T,J)
  )
  
  if(indic.ZLB==1){
    X.complete$F[X.complete$F<0] <- 0
  }

  # ==========================================
  # Compute itraxx for all maturities:
  v <- c(1,rep(0,J-1)) # consider only first type of entities (systemic ones)
  
  all.modeled.itraxx <- compute.model.implied.itraxx(X.complete, v, Model.solved, DATASET)
  
  # ==========================================
  # Compute model-implied IV:
  K.over.P <- rep(1-DATASET$decrease.in.percent.4.stock.options/100,T)
  
  option.prices <- Equity.option.pricing(Model.solved,
                                         DATASET$H.in.years.4.stock.options,
                                         X.complete, v,
                                         K.over.P,
                                         min.log.v = -6,max.v = 80,step = .03)
  
  all.model.implied.vol <- NULL
  count <- 0
  for(h in DATASET$H.in.years.4.stock.options){
    count <- count + 1
    all.model.implied.vol <- cbind(all.model.implied.vol,
                                   compute.implied.vol(relative.prices = option.prices$Put[,count],
                                                       K.over.S = K.over.P,
                                                       maturities.in.years = h,
                                                       riskfree.rates = 0,
                                                       nb.iterations = 10))
  }
  
  
  # ==========================================
  # Compute model-implied tranche prices
  
  if(indic.compute.tranches==1){
    
    res.tranche.pricing <- Tranche.pricing(Model.solved,
                                           max.H=max(DATASET$H.in.years.4.tranches),
                                           X.complete, v,
                                           DATASET$vec.a.b.4.tranches,
                                           U=NaN,
                                           du=0.0001,
                                           min.log.v = -8,
                                           max.v = 40,
                                           step = .02)
    
    all.model.implied.tranches <-
      matrix(res.tranche.pricing$S.a.b[,DATASET$H.in.years.4.tranches*DATASET$q,select.tranches],
             T,length(DATASET$H.in.years.4.tranches)*length(select.tranches))
  }else{
    all.model.implied.tranches <- NaN
  }
  
  return(list(
    all.modeled.itraxx         = all.modeled.itraxx,
    all.model.implied.vol      = all.model.implied.vol,
    all.model.implied.tranches = all.model.implied.tranches,
    X.complete                 = X.complete,
    F1F2.est                   = F1F2.est
  ))
}






load.stock.option.data <- function(maturity.in.month,decrease.in.percent){
  DATA <- read.csv("data/csvfiles/AllOptionData.csv")
  DATA$Date <- as.Date(DATA$Date,"%d/%m/%y")
  
  Info_options <- read.csv("data/csvfiles/Strike_and_ExpiryDates.csv", header=FALSE)
  Info_options[,2] <- as.Date(Info_options[,2],"%d/%m/%y")
  # Info_options has two columns: the first gives the strike (K),
  # the second gives expiry dates.
  
  K.ts <- DATA$EUROSTOXX50*(1-decrease.in.percent/100)
  
  all.K <- c(1000,1500,2000,2500,3000,3500,4000)
  
  vec.prices <- NULL
  
  for(t in 1:dim(DATA)[1]){# loop on dates
    price.4.different.K <- NULL
    
    for(K in all.K){
      date.t <- DATA$Date[t]
      
      put.indices <- which((Info_options[,1]==K)&(Info_options[,2]>date.t))
      data <- cbind(
        (Info_options[put.indices,2]-date.t)/30,
        c(DATA[t,(put.indices+1)])
      )
      
      splinef <- splinefun(data[,1],data[,2])
      
      price.4.different.K <- c(price.4.different.K,
                               splinef(maturity.in.month)
      )
    }
    
    splinef2 <- splinefun(all.K,price.4.different.K)
    
    vec.prices <- c(vec.prices,
                    splinef2(K.ts[t]))
  }
  
  relative.price <- vec.prices/DATA$EUROSTOXX50
  
  return(list(
    DATA = DATA,
    vec.prices = vec.prices,
    relative.price = relative.price
  ))
}



load.data.4.1.option <- function(indic.column.in.DATA){
  
  DATA <- read.csv("data/csvfiles/AllOptionData.csv")
  DATA$Date <- as.Date(DATA$Date,"%d/%m/%y")
  
  Info_options <- read.csv("data/csvfiles/Strike_and_ExpiryDates.csv", header=FALSE)
  Info_options[,2] <- as.Date(Info_options[,2],"%d/%m/%y")
  # Info_options has two columns: the first gives the strike (K),
  # the second gives expiry dates.
  
  maturities.in.year <- as.double((Info_options[indic.column.in.DATA,2] - DATA$Date)/365.25)
  
  maturities.in.year[maturities.in.year<0] <- NaN
  
  sigma <- rep(.3,length(maturities.in.year))
  
  K <- Info_options[indic.column.in.DATA,1]
  
  S.t <- DATA$EUROSTOXX50
  
  d.1 <- 1/sigma/sqrt(maturities.in.year) * (log(S.t/K) + sigma^2/2*maturities.in.year)
  d.2 <- d.1 - sigma*sqrt(maturities.in.year)
  
  P <- pnorm(-d.2)*K - pnorm(-d.1)*S.t
  
  observed.prices <- DATA[,indic.column.in.DATA]
  
  plot(P,type="l")
  lines(observed.prices,col="red")
  
  return(list(
    S.t = S.t,
    K = K,
    maturities.in.years = maturities.in.year,
    observed.prices = observed.prices,
    dates=DATA$Date,
    P=P
  ))
}


compute.implied.vol <- function(relative.prices,K.over.S,maturities.in.years,riskfree.rates,nb.iterations){
  T <- length(relative.prices)
  sigma.i <- rep(.4,T)
  epsilon <- .00000001
  for(i in 1:nb.iterations){
    
    d.1 <- 1/sigma.i/sqrt(maturities.in.years) * (-log(K.over.S) + sigma.i^2/2*maturities.in.years)
    d.2 <- d.1 - sigma.i*sqrt(maturities.in.years)
    modeled.relative.prices <- pnorm(-d.2)*K.over.S - pnorm(-d.1)
    
    f.0 <- modeled.relative.prices - relative.prices
    
    sigma.i.eps <- sigma.i + epsilon
    d.1 <- 1/sigma.i.eps/sqrt(maturities.in.years) * (-log(K.over.S) + sigma.i.eps^2/2*maturities.in.years)
    d.2 <- d.1 - sigma.i.eps*sqrt(maturities.in.years)
    modeled.relative.prices.eps <- pnorm(-d.2)*K.over.S - pnorm(-d.1)
    
    f.prime <- (modeled.relative.prices.eps - modeled.relative.prices)/epsilon
    
    ratio <- f.0/f.prime
    
    sigma.i <- sigma.i - 0.8*ratio
  }
  
  return(sigma.i)
}




