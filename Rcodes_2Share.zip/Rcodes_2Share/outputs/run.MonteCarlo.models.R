# =======================================
# DISASTROUS DEFAULTS
# =======================================
# Christian Gouriéroux, Alain Monfort,
# Jean-Paul Renne and Sarah Mouabbi
# Contact: jean-paul.renne@unil.ch
# =======================================
# This version: October 2020
# =======================================
# This script simulates new models by 
#   drawing parameters in their asymptotic
#   distribution.
# =======================================

print("")
print("")
print("==========================================================")
print(" Generate random models - Monte Carlo")
print(" (drawing parameters in their asymptotic distribution)")
print(" (Can take some time. Results are stored in results/saveSimulatedModels/)")
print("==========================================================")


# Baseline model:
load(results.estim.KF)

# Compute baseline vector of parameters:
Filter <- rep(1,length(THETA.FULL))
Filter[param.2.exclude.from.optim]  <- 0
theta <- THETA.FULL[Filter==1]

# Solve model:
Model.solved <- make.Model(theta,
                           THETA.FULL,
                           Model,
                           DATASET,
                           targets,
                           nb.iter)
# Use Kalman smoother:
res.KF <- prepare.state.space(Model.solved,
                              DATASET,
                              indic.smooth = 1)
Logl.baseline <- res.KF$loglik
print(Logl.baseline)



cl <- makeCluster(number.of.cores)
registerDoParallel(cl)

save.image("estimation/tempo/toto.Rdata")
clusterEvalQ(cl,load("estimation/tempo/toto.Rdata"))

clusterEvalQ(cl,library(optimx))
clusterEvalQ(cl,library(MASS))
clusterEvalQ(cl,library(expm))
clusterEvalQ(cl,library(mFilter))
clusterEvalQ(cl,library(stringr))
clusterEvalQ(cl,library(doParallel))


AUX <- foreach(JJJ=1:nb.replications,.combine=sum) %dopar% {
  
  set.seed(JJJ)
  
  flag <- 0
  while(flag==0){
    theta.i <- theta + t(chol(Mat.var.cov)) %*% matrix(rnorm(length(theta)),ncol=1)
    Model.solved <- make.Model(theta.i,
                               THETA.FULL,
                               Model,
                               DATASET,
                               targets,
                               nb.iter)
    if(!is.na(Model.solved$z.bar)){
      res.KF <- prepare.state.space(Model.solved,
                                    DATASET,
                                    indic.smooth = 1)
      logl <- res.KF$loglik
      
      if(logl>Logl.baseline-Threshold.logL){
        flag <- 1
        
        # =========================================
        # =========================================
        # Compute probas used for indicators
        # =========================================
        # =========================================
        
        # remove prices of risk:
        Model.aux <- Model.solved
        Model.aux$Delta <- NULL
        Model.aux$Eta <- NULL
        
        # --------------------------------------------------------  
        # A- Proba of serval defaults among iTraxx consitutents:
        
        H <- matrix(DATASET$q*Maturity.4.indicator.1stChart,ncol=1)
        v <- c(1,0,0)
        a    <- list(A = matrix(0,n.F,1),
                     B = matrix(0,J,1),
                     C = matrix(0,J,1),
                     D = matrix(0,1,1))
        b    <- list(A = matrix(0,n.F,1),
                     B = matrix(v,ncol=1),
                     C = matrix(0,J,1),
                     D = matrix(0,1,1))
        
        Y <- g(Model.aux,a,b,nb.def.iTraxx.constitu,
               H,X.complete,min.log.v=-10,max.v=500,step=.001)
        
        proba.iTraxxDefault.maturity1 <- 1-Y[,,1]
        proba.iTraxxDefault.maturity2 <- 1-Y[,,2]
        
        # --------------------------------------------------------  
        # B- Proba of large falls in consumption:
        
        H <- matrix(DATASET$q*Maturity.4.indicator.2ndChart,length(Maturity.4.indicator.2ndChart),1)
        a    <- list(A = matrix(0,n.F,1),
                     B = matrix(0,J,1),
                     C = matrix(0,J,1),
                     D = matrix(0,1,1))
        b    <- list(A = matrix(Model.aux$Mu.c$A,n.F,1),
                     B = matrix(Model.aux$Mu.c$B,ncol=1),
                     C = matrix(Model.aux$Mu.c$C,J,1),
                     D = matrix(0,1,1))
        
        # First threshold:
        threshold <- vector.of.decrease.in.conso[1]
        
        y <- threshold - DATASET$q * Maturity.4.indicator.2ndChart * Model.aux$Mu.c$D
        YY <- g(Model.aux,a,b,y,H,X.complete,min.log.v=-10,max.v=10000,step=.001,indic_cumul = 1)
        YY.aux1 <- matrix(YY,ncol=1)
        proba.consDecrease1 <- YY.aux1 # store central values
        
        # Second threshold:
        threshold <- vector.of.decrease.in.conso[2]
        
        y <- threshold - DATASET$q * Maturity.4.indicator.2ndChart * Model.aux$Mu.c$D
        YY <- g(Model.aux,a,b,y,H,X.complete,min.log.v=-10,max.v=10000,step=.001,indic_cumul = 1)
        YY.aux2 <- matrix(YY,ncol=1)
        proba.consDecrease2 <- YY.aux2 # store central values

        save(Model.solved,res.KF,
             proba.iTraxxDefault.maturity1,
             proba.iTraxxDefault.maturity2,
             proba.consDecrease1,
             proba.consDecrease2,
             file=paste("results/saveSimulatedModels/simuated_model_",
                        toString(JJJ),".Rdat",sep=""))
      }
    }
  }
}

stopCluster(cl)

