# =======================================
# DISASTROUS DEFAULTS
# =======================================
# Christian Gouriéroux, Alain Monfort,
# Jean-Paul Renne and Sarah Mouabbi
# Contact: jean-paul.renne@unil.ch
# =======================================
# This version: October 2020
# =======================================
# This script aims at computing indicators with confidence intervals
#    taking into account two types of uncertainty:
#    (a) parameters and (b) filtering of factors.
# For this script to work, one needs Mat.var.cov (computed in make.output.tables.R)
# Parameters are drawn from the asymptotic distribution of the parameter estimates.
# =======================================


print("")
print("")
print("==========================================================")
print(" Producing figure with indicators")
print("==========================================================")



# ================================
# Baseline model:

# Load baseline results:
load(results.estim.KF)
Filter <- rep(1,length(Filter))
Model.solved <- make.Model(THETA.FULL,
                           THETA.FULL,
                           Model,
                           DATASET,
                           targets,
                           nb.iter = nb.iter)
res.KF <- prepare.state.space(Model.solved,
                              DATASET,
                              indic.smooth = 1)
print(paste("Log-likelihood: ",res.KF$loglik,sep=""))

X.complete <- list(
  F   = cbind(matrix(0,dim(res.KF$r_smooth)[1],J),
              res.KF$r_smooth[,1:2]),
  N   = matrix(0,dim(res.KF$r)[1],J),
  N_1 = matrix(0,dim(res.KF$r)[1],J)
)




# Kill prices of risk (work under the physical dynamics):
Model.aux <- Model.solved
Model.aux$Delta <- NULL
Model.aux$Eta <- NULL



# ================================
# A - Defaults of iTraxx constituents
# ================================

H <- matrix(DATASET$q*Maturity.4.indicator.1stChart,ncol=1)

v <- c(1,0,0)
a    <- list(A = matrix(0,n.F,1),
             B = matrix(0,J,1),
             C = matrix(0,J,1),
             D = matrix(0,1,1))
b    <- list(A = matrix(0,n.F,1),
             B = matrix(v,ncol=1),
             C = matrix(0,J,1),
             D = matrix(0,1,1))

Y <- g(Model.aux,a,b,nb.def.iTraxx.constitu,
       H,X.complete,min.log.v=-10,max.v=500,step=.001)

# For delta method: compute derivative of Y wrt [x,y]:

eps <- .000001
Jacob.matrix.iTraxx1 <- NULL
Jacob.matrix.iTraxx2 <- NULL
for(i in 1:(n.F-J)){
  X.complete.i <- X.complete
  X.complete.i$F[,J+i] <- X.complete.i$F[,J+i] + eps
  Y.i <- g(Model.aux,a,b,nb.def.iTraxx.constitu,
           H,X.complete.i,min.log.v=-10,max.v=500,step=.001)
  Jacob.matrix.iTraxx1 <- cbind(Jacob.matrix.iTraxx1,(Y.i[,,1]-Y[,,1])/eps)
  Jacob.matrix.iTraxx2 <- cbind(Jacob.matrix.iTraxx2,(Y.i[,,2]-Y[,,2])/eps)
}


y.iTraxx.1 <- 1-Y[,,1]
y.iTraxx.2 <- 1-Y[,,2]

y.lim.1.iTraxx <- c(0,2*max(y.iTraxx.1))
y.lim.2.iTraxx <- c(0,2*max(y.iTraxx.2))


# ================================
# B - Large decreases in consumption
# ================================

H <- matrix(DATASET$q*Maturity.4.indicator.2ndChart,ncol=1)
a    <- list(A = matrix(0,n.F,1),
             B = matrix(0,J,1),
             C = matrix(0,J,1),
             D = matrix(0,1,1))
b    <- list(A = matrix(Model.solved$Mu.c$A,n.F,1),
             B = matrix(Model.solved$Mu.c$B,ncol=1),
             C = matrix(Model.solved$Mu.c$C,J,1),
             D = matrix(0,1,1))

Y <- NULL
Jacob.matrix.conso1 <- NULL
Jacob.matrix.conso2 <- NULL

for(threshold in vector.of.decrease.in.conso){# Loop on the decrease in consumption
  y <- threshold - DATASET$q * Maturity.4.indicator.2ndChart * Model.solved$Mu.c$D
  YY <- g(Model.aux,a,b,y,H,X.complete,
          min.log.v=-10,max.v=10000,step=.001,indic_cumul = 1)
  YY.aux <- matrix(YY,ncol=1)
  Y <- cbind(Y,YY.aux) # store central values
  
  # For delta method: compute derivative of Y wrt [x,y]:
  eps <- .000001
  Jacob.matrix <- NULL
  for(i in 1:(n.F-J)){
    X.complete.i <- X.complete
    X.complete.i$F[,J+i] <- X.complete.i$F[,J+i] + eps
    Y.i <- g(Model.aux,a,b,y,H,X.complete.i,
             min.log.v=-10,max.v=10000,step=.001,indic_cumul = 1)
    Y.i <- matrix(Y.i,ncol=1)
    if(i==1){
      Jacob.matrix.conso1 <- cbind(Jacob.matrix.conso1,(Y.i-YY.aux)/eps)
    }else{
      Jacob.matrix.conso2 <- cbind(Jacob.matrix.conso2,(Y.i-YY.aux)/eps)
    }
  }
}  

y.conso.1 <- Y[,1]
y.conso.2 <- Y[,2]

y.lim.1.conso <- c(0,2*max(y.conso.1))
y.lim.2.conso <- c(0,2*max(y.conso.2))

all.proba.iTraxxDefault.maturity1 <- NULL
all.proba.iTraxxDefault.maturity2 <- NULL

all.proba.consDecrease1 <- NULL
all.proba.consDecrease2 <- NULL

for(JJJ in 1:nb.replications){
  
  load(file=paste("results/saveSimulatedModels/simuated_model_",
                  toString(JJJ),".Rdat",sep=""))
  
  all.proba.iTraxxDefault.maturity1 <- cbind(all.proba.iTraxxDefault.maturity1,
                                             proba.iTraxxDefault.maturity1)
  all.proba.iTraxxDefault.maturity2 <- cbind(all.proba.iTraxxDefault.maturity2,
                                             proba.iTraxxDefault.maturity2)
  all.proba.consDecrease1 <- cbind(all.proba.consDecrease1,
                                   proba.consDecrease1)
  all.proba.consDecrease2 <- cbind(all.proba.consDecrease2,
                                   proba.consDecrease2)
  
}


# Without state vector uncertainty (i.e. only parameter uncertainty):
stdv.iTraxx1 <- apply(all.proba.iTraxxDefault.maturity1,1,sd)
stdv.iTraxx2 <- apply(all.proba.iTraxxDefault.maturity2,1,sd)

stdv.conso1 <- apply(all.proba.consDecrease1,1,sd)
stdv.conso2 <- apply(all.proba.consDecrease2,1,sd)

# With parameter and state vector uncertainty:
var.iTraxx1 <- apply(all.proba.iTraxxDefault.maturity1,1,var) +
  apply(t(apply(Jacob.matrix.iTraxx1,1,function(x){x %x% x})) *
          res.KF$S_smooth[,c(1,2,6,7)],1,sum)
stdv.iTraxx1 <- sqrt(var.iTraxx1)

var.iTraxx2 <- apply(all.proba.iTraxxDefault.maturity2,1,var) +
  apply(t(apply(Jacob.matrix.iTraxx2,1,function(x){x %x% x})) *
          res.KF$S_smooth[,c(1,2,6,7)],1,sum)
stdv.iTraxx2 <- sqrt(var.iTraxx2)

var.conso1 <- apply(all.proba.consDecrease1,1,var) +
  apply(t(apply(Jacob.matrix.conso1,1,function(x){x %x% x})) *
          res.KF$S_smooth[,c(1,2,6,7)],1,sum)
stdv.conso1 <- sqrt(var.conso1)

var.conso2 <- apply(all.proba.consDecrease2,1,var) +
  apply(t(apply(Jacob.matrix.conso2,1,function(x){x %x% x})) *
          res.KF$S_smooth[,c(1,2,6,7)],1,sum)
stdv.conso2 <- sqrt(var.conso2)



# ================================
# Prepare pdf figure
# ================================

FILE = paste("/figures/Figure_indicator.pdf",sep="")
pdf(file=paste(getwd(),FILE,sep=""),pointsize=7,width=6, height=6)

par(mfrow=c(2,1),plt=c(.1,.95,.1,.85))




# -----------------------------------------------
# Panel A - Proba of default of serval iTraxx constitutents


max.Y <- 1.8*max(100*y.iTraxx.2)

plot(clean.DATA$Date,100*(y.iTraxx.2),type="l",lwd=2,col="white",
     xlab="",ylab="in percent",las=1,ylim=c(0,max.Y),
     # main="Default of at least 10% of the iTraxx constituents before 12 and 24 months")
     main=paste("Probability of at least ",toString(nb.def.iTraxx.constitu)," iTraxx constituents defaulting before 12 and 24 months",
                sep=""))
polygon.upper <- 100*(y.iTraxx.2 + mult.fact.stdv*stdv.iTraxx2)
polygon.lower <- pmax(0,100*(y.iTraxx.2 - mult.fact.stdv*stdv.iTraxx2))
polygon(c(clean.DATA$Date,clean.DATA$Date[length(clean.DATA$Date):1]),
        c(polygon.lower,polygon.upper[length(DATASET$Date):1]),col="#99999944",border = NaN)

polygon.upper <- 100*(y.iTraxx.1 + mult.fact.stdv*stdv.iTraxx1)
polygon.lower <- pmax(0,100*(y.iTraxx.1 - mult.fact.stdv*stdv.iTraxx1))
polygon(c(clean.DATA$Date,clean.DATA$Date[length(clean.DATA$Date):1]),
        c(polygon.lower,polygon.upper[length(DATASET$Date):1]),col="#99999944",border = NaN)

lines(clean.DATA$Date,100*y.iTraxx.2,lwd=2)
lines(clean.DATA$Date,100*y.iTraxx.1,lwd=3,col="black",lty=3)

# ============================
# http://bruegel.org/2015/09/euro-crisis/
# ============================

# European interbank markets seize-up
abline(v=as.Date("1-8-2007","%d-%m-%Y"),
       col="red",lwd=1)
text(as.Date("1-8-2007","%d-%m-%Y")-10,max.Y,"1",cex = 1,pos = 2)

# Lehman Brother's bankrupcty
abline(v=as.Date("15-09-2008","%d-%m-%Y"),col="red",lwd=1)
text(as.Date("15-08-2008","%d-%m-%Y")-10,max.Y,"2",cex = 1,pos = 2)

# Emergency measures to safeguard financial stability
abline(v=as.Date("7-05-2010","%d-%m-%Y"),col="red",lwd=1)
text(as.Date("7-5-2010","%d-%m-%Y")-10,max.Y,"3",cex = 1,pos = 2)

#May 2011, the crisis resurfaced, concerning mostly the refinancing of Greek public debt
#abline(v=as.Date("15-05-2011","%d-%m-%Y"),col="red",lwd=2)

# European shares declined for a second day on fears that Franco-Belgian bank Dexia
#    may need to be rescued due to its exposure to Greek debt.
# Concern increased that the Eurozone sovereign debt crisis is spreading to the banking sector.
# Rating agencies downgrade Spain and Italy
abline(v=as.Date("4-10-2011","%d-%m-%Y"),col="red",lwd=1)
text(as.Date("4-10-2011","%d-%m-%Y")-10,max.Y,"4",cex = 1,pos = 2)

# ECB President Mario Draghi says that the ECB, within its mandate, will do ???whatever it takes to preserve the euro???.
abline(v=as.Date("26-07-2012","%d-%m-%Y"),col="red",lwd=1)
text(as.Date("26-7-2012","%d-%m-%Y")-10,max.Y,"5",cex = 1,pos = 2)

# The European Central Bank announces its long-awaited Quantitative Easing programme and details asset purchases of ???60bn per month starting in March 2015,
# which will continue at this pace until atleast September 2016.
#abline(v=as.Date("22-01-2015","%d-%m-%Y"),col="red",lwd=2)
#text(as.Date("22-01-2015","%d-%m-%Y")-10,max.Y,"6",cex = 1,pos = 2)

legend("topright", # places a legend at the appropriate place c("Health","Defense"), # puts text in the legend 
       c("Horizon: 1 year","Horizon: 2 years"),
       lty=c(3,1), # gives the legend appropriate symbols (lines)       
       lwd=c(3,2), # line width
       col=c("black","black"), # gives the legend lines the correct color and width
       pt.bg=c(1),
       pt.cex = c(1),
       bg="white",
       seg.len = 4)

abline(h=0,col="grey")


# -----------------------------------------------
# Panel B - Consumption falls

max.Y <- 1.8*max(100*y.conso.1)

plot(clean.DATA$Date,100*y.conso.1,type="l",lwd=2,
     xlab="",ylab="in percent",las=1,ylim=c(0,max.Y),col="white",
     #main="Drops in consumption by more than 10% or 20% (horizon = 12 months)")
     main="Probability of consumption dropping by more than 10% or 20% (horizon = 12 months)")

polygon.upper <- 100*(y.conso.1 + mult.fact.stdv*stdv.conso1)
polygon.lower <- pmax(0,100*(y.conso.1 - mult.fact.stdv*stdv.conso1))
polygon(c(clean.DATA$Date,clean.DATA$Date[length(clean.DATA$Date):1]),
        c(polygon.lower,polygon.upper[length(DATASET$Date):1]),col="#99999944",border = NaN)

polygon.upper <- 100*(y.conso.2 + mult.fact.stdv*stdv.conso2)
polygon.lower <- pmax(0,100*(y.conso.2 - mult.fact.stdv*stdv.conso2))
polygon(c(clean.DATA$Date,clean.DATA$Date[length(clean.DATA$Date):1]),
        c(polygon.lower,polygon.upper[length(DATASET$Date):1]),col="#99999944",border = NaN)

lines(clean.DATA$Date,100*y.conso.1,lwd=2)
lines(clean.DATA$Date,100*y.conso.2,lwd=3,col="black",lty=3)

# ============================
# http://bruegel.org/2015/09/euro-crisis/
# ============================

# European interbank markets seize-up
abline(v=as.Date("1-8-2007","%d-%m-%Y"),
       col="red",lwd=1)
text(as.Date("1-8-2007","%d-%m-%Y")-10,max.Y,"1",cex = 1,pos = 2)

# Lehman Brother's bankrupcty
abline(v=as.Date("15-09-2008","%d-%m-%Y"),col="red",lwd=1)
text(as.Date("15-08-2008","%d-%m-%Y")-10,max.Y,"2",cex = 1,pos = 2)

# Emergency measures to safeguard financial stability
abline(v=as.Date("7-05-2010","%d-%m-%Y"),col="red",lwd=1)
text(as.Date("7-5-2010","%d-%m-%Y")-10,max.Y,"3",cex = 1,pos = 2)

#May 2011, the crisis resurfaced, concerning mostly the refinancing of Greek public debt
#abline(v=as.Date("15-05-2011","%d-%m-%Y"),col="red",lwd=2)

# European shares declined for a second day on fears that Franco-Belgian bank Dexia
#    may need to be rescued due to its exposure to Greek debt.
# Concern increased that the Eurozone sovereign debt crisis is spreading to the banking sector.
# Rating agencies downgrade Spain and Italy
abline(v=as.Date("4-10-2011","%d-%m-%Y"),col="red",lwd=1)
text(as.Date("4-10-2011","%d-%m-%Y")-10,max.Y,"4",cex = 1,pos = 2)

# ECB President Mario Draghi says that the ECB, within its mandate, will do ???whatever it takes to preserve the euro???.
abline(v=as.Date("26-07-2012","%d-%m-%Y"),col="red",lwd=1)
text(as.Date("26-7-2012","%d-%m-%Y")-10,max.Y,"5",cex = 1,pos = 2)

# The European Central Bank announces its long-awaited Quantitative Easing programme and details asset purchases of ???60bn per month starting in March 2015,
# which will continue at this pace until atleast September 2016.
#abline(v=as.Date("22-01-2015","%d-%m-%Y"),col="red",lwd=2)
#text(as.Date("22-01-2015","%d-%m-%Y")-10,max.Y,"6",cex = 1,pos = 2)

legend("topright", # places a legend at the appropriate place c("Health","Defense"), # puts text in the legend 
       c(paste("< ",toString(100*vector.of.decrease.in.conso[1]),"%",sep=""),
         paste("< ",toString(100*vector.of.decrease.in.conso[2]),"%",sep="")),
       lty=c(1,3), # gives the legend appropriate symbols (lines)       
       lwd=c(3,2), # line width
       col=c("black","black"), # gives the legend lines the correct color and width
       pt.bg=c(1),
       #text.width = 2,
       #cex=1.0,# size of the text
       #pch = c(1,2,3,4),#symbols,
       pt.cex = c(1),
       bg="white",
       seg.len = 4,
       title = "Falls in consumption:"
)

abline(h=0,col="grey")




dev.off()




