# ===============================
# Counterfactual analysis
# Compare model fit with the fit
#    obtained with alternative specificaitons
#    (no contagion, no macro effects)
# Two sets of two tables are built, one set is for alternative models where
# contagion and systemic-pricing channels are killed, the other set considers
# re-estimated contrained models.
# ===============================

for(Type.of.modif in c("Reestimated","Modified")){
  
  
  print("")
  print("")
  print("==========================================================")
  print(" Solving models without contagion and/or macro effects")
  if(Type.of.modif == "Reestimated"){
    print(" (Part 1/2 - Models that have been re-estimated)")
  }else{
    print(" (Part 2/2 - Models that have not been re-estimated)")
  }
  print("==========================================================")
  
  
  #options(warn=-1)
  if(Type.of.modif=="Reestimated"){
    # Version where alternative models are re-estimated:
    source('outputs/load.alternative.estimated.models.R')
  }
  if(Type.of.modif=="Modified"){
    # Version where the baseline model is modified (no parameter re-estimation):
    source('outputs/load.alternative.modified.models.R')
  }
  #options(warn=0)
  
  res <-
    compute.various.moments(Model.solved,
                            DATASET,targets)
  res.no.contagion <-
    compute.various.moments(Model.solved.no.contagion,
                            DATASET,targets)
  res.no.macro.effect <-
    compute.various.moments(Model.solved.no.macro.effect,
                            DATASET,targets)
  res.no.contagion.no.macro.effect <-
    compute.various.moments(Model.solved.no.contagion.no.macro.effect,
                            DATASET,targets)
  
  moments                 <-
    compute.moments(Model.solved)
  moments.no.contagion    <-
    compute.moments(Model.solved.no.contagion)
  moments.no.macro.effect <-
    compute.moments(Model.solved.no.macro.effect)
  moments.no.contagion.no.macro.effect <-
    compute.moments(Model.solved.no.contagion.no.macro.effect)
  
  r_s.avg <-
    Model.solved$q*(Model.solved$kappa.0 + Model.solved$A.0*(Model.solved$kappa.1 - 1) + Model.solved$Mu.d$D +
                      t((Model.solved$kappa.1-1)*c(Model.solved$A.1$A,Model.solved$A.1$B) +
                          c(Model.solved$Mu.d$A,Model.solved$Mu.d$B)) %*% moments$unc.mean)
  r_s.avg.no.contagion <-
    Model.solved$q*(Model.solved.no.contagion$kappa.0 + Model.solved.no.contagion$A.0*(Model.solved.no.contagion$kappa.1 - 1) + Model.solved.no.contagion$Mu.d$D +
                      t((Model.solved.no.contagion$kappa.1-1)*c(Model.solved.no.contagion$A.1$A,Model.solved.no.contagion$A.1$B) +
                          c(Model.solved.no.contagion$Mu.d$A,Model.solved.no.contagion$Mu.d$B)) %*% moments.no.contagion$unc.mean)
  r_s.avg.no.macro.effect <-
    Model.solved$q*(Model.solved.no.macro.effect$kappa.0 + Model.solved.no.macro.effect$A.0*(Model.solved.no.macro.effect$kappa.1 - 1) + Model.solved.no.macro.effect$Mu.d$D +
                      t((Model.solved.no.macro.effect$kappa.1-1)*c(Model.solved.no.macro.effect$A.1$A,Model.solved.no.macro.effect$A.1$B) +
                          c(Model.solved.no.macro.effect$Mu.d$A,Model.solved.no.macro.effect$Mu.d$B)) %*% moments.no.macro.effect$unc.mean)
  r_s.avg.no.contagion.no.macro.effect <-
    Model.solved$q*(Model.solved.no.contagion.no.macro.effect$kappa.0 + Model.solved.no.contagion.no.macro.effect$A.0*(Model.solved.no.contagion.no.macro.effect$kappa.1 - 1) + Model.solved.no.contagion.no.macro.effect$Mu.d$D +
                      t((Model.solved.no.contagion.no.macro.effect$kappa.1-1)*c(Model.solved.no.contagion.no.macro.effect$A.1$A,Model.solved.no.contagion.no.macro.effect$A.1$B) +
                          c(Model.solved.no.contagion.no.macro.effect$Mu.d$A,Model.solved.no.contagion.no.macro.effect$Mu.d$B)) %*% moments.no.contagion.no.macro.effect$unc.mean)
  
  delta.c.annual.mean <-
    Model.solved$q*(Model.solved$Mu.c$D +
                      t(Model.solved$Mu.c$A)%*%moments$unc.mean[1:5])
  delta.c.annual.mean.no.contagion <-
    Model.solved$q*(Model.solved.no.contagion$Mu.c$D +
                      t(Model.solved.no.contagion$Mu.c$A)%*%moments.no.contagion$unc.mean[1:5])
  delta.c.annual.mean.no.macro.effect <-
    Model.solved$q*(Model.solved.no.macro.effect$Mu.c$D +
                      t(Model.solved.no.macro.effect$Mu.c$A)%*%moments.no.macro.effect$unc.mean[1:5])
  delta.c.annual.mean.no.contagion.no.macro.effect <-
    Model.solved$q*(Model.solved.no.contagion.no.macro.effect$Mu.c$D +
                      t(Model.solved.no.contagion.no.macro.effect$Mu.c$A)%*%moments.no.contagion.no.macro.effect$unc.mean[1:5])
  
  # ================================
  # Compute std dev of annual consumption growth for the three models:
  
  # Baseline:
  V <- moments$unc.var
  PHI <- moments$PHI
  Var.X.q <- Model.solved$q * V
  for(j in 1:(Model.solved$q-1)){
    Var.X.q <- Var.X.q + 2 * (Model.solved$q-j) * (PHI%^%j %*% V + V %*% t(PHI%^%j))
  }
  var.delta.c.annual <- t(Model.solved$Mu.c$A) %*% Var.X.q[1:5,1:5] %*% Model.solved$Mu.c$A +
    Model.solved$q * Model.solved$sigma.c^2
  
  # No contagion:
  V <- moments.no.contagion$unc.var
  PHI <- moments.no.contagion$PHI
  Var.X.q <- Model.solved$q * V
  for(j in 1:(Model.solved$q-1)){
    Var.X.q <- Var.X.q + 2 * (Model.solved$q-j) * (PHI%^%j %*% V + V %*% t(PHI%^%j))
  }
  var.delta.c.annual.no.contagion <- t(Model.solved.no.contagion$Mu.c$A) %*% Var.X.q[1:5,1:5] %*% Model.solved.no.contagion$Mu.c$A +
    Model.solved$q * Model.solved.no.contagion$sigma.c^2
  
  # No macro effects:
  V <- moments.no.macro.effect$unc.var
  PHI <- moments.no.macro.effect$PHI
  Var.X.q <- Model.solved$q * V
  for(j in 1:(Model.solved$q-1)){
    Var.X.q <- Var.X.q + 2 * (Model.solved$q-j) * (PHI%^%j %*% V + V %*% t(PHI%^%j))
  }
  var.delta.c.annual.no.macro.effect <- t(Model.solved.no.macro.effect$Mu.c$A) %*% Var.X.q[1:5,1:5] %*% Model.solved.no.macro.effect$Mu.c$A +
    Model.solved$q * Model.solved.no.macro.effect$sigma.c^2
  
  # No contagion and no macro effects:
  V <- moments.no.contagion.no.macro.effect$unc.var
  PHI <- moments.no.contagion.no.macro.effect$PHI
  Var.X.q <- Model.solved$q * V
  for(j in 1:(Model.solved$q-1)){
    Var.X.q <- Var.X.q + 2 * (Model.solved$q-j) * (PHI%^%j %*% V + V %*% t(PHI%^%j))
  }
  var.delta.c.annual.no.contagion.no.macro.effect <-
    t(Model.solved.no.contagion.no.macro.effect$Mu.c$A) %*% Var.X.q[1:5,1:5] %*% Model.solved.no.contagion.no.macro.effect$Mu.c$A +
    Model.solved$q * Model.solved.no.contagion.no.macro.effect$sigma.c^2
  # ================================
  
  
  
  print("==== Solve models (including counterfactuals) ====")
  mom.stock.returns <-
    compute.exp.stock.returns(Model.solved)
  mom.stock.returns.no.contagion <-
    compute.exp.stock.returns(Model.solved.no.contagion)
  mom.stock.returns.no.macro.effect <-
    compute.exp.stock.returns(Model.solved.no.macro.effect)
  mom.stock.returns.no.contagion.no.macro.effect <-
    compute.exp.stock.returns(Model.solved.no.contagion.no.macro.effect)
  
  print("==== Compute prices (including counterfactuals) ====")
  print("baseline model")
  res.prices <- compute.prices.for.given.X(Model.solved,
                                           X.complete,v,
                                           DATASET)
  res.tranche.pricing <- Tranche.pricing(Model.solved,
                                         max.H=max(DATASET$H.in.years.4.tranches),
                                         X.complete,v,
                                         DATASET$vec.a.b.4.tranches,U=NaN,
                                         du=0.0001,
                                         min.log.v=-8,
                                         max.v=10000,
                                         step=.01)
  
  print("no-contagion model")
  res.prices.no.contagion <- compute.prices.for.given.X(Model.solved.no.contagion,
                                                        X.complete.no.contagion,v,
                                                        DATASET)
  res.tranche.pricing.no.contagion <- Tranche.pricing(Model.solved.no.contagion,
                                                      max.H=max(DATASET$H.in.years.4.tranches),
                                                      X.complete.no.contagion,v,
                                                      DATASET$vec.a.b.4.tranches,U=NaN,
                                                      du=0.0001,
                                                      min.log.v=-8,
                                                      max.v=10000,
                                                      step=.01)
  
  print("no-macro-effect model")
  res.prices.no.macro.effect <- compute.prices.for.given.X(Model.solved.no.macro.effect,
                                                           X.complete.no.macro.effect,v,
                                                           DATASET)
  res.tranche.pricing.no.macro.effect <- Tranche.pricing(Model.solved.no.macro.effect,
                                                         max.H=max(DATASET$H.in.years.4.tranches),
                                                         X.complete.no.macro.effect,v,
                                                         DATASET$vec.a.b.4.tranches,U=NaN,
                                                         du=0.0001,
                                                         min.log.v=-8,
                                                         max.v=10000,
                                                         step=.01)
  
  print("no-contagion-no-macro-effect model")
  res.prices.no.contagion.no.macro.effect <- compute.prices.for.given.X(Model.solved.no.contagion.no.macro.effect,
                                                                        X.complete.no.contagion.no.macro.effect,v,
                                                                        DATASET)
  res.tranche.pricing.no.contagion.no.macro.effect <- Tranche.pricing(Model.solved.no.contagion.no.macro.effect,
                                                                      max.H=max(DATASET$H.in.years.4.tranches),
                                                                      X.complete.no.contagion.no.macro.effect,v,
                                                                      DATASET$vec.a.b.4.tranches,U=NaN,
                                                                      du=0.0001,
                                                                      min.log.v=-8,
                                                                      max.v=10000,
                                                                      step=.01)
  
  
  # Compute real short-term interest rate from AWM:
  awm19up18 <- read.csv("data/csvfiles/awm19up18.csv")
  T.AWM <- dim(awm19up18)[1]
  r.AWM <- awm19up18$STN[5:T.AWM] - 100*(awm19up18$PCD[5:T.AWM]/awm19up18$PCD[1:(T.AWM-4)]-1)
  Delta.c.annual <- log(awm19up18$PCR[5:T.AWM]/awm19up18$PCR[1:(T.AWM-4)])
  
  
  first.line <- NULL
  
  names.itraxx <- NULL
  for(i in 1:length(DATASET$H.in.years.4.itraxx.indices)){
    names.itraxx <- c(names.itraxx,
                      paste(toString(DATASET$H.in.years.4.itraxx.indices[i])," years",sep=""))
  }
  
  
  
  
  latex.table <- rbind(first.line,
                       #"\\hline",
                       paste("Avg. annual consumption growth&$",round.fixed.length(100*mean(Delta.c.annual),2),"^a$&$",
                             round.fixed.length(100*delta.c.annual.mean,2),"$&$",
                             round.fixed.length(100*delta.c.annual.mean,2),"$&$",
                             round.fixed.length(100*delta.c.annual.mean,2),"$&$",
                             round.fixed.length(100*delta.c.annual.mean,2),
                             #"$&$",round.fixed.length(100*target.avg.r,2),"\\%",
                             "$\\\\",sep=""),
                       paste("St. dev. annual consumption growth&$",round.fixed.length(100*sd(Delta.c.annual),1),
                             "^a$ / $2.9^b$ / $5.7^c$","&$",
                             round.fixed.length(round(100*sqrt(var.delta.c.annual)),2),"$&$",
                             round.fixed.length(100*sqrt(var.delta.c.annual.no.contagion),2),"$&$",
                             round.fixed.length(100*sqrt(var.delta.c.annual.no.macro.effect),2),"$&$",
                             round.fixed.length(100*sqrt(var.delta.c.annual.no.contagion.no.macro.effect),2),
                             "$\\\\",sep=""),
                       paste("Avg. short-term risk-free rate&$",round.fixed.length(mean(r.AWM),2),"^a$&$",
                             round.fixed.length(100*res$model.implied.avg.r,2),"$&$",
                             round.fixed.length(100*res.no.contagion$model.implied.avg.r,2),"$&$",
                             round.fixed.length(100*res.no.macro.effect$model.implied.avg.r,2),"$&$",
                             round.fixed.length(100*res.no.contagion.no.macro.effect$model.implied.avg.r,2),
                             #"$&$",round.fixed.length(100*target.avg.r,2),"\\%",
                             "$\\\\",sep=""),
                       paste("St. dev. short-term risk-free rate &$",round.fixed.length(sd(r.AWM),2),"^a$&$",
                             round.fixed.length(100*res$model.implied.stdv.r,2),"$&$",
                             round.fixed.length(100*res.no.contagion$model.implied.stdv.r,2),"$&$",
                             round.fixed.length(100*res.no.macro.effect$model.implied.stdv.r,2),"$&$",
                             round.fixed.length(100*res.no.contagion.no.macro.effect$model.implied.stdv.r,2),
                             "$\\\\",sep=""),
                       paste("Avg. equity excess return&&$",
                             round.fixed.length(100*(mom.stock.returns$mean.return -
                                                       mom.stock.returns$mean.rf.yd),2),"$&$",
                             round.fixed.length(100*(mom.stock.returns.no.contagion$mean.return -
                                                       mom.stock.returns.no.contagion$mean.rf.yd),2),"$&$",
                             round.fixed.length(100*(mom.stock.returns.no.macro.effect$mean.return -
                                                       mom.stock.returns.no.macro.effect$mean.rf.yd),2),"$&$",
                             round.fixed.length(100*(mom.stock.returns.no.contagion.no.macro.effect$mean.return -
                                                       mom.stock.returns.no.contagion.no.macro.effect$mean.rf.yd),2),
                             "$\\\\",sep=""),
                       paste("Maximum Sharpe ratio&&$",
                             round.fixed.length(100*compute.max.Sharpe.ratio(Model.solved),1),"$&$",
                             round.fixed.length(100*compute.max.Sharpe.ratio(Model.solved.no.contagion),1),"$&$",
                             round.fixed.length(100*compute.max.Sharpe.ratio(Model.solved.no.macro.effect),1),"$&$",
                             round.fixed.length(100*compute.max.Sharpe.ratio(Model.solved.no.contagion.no.macro.effect),1),
                             "$\\\\",sep=""),
                       paste("Avg. default proba. of a systemic entity\\;&$",
                             round.fixed.length(100*targets$target.default.rate,2),"^d$&$",
                             #paste("$\\mathbb{E}(n^s_t)$&&$",
                             round.fixed.length(100*round(moments$unc.mean[6]*Model.solved$q,3)/DATASET$I.iTraxx,2),"$&$",
                             round.fixed.length(100*round(moments.no.contagion$unc.mean[6]*Model.solved$q,3)/DATASET$I.iTraxx,2),"$&$",
                             round.fixed.length(100*round(moments.no.macro.effect$unc.mean[6]*Model.solved$q,3)/DATASET$I.iTraxx,2),"$&$",
                             round.fixed.length(100*round(moments.no.contagion.no.macro.effect$unc.mean[6]*Model.solved$q,3)/DATASET$I.iTraxx,2),
                             "$\\\\",sep=""),
                       "\\\\",
                       "\\hline"
  )
  
  latex.file <- paste("tables/table_targetsA_",Type.of.modif,".txt",sep="")
  write(latex.table, file = latex.file)

  
  
  latex.table <- NULL
  
  for(i in 1:length(DATASET$H.in.years.4.itraxx.indices)){
    obs.itraxx.series <- DATASET$ITRAXX.main[,i]
    mean.obs <- mean(obs.itraxx.series)
    
    modeled.itraxx.series <- res.prices$all.modeled.itraxx[,i]
    mean.modeled <- mean(modeled.itraxx.series)
    
    modeled.itraxx.series.no.contagion <- res.prices.no.contagion$all.modeled.itraxx[,i]
    mean.modeled.no.contagion <- mean(modeled.itraxx.series.no.contagion)
    
    modeled.itraxx.series.no.macro.effect <- res.prices.no.macro.effect$all.modeled.itraxx[,i]
    mean.modeled.no.macro.effect <- mean(modeled.itraxx.series.no.macro.effect)
    
    modeled.itraxx.series.no.contagion.no.macro.effect <- res.prices.no.contagion.no.macro.effect$all.modeled.itraxx[,i]
    mean.modeled.no.contagion.no.macro.effect <- mean(modeled.itraxx.series.no.contagion.no.macro.effect)
    
    latex.table <- rbind(latex.table,
                         paste(names.itraxx[i],"&$",round.fixed.length(10000*mean.obs,0),"$&$",
                               round.fixed.length(10000*mean.modeled,0),"$&$",
                               round.fixed.length(10000*mean.modeled.no.contagion,0),"$&$",
                               round.fixed.length(10000*mean.modeled.no.macro.effect,0),"$&$",
                               round.fixed.length(10000*mean.modeled.no.contagion.no.macro.effect,0),"$\\\\",sep=""))
  }
  
  
  
  latex.table <- rbind(latex.table,
                       "\\\\",
                       "\\hline",
                       "{\\bf Panel (b) ITRAXX tranches} (in b.p.)\\\\")
  count.matur <- 0
  for(matur.in.year in DATASET$H.in.years.4.tranches){
    count.matur <- count.matur + 1
    
    latex.table <- rbind(latex.table,
                         "\\hline")
    
    for(nb.tranche in 1:length(DATASET$vec.a.b.4.tranches)){
      eval(parse(text = gsub(" ","",paste("observations <- clean.DATA$Tranche_",names.tranches.2[nb.tranche],"_",
                                          toString(matur.in.year),"YR", sep=""))))
      
      modeled                 <- 10000*res.tranche.pricing$S.a.b[,matur.in.year*Model.solved$q,nb.tranche]
      modeled.no.contagion    <- 10000*res.tranche.pricing.no.contagion$S.a.b[,matur.in.year*Model.solved$q,nb.tranche]
      modeled.no.macro.effect <- 10000*res.tranche.pricing.no.macro.effect$S.a.b[,matur.in.year*Model.solved$q,nb.tranche]
      modeled.no.contagion.no.macro.effect <- 10000*res.tranche.pricing.no.contagion.no.macro.effect$S.a.b[,matur.in.year*Model.solved$q,nb.tranche]
      #modeled <- 10000*res.prices$all.model.implied.tranches[,(nb.tranche - 1)*3 + count.matur]
      
      indic.obs <- which(!is.na(observations))
      
      mean.obs <- mean(observations[indic.obs])
      mean.modeled                 <- mean(modeled[indic.obs])
      mean.modeled.no.contagion    <- max(mean(modeled.no.contagion[indic.obs]),0)
      mean.modeled.no.macro.effect <- max(mean(modeled.no.macro.effect[indic.obs]),0)
      mean.modeled.no.contagion.no.macro.effect <- max(mean(modeled.no.contagion.no.macro.effect[indic.obs]),0)
      
      latex.table <- rbind(latex.table,
                           paste(toString(matur.in.year)," years, Tranche: ",names.tranches[nb.tranche],"\\% &$",
                                 round.fixed.length(mean.obs,0),"$&$",
                                 round.fixed.length(mean.modeled,0),"$&$",
                                 round.fixed.length(mean.modeled.no.contagion,0),"$&$",
                                 round.fixed.length(mean.modeled.no.macro.effect,0),"$&$",
                                 round.fixed.length(mean.modeled.no.contagion.no.macro.effect,0),"$\\\\",sep=""))
      
    }
  }
  
  
  latex.table <- rbind(latex.table,
                       "\\\\",
                       "\\hline",
                       "{\\bf Panel (c) Implied Volatility} (in p.p.)\\\\",
                       "\\hline")
  
  for(i in 1:length(DATASET$H.in.years.4.stock.options)){
    obs.IV.series <- DATASET$IV[,i]
    mean.obs <- mean(obs.IV.series,na.rm=TRUE)
    
    modeled.IV.series <- res.prices$all.model.implied.vol[,i]
    mean.modeled <- mean(modeled.IV.series,na.rm = TRUE)
    
    modeled.IV.series.no.contagion <- res.prices.no.contagion$all.model.implied.vol[,i]
    mean.modeled.no.contagion <- mean(modeled.IV.series.no.contagion,na.rm = TRUE)
    
    modeled.IV.series.no.macro.effect <- res.prices.no.macro.effect$all.model.implied.vol[,i]
    modeled.IV.series.no.macro.effect[modeled.IV.series.no.macro.effect<0] <- NaN
    modeled.IV.series.no.macro.effect[modeled.IV.series.no.macro.effect==Inf] <- NaN
    mean.modeled.no.macro.effect <- mean(modeled.IV.series.no.macro.effect,na.rm = TRUE)
    
    modeled.IV.series.no.contagion.no.macro.effect <- res.prices.no.contagion.no.macro.effect$all.model.implied.vol[,i]
    modeled.IV.series.no.contagion.no.macro.effect[modeled.IV.series.no.contagion.no.macro.effect<0] <- NaN
    modeled.IV.series.no.contagion.no.macro.effect[modeled.IV.series.no.contagion.no.macro.effect==Inf] <- NaN
    mean.modeled.no.contagion.no.macro.effect <- mean(modeled.IV.series.no.contagion.no.macro.effect,na.rm = TRUE)
    
    latex.table <- rbind(latex.table,
                         paste("Maturity: ",toString(12*DATASET$H.in.years.4.stock.options[i])," months&$",
                               round.fixed.length(100*mean.obs,0),"\\%$&$",
                               round.fixed.length(100*mean.modeled,0),"\\%$&$",
                               round.fixed.length(100*mean.modeled.no.contagion,0),"\\%$&$",
                               round.fixed.length(100*mean.modeled.no.macro.effect,0),"\\%$&$",
                               round.fixed.length(100*mean.modeled.no.contagion.no.macro.effect,0),"\\%$\\\\",sep=""))
  }
  
  
  latex.table <- rbind(latex.table,
                       "\\\\",
                       "\\hline",
                       "\\multicolumn{5}{l}{{\\bf Panel (d) Conditional probability of $k$ default over estim. period}}\\\\",
                       "\\hline",
                       paste(
                         "$k=0$&--&$",
                         round.fixed.length(100*PD.baseline$P0,1),"\\%$&$",
                         round.fixed.length(100*PD.no.contagion$P0,1),"\\%$&$",
                         round.fixed.length(100*PD.no.macro.effect$P0,1),"\\%$&$",
                         round.fixed.length(100*PD.no.contagion.no.macro.effect$P0,1),
                         "\\%$\\\\",
                         "$k=1$&--&$",
                         round.fixed.length(100*PD.baseline$P1,1),"$\\%&$",
                         round.fixed.length(100*PD.no.contagion$P1,1),"$\\%&$",
                         round.fixed.length(100*PD.no.macro.effect$P1,1),"$\\%&$",
                         round.fixed.length(100*PD.no.contagion.no.macro.effect$P1,1),
                         "\\%$\\\\",
                         # "$k=2$&&$",
                         # round.fixed.length(100*PD.baseline$P2,2),"$&$",
                         # round.fixed.length(100*PD.no.contagion$P2,2),"$&$",
                         # round.fixed.length(100*PD.no.macro.effect$P2,2),"$&$",
                         # round.fixed.length(100*PD.no.contagion.no.macro.effect$P2,2),
                         # "$\\\\",
                         sep=""))
  
  if(Type.of.modif=="Reestimated"){
    latex.table <- rbind(latex.table,
                         "\\\\",
                         "\\hline",
                         "\\multicolumn{5}{l}{{\\bf Panel (e) Log-likelihood}}\\\\",
                         "\\hline",
                         paste(
                           "&&$",
                           round.fixed.length(loglik.baseline,1),"$&$",
                           round.fixed.length(loglik.no.contagion,1),"$&$",
                           round.fixed.length(loglik.no.macro.effect,1),"$&$",
                           round.fixed.length(loglik.no.contagion.no.macro.effect,1),
                           "$\\\\",
                           sep=""))
  }
  
  latex.table <- rbind(latex.table,
                       "\\hline")
  
  latex.file <- paste("tables/table_targetsB_",Type.of.modif,".txt",sep="")
  write(latex.table, file = latex.file)

  
}


