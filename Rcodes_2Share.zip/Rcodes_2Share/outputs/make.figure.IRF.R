# =======================================
# DISASTROUS DEFAULTS
# =======================================
# Christian Gouriéroux, Alain Monfort,
# Jean-Paul Renne and Sarah Mouabbi
# Contact: jean-paul.renne@unil.ch
# =======================================
# This version: October 2020
# =======================================
# Impulse Response Functions:
# This code produces IRFs. It displays Confidence Intervals
#   based on the Delta method (if indic.compute.CI == 1). To do so,
#   it requires Mat.var.cov, the covariance matrix of estimated param.
# The charts produced are:
#  1. Responses of number of default, conso and stock returns
#     (baseline model only)
#  2. Responses of conso in the 27 alternative models
# =======================================



print("")
print("")
print("==========================================================")
print(" Producing figure with IRFs (baseline model)")
print("==========================================================")



# Length of shock, in years:
Horiz <- 4

indic.compute.CI <- 1
eps <- .00001
nb.stdv <- 2 # Number of standard deviations (for confidence bands)

shock <- c(rep(0,n.F),c(1,rep(0,J-1)))
nb.sim <- DATASET$q * Horiz

# Compute central trajectories:
load(results.estim.KF)
Filter    <- rep(1,length(THETA.FULL))
Filter[param.2.exclude.from.optim] <- 0
theta     <- THETA.FULL[Filter==1]
Model.solved <- make.Model(theta,
                           THETA.FULL,
                           Model,
                           DATASET,
                           targets,
                           nb.iter = nb.iter)



# =======================================
#  1. Responses of number of default, conso and stock returns
#     (baseline model only)
# =======================================


# Baseline model:
IRFs.baseline <- make.IRFs(Model.solved,nb.sim,shock)
all.res               <- IRFs.baseline$all.res
impact.on.ns          <- cumsum(all.res[n.F+1,]+all.res[n.F+2,])
impact.on.Delta.c     <- IRFs.baseline$impact.on.cumsum.Delta.c
impact.on.var.Delta.c <- IRFs.baseline$impact.on.stdv.var.Delta.c
impact.on.g.d         <- IRFs.baseline$impact.on.g.d
impact.on.stock.index <- IRFs.baseline$impact.on.stock.index
impact.on.var.r_s     <- IRFs.baseline$impact.on.stdv.var.r_s


if(indic.compute.CI==1){
  
  Jacob.impact.on.ns          <- NULL
  Jacob.impact.on.Delta.c     <- NULL
  Jacob.impact.on.var.Delta.c <- NULL
  Jacob.impact.on.g.d         <- NULL
  Jacob.impact.on.stock.index <- NULL
  Jacob.impact.on.var.r_s     <- NULL
  
  for(i in 1:length(theta)){
    print(paste("Param No",toString(i), " (out of ",toString(length(theta)),")",sep=""))
    theta.i <- theta
    theta.i[i] <- theta.i[i] + eps
    Model.solved.i <- make.Model(theta.i,
                                 THETA.FULL,
                                 Model,
                                 DATASET,
                                 targets,
                                 nb.iter = nb.iter)
    
    IRFs.i <- make.IRFs(Model.solved.i,nb.sim,shock)
    all.res.i               <- IRFs.i$all.res
    impact.on.ns.i          <- cumsum(all.res.i[n.F+1,]+all.res.i[n.F+2,])
    impact.on.Delta.c.i     <- IRFs.i$impact.on.cumsum.Delta.c
    impact.on.var.Delta.c.i <- IRFs.i$impact.on.stdv.var.Delta.c
    impact.on.g.d.i         <- IRFs.i$impact.on.g.d
    impact.on.stock.index.i <- IRFs.i$impact.on.stock.index
    impact.on.var.r_s.i     <- IRFs.i$impact.on.stdv.var.r_s
    
    Diff.impact.on.ns.i          <- c(impact.on.ns.i - impact.on.ns)/eps
    Diff.impact.on.Delta.c.i     <- c(impact.on.Delta.c.i - impact.on.Delta.c)/eps
    Diff.impact.on.var.Delta.c.i <- c(impact.on.var.Delta.c.i - impact.on.var.Delta.c)/eps
    Diff.impact.on.g.d.i         <- c(impact.on.g.d.i - impact.on.g.d)/eps
    Diff.impact.on.stock.index.i <- c(impact.on.stock.index.i - impact.on.stock.index)/eps
    Diff.impact.on.var.r_s.i     <- c(impact.on.var.r_s.i - impact.on.var.r_s)/eps
    
    Jacob.impact.on.ns          <- cbind(Jacob.impact.on.ns,Diff.impact.on.ns.i)
    Jacob.impact.on.Delta.c     <- cbind(Jacob.impact.on.Delta.c,Diff.impact.on.Delta.c.i)
    Jacob.impact.on.var.Delta.c <- cbind(Jacob.impact.on.var.Delta.c,Diff.impact.on.var.Delta.c.i)
    Jacob.impact.on.g.d         <- cbind(Jacob.impact.on.g.d,Diff.impact.on.g.d.i)
    Jacob.impact.on.stock.index <- cbind(Jacob.impact.on.stock.index,Diff.impact.on.stock.index.i)
    Jacob.impact.on.var.r_s     <- cbind(Jacob.impact.on.var.r_s,Diff.impact.on.var.r_s.i)
  }
  
  # Compute stdv using the Delta method:
  var.impact.on.ns          <- apply(t(apply(Jacob.impact.on.ns,1,function(x){x %x% x})) *
                                       t(matrix(Mat.var.cov,length(theta)^2,dim(Jacob.impact.on.ns)[1])),1,sum)
  var.impact.on.Delta.c     <- apply(t(apply(Jacob.impact.on.Delta.c,1,function(x){x %x% x})) *
                                       t(matrix(Mat.var.cov,length(theta)^2,dim(Jacob.impact.on.ns)[1])),1,sum)
  var.impact.on.var.Delta.c <- apply(t(apply(Jacob.impact.on.var.Delta.c,1,function(x){x %x% x})) *
                                       t(matrix(Mat.var.cov,length(theta)^2,dim(Jacob.impact.on.ns)[1])),1,sum)
  var.impact.on.g.d         <- apply(t(apply(Jacob.impact.on.g.d,1,function(x){x %x% x})) *
                                       t(matrix(Mat.var.cov,length(theta)^2,dim(Jacob.impact.on.ns)[1])),1,sum)
  var.impact.on.stock.index <- apply(t(apply(Jacob.impact.on.stock.index,1,function(x){x %x% x})) *
                                       t(matrix(Mat.var.cov,length(theta)^2,dim(Jacob.impact.on.ns)[1])),1,sum)
  var.impact.on.var.r_s     <- apply(t(apply(Jacob.impact.on.var.r_s,1,function(x){x %x% x})) *
                                       t(matrix(Mat.var.cov,length(theta)^2,dim(Jacob.impact.on.ns)[1])),1,sum)
}



FILE = paste("/figures/Figure_IRFs.pdf",sep="")
pdf(file=paste(getwd(),FILE,sep=""),pointsize=10,width=6.5, height=4)

par(mfrow=c(1,3),plt=c(.1,.85,.15,.85))

plot((0:nb.sim)/DATASET$q,impact.on.ns,
     xlab="Time after shock (h, in years)",ylab="",las=1,
     ylim=c(0,1.2*max(impact.on.ns)),
     lwd=2,type="l",
     main=expression(paste("Number of systemic defaults",sep="")))

if(indic.compute.CI){
  polygon.upper <- impact.on.ns + nb.stdv*sqrt(var.impact.on.ns)
  polygon.lower <- impact.on.ns - nb.stdv*sqrt(var.impact.on.ns)
  polygon(c((0:nb.sim),(nb.sim:0))/DATASET$q,
          c(polygon.lower,polygon.upper[(nb.sim+1):1]),col="#99999944",border = NaN)
}

legend("bottomleft", # places a legend at the appropriate place c("Health","Defense"), # puts text in the legend 
       c(expression(paste(n[t+h]^s,sep=""))),
       lty=c(1,1), # gives the legend appropriate symbols (lines)       
       lwd=c(2,2), # line width
       col=c("black","dark grey"), # gives the legend lines the correct color and width
       pt.bg=c(NaN),
       pch = c(NaN),#symbols,
       pt.cex = c(NaN),
       bg="white",
       seg.len = 2
)

plot((0:nb.sim)/DATASET$q,100*impact.on.Delta.c,type="l",
     xlab="Time after shock (h, in years)",ylab="",las=1,
     ylim=c(-5,0),lwd=2,col="black",
     main=expression(paste("Consumption and stock index (%)",sep="")))
if(indic.compute.CI){
  # Cumulated impact on consumption:
  polygon.upper <- impact.on.Delta.c + nb.stdv*sqrt(var.impact.on.Delta.c)
  polygon.lower <- impact.on.Delta.c - nb.stdv*sqrt(var.impact.on.Delta.c)
  polygon(c((0:nb.sim),(nb.sim:0))/DATASET$q,
          100*c(polygon.lower,polygon.upper[(nb.sim+1):1]),col="#99999944",border = NaN)
  
}


par(new=TRUE)
plot((0:nb.sim)/DATASET$q,100*impact.on.stock.index,type="l",
     xlab="",ylab="",
     ylim=c(min(140*impact.on.stock.index),0),lwd=2,col="dark grey",
     xaxt='n',yaxt='n',
     main=expression(paste("Consumption and stock index (%)",sep="")))
aux <- seq(-20,0,by=5)
aux.str <- NULL
for(i in 1:length(aux)){
  aux.str <- cbind(aux.str,toString(aux[i]))
}
axis(side=4, at=aux, labels=aux.str,col="dark grey",
     col.ticks = "dark grey",
     col.axis = rgb(.4,.4,.4),
     las=1)


legend("bottomleft", # places a legend at the appropriate place c("Health","Defense"), # puts text in the legend 
       c(expression(paste(Delta,c[t+1],"+...+",Delta,c[t+h]," (l.h.s)",sep="")),
         expression(paste(r[t+1],"*","+...+",r[t+h],"*"," (r.h.s.)",sep=""))),
       lty=c(1,1), # gives the legend appropriate symbols (lines)       
       lwd=c(2,2), # line width
       col=c("black","dark grey"), # gives the legend lines the correct color and width
       pt.bg=c(NaN),
       #text.width = 2,
       #cex=1.0,# size of the text
       pch = c(NaN),#symbols,
       pt.cex = c(NaN),
       bg="white",
       seg.len = 2)


plot((0:nb.sim)/DATASET$q,100*impact.on.var.Delta.c,type="l",
     xlab="Time after shock (h, in years)",ylab="",las=1,
     ylim=c(0,5),lwd=2,col="black",
     main=expression("Vol. of consum. and stock returns (%)",sep=""))
if(indic.compute.CI){
  polygon.upper <- impact.on.var.Delta.c + nb.stdv*sqrt(var.impact.on.var.Delta.c)
  polygon.lower <- impact.on.var.Delta.c - nb.stdv*sqrt(var.impact.on.var.Delta.c)
  polygon(c((0:nb.sim),(nb.sim:0))/DATASET$q,
          100*c(polygon.lower,polygon.upper[(nb.sim+1):1]),col="#99999944",border = NaN)
}

par(new=TRUE)
plot((0:nb.sim)/DATASET$q,100*impact.on.var.r_s,type="l",
     xlab="Time after shock (h, in years)",ylab="",las=1,
     xaxt='n',yaxt='n',
     ylim=c(0,20),lwd=2,col="dark grey",
     main=expression("Vol. of consum. and stock returns (%)",sep=""))

aux <- seq(0,20,by=5)
aux.str <- NULL
for(i in 1:length(aux)){
  aux.str <- cbind(aux.str,toString(aux[i]))
}
axis(side=4, at=aux, labels=aux.str,
     col="dark grey",
     las=1,
     col.ticks = "dark grey",
     col.axis = rgb(.4,.4,.4))

legend("topright", # places a legend at the appropriate place c("Health","Defense"), # puts text in the legend 
       # c(expression(sqrt(Var[t+h](paste(r[t+h+1],"*",sep="")))),expression(sqrt(Var[t+h](paste(Delta,c[t+h+1],sep=""))))),
       c(expression(paste(sqrt(Var[t+h](paste(Delta,c[t+h+1],sep="")))," (l.h.s.)",sep="")),
         expression(paste(sqrt(Var[t+h](paste(r[t+h+1],"*",sep="")))," (r.h.s.)",sep=""))),
       lty=c(1,1), # gives the legend appropriate symbols (lines)       
       lwd=c(2,2), # line width
       col=c("black","dark grey"), # gives the legend lines the correct color and width
       pt.bg=c(NaN),
       #text.width = 2,
       #cex=1.0,# size of the text
       pch = c(NaN),#symbols,
       pt.cex = c(NaN),
       bg="white",
       seg.len = 2
)

dev.off()







# =======================================
#  2. Responses of conso
#     (27 alternative models)
# =======================================


nb.default.rate            <- length(vec.of.target.default.rate)
nb.stdv.delta.c            <- length(vec.of.stdv.delta.c.yoy)
nb.gamma                   <- length(vec.of.gamma)

all.parameterizations      <- matrix(NaN,nb.default.rate*nb.stdv.delta.c*nb.gamma,3)
all.parameterizations[,1]  <- vec.of.target.default.rate %x% rep(1,nb.stdv.delta.c)  %x% rep(1,nb.gamma)
all.parameterizations[,2]  <- rep(1,nb.default.rate) %x% vec.of.stdv.delta.c.yoy  %x% rep(1,nb.gamma)
all.parameterizations[,3]  <- rep(1,nb.default.rate) %x% rep(1,nb.stdv.delta.c)  %x% vec.of.gamma

nb.parameterizations <- dim(all.parameterizations)[1]

all.loglik       <- NULL
all.proba        <- NULL
all.impact.on.Delta.c <- NULL

for(JJJ in 1:nb.parameterizations){
  print(paste("Model No",toString(JJJ)," (out of ",toString(nb.parameterizations),")",sep=""))
  
  targets$target.default.rate <- all.parameterizations[JJJ,1]
  targets$stdv.delta.c.yoy    <- all.parameterizations[JJJ,2]
  Model$gamma                 <- all.parameterizations[JJJ,3]
  
  FILE <- paste("results/save_DefRate",toString(targets$target.default.rate),
                "_stdvDc",toString(targets$stdv.delta.c.yoy),
                "_gamma",toString(Model$gamma),".Rdat",sep="")
  load(file = FILE)
  
  Filter <- rep(1,length(Filter))
  
  Model.solved <- make.Model(THETA.FULL,
                             THETA.FULL,
                             Model,
                             DATASET,
                             targets,
                             nb.iter = nb.iter)
  
  # Use of Kalman filter to compute condi. proba of no default:
  res.KF <- prepare.state.space(Model.solved,DATASET)
  # Store log-likelihood:
  all.loglik <- c(all.loglik,
                  res.KF$loglik)
  AUX <- function.compute.param.4.stdv.computation(THETA.FULL,
                                                   THETA.FULL,
                                                   Model,
                                                   DATASET,targets,
                                                   nb.iter=nb.iter)
  transf.param <- AUX$vector.of.param
  beta <- transf.param[2]
  all.proba <- c(all.proba,
                 prod(exp(-beta*res.KF$r[,2])))
  
  # Compute IRFs:
  IRFs.baseline <- make.IRFs(Model.solved,nb.sim,shock)
  all.res               <- IRFs.baseline$all.res
  impact.on.ns          <- cumsum(all.res[n.F+1,]+all.res[n.F+2,])
  impact.on.Delta.c     <- IRFs.baseline$impact.on.cumsum.Delta.c
  impact.on.var.Delta.c <- IRFs.baseline$impact.on.stdv.var.Delta.c
  impact.on.g.d         <- IRFs.baseline$impact.on.g.d
  impact.on.stock.index <- IRFs.baseline$impact.on.stock.index
  impact.on.var.r_s     <- IRFs.baseline$impact.on.stdv.var.r_s
  
  all.impact.on.Delta.c <- cbind(all.impact.on.Delta.c,c(impact.on.Delta.c))
}

proba.threshold <- .01
indic.2.remove <- which(all.proba<proba.threshold)


FILE = paste("/figures/Figure_IRFs_diffModels",suffix,".pdf",sep="")
pdf(file=paste(getwd(),FILE,sep=""),pointsize=10,width=6, height=4)

par(plt=c(.12,.95,.2,.95))
plot((0:nb.sim)/DATASET$q,
     100*all.impact.on.Delta.c[,1],type="l",
     col="#44444444",
     ylim=100*c(1.1*min(all.impact.on.Delta.c),0),
     xlab="Time after shock (h, in years)",ylab="in percent")
for(j in 2:nb.parameterizations){
  if(j%in%indic.2.remove){
    lines((0:nb.sim)/DATASET$q,
          100*all.impact.on.Delta.c[,j],
          col="#44444444",lwd=3,lty=3)
  }else{
    lines((0:nb.sim)/DATASET$q,
          100*all.impact.on.Delta.c[,j],
          col="#44444444",lwd=3)
  }
}
indic.baseline <- round(nb.parameterizations/2)
lines((0:nb.sim)/DATASET$q,
      100*all.impact.on.Delta.c[,indic.baseline],col="black",lwd=4)

dev.off()


