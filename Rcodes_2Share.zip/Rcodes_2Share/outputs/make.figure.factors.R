# =======================================
# DISASTROUS DEFAULTS
# =======================================
# Christian Gouriéroux, Alain Monfort,
# Jean-Paul Renne and Sarah Mouabbi
# Contact: jean-paul.renne@unil.ch
# =======================================
# This version: October 2020
# =======================================
# This script aims at computing factors with confidence intervals
#    taking into account two types of uncertainty:
#    (a) parameters and (b) filtering of factors.
# For this script to work, one needs Mat.var.cov (computed in make.output.tables.R)
# Approach: Hamilton (1986)
# =======================================

print("")
print("")
print("==========================================================")
print(" Producing figure with x and y factors")
print("==========================================================")


# Initialize smoothed series and covariance matrices:
all.x     <- NULL
all.y     <- NULL
all.var.x <- NULL
all.var.y <- NULL

for(JJJ in 1:nb.replications){
  
  load(file=paste("results/saveSimulatedModels/simuated_model_",
                  toString(JJJ),".Rdat",sep=""))
  
  all.x <- cbind(all.x,res.KF$r_smooth[,1])
  all.y <- cbind(all.x,res.KF$r_smooth[,2])
  all.var.x <- cbind(all.var.x,res.KF$S_smooth[,1])
  all.var.y <- cbind(all.var.y,res.KF$S_smooth[,7])
}

total.var.x <- apply(all.x,1,var) + apply(all.var.x,1,mean)
total.var.y <- apply(all.y,1,var) + apply(all.var.y,1,mean)

total.sd.x <- sqrt(total.var.x)
total.sd.y <- sqrt(total.var.y)





# Compute baseline vector of parameters:
Filter <- rep(1,length(THETA.FULL))
Filter[param.2.exclude.from.optim]  <- 0
theta <- THETA.FULL[Filter==1]
# Solve model:
Model.solved <- make.Model(theta,
                           THETA.FULL,
                           Model,
                           DATASET,
                           targets,
                           nb.iter)
# Use Kalman smoother:
res.KF <- prepare.state.space(Model.solved,
                              DATASET,
                              indic.smooth = 1)
print(res.KF$loglik)



# ====================================
# Prepare pdf figure
# ====================================


FILE = paste("/figures/Figure_factors.pdf",sep="")
pdf(file=paste(getwd(),FILE,sep=""),pointsize=7,width=5, height=2)

par(plt=c(.15,.95,.15,.85),mfrow=c(1,2))

plot(clean.DATA$Date,res.KF$r_smooth[,1],type="l",
     ylim=c(0,1*max(res.KF$r_smooth[,1]+mult.fact.stdv*total.sd.x)),
     col="dark grey",
     lwd=2,
     xlab="",ylab="",las=1,main=expression(paste("Panel (a) - Estimates of ",x[t],sep="")))# Model
polygon.lower <- pmax(res.KF$r_smooth[,1]-mult.fact.stdv*total.sd.x,0)
polygon.upper <- res.KF$r_smooth[,1]+mult.fact.stdv*total.sd.x
polygon(c(clean.DATA$Date,clean.DATA$Date[length(clean.DATA$Date):1]),
        c(polygon.lower,polygon.upper[length(DATASET$Date):1]),col="gray80",border = NaN)
lines(clean.DATA$Date,res.KF$r_smooth[,1],col="black",lwd=2,lty=1)# Data
abline(h=0,lty=3)

plot(clean.DATA$Date,res.KF$r_smooth[,2],type="l",
     ylim=c(0,1*max(res.KF$r_smooth[,2]+mult.fact.stdv*total.sd.y)),
     col="dark grey",
     lwd=2,
     xlab="",ylab="",las=1,main=expression(paste("Panel (b) - Estimates of ",y[t],sep="")))# Model
polygon.lower <- pmax(res.KF$r_smooth[,2]-mult.fact.stdv*total.sd.y,0)
polygon.upper <- res.KF$r_smooth[,2]+mult.fact.stdv*total.sd.y
polygon(c(clean.DATA$Date,clean.DATA$Date[length(clean.DATA$Date):1]),
        c(polygon.lower,polygon.upper[length(DATASET$Date):1]),col="gray80",border = NaN)
lines(clean.DATA$Date,res.KF$r_smooth[,2],col="black",lwd=2,lty=1)# Data
abline(h=0,lty=3)

dev.off()




