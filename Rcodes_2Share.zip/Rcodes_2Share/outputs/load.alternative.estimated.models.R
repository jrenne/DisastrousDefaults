# =======================================
# DISASTROUS DEFAULTS
# =======================================
# Christian Gouriéroux, Alain Monfort,
# Jean-Paul Renne and Sarah Mouabbi
# Contact: jean-paul.renne@unil.ch
# =======================================
# This version: October 2020
# =======================================
# This script prepares an Rdat file,
# namely "results/Saved_AlternativeSolvedModels/save_EstimatedAlternativeModels.Rdat",
# that contains the parameterizations of the estimated
# alternative models (w/o contagion and macro-effects).
# These models are named I, II, III and IV in the paper.
# In these models, contagion and/or macro-effects are switched off,
# and then re-estimated.
# =======================================




# ======================================================
# Load model no contag.
load(results.estim.KF.noContag)
param.4.grid <- .3
Filter    <- rep(1,length(THETA.FULL))
Filter[param.2.exclude.from.optim] <- 0
theta     <- THETA.FULL[Filter==1]
Model.solved.no.contagion <- make.Model(theta,
                                        THETA.FULL,
                                        Model,
                                        DATASET,
                                        targets,
                                        nb.iter = nb.iter)
res.KF <- prepare.state.space(Model.solved.no.contagion,
                              DATASET,indic.smooth = 1)
loglik.no.contagion <- res.KF$loglik
print(paste("Log-likelihood: ",res.KF$loglik,sep=""))# 4235.077 in last version
X.complete.no.contagion <- list(
  F   = cbind(matrix(0,dim(res.KF$r_smooth)[1],J),res.KF$r_smooth[,1:2]),
  N   = matrix(0,dim(res.KF$r)[1],J),
  N_1 = matrix(0,dim(res.KF$r)[1],J)
)
PD.no.contagion <- compute.proba.NB.def(Model.solved.no.contagion,
                                        res.KF)


# ======================================================
# Load model no macro effects.
load(results.estim.KF.noMacroEffect)
param.4.grid <- .5
Filter    <- rep(1,length(THETA.FULL))
Filter[param.2.exclude.from.optim] <- 0
theta     <- THETA.FULL[Filter==1]
Model.solved.no.macro.effect <- make.Model(theta,
                                           THETA.FULL,
                                           Model,
                                           DATASET,
                                           targets,
                                           nb.iter = nb.iter)
res.KF <- prepare.state.space(Model.solved.no.macro.effect,
                              DATASET,indic.smooth = 1)
loglik.no.macro.effect <- res.KF$loglik
print(paste("Log-likelihood: ",res.KF$loglik,sep=""))# 4235.077 in last version
X.complete.no.macro.effect <- list(
  F   = cbind(matrix(0,dim(res.KF$r_smooth)[1],J),res.KF$r_smooth[,1:2]),
  N   = matrix(0,dim(res.KF$r)[1],J),
  N_1 = matrix(0,dim(res.KF$r)[1],J)
)
PD.no.macro.effect <- compute.proba.NB.def(Model.solved.no.macro.effect,
                                           res.KF)

# ======================================================
# Load model no macro effects, no contagion.
load(results.estim.KF.noContag.noMacroEffect)
param.4.grid <- .3
Filter    <- rep(1,length(THETA.FULL))
Filter[param.2.exclude.from.optim] <- 0
theta     <- THETA.FULL[Filter==1]
Model.solved.no.contagion.no.macro.effect <- make.Model(theta,
                                                        THETA.FULL,
                                                        Model,
                                                        DATASET,
                                                        targets,
                                                        nb.iter = nb.iter)
res.KF <- prepare.state.space(Model.solved.no.contagion.no.macro.effect,
                              DATASET,indic.smooth = 1)
loglik.no.contagion.no.macro.effect <- res.KF$loglik
print(paste("Log-likelihood: ",res.KF$loglik,sep=""))# 4235.077 in last version
X.complete.no.contagion.no.macro.effect <- list(
  F   = cbind(matrix(0,dim(res.KF$r_smooth)[1],J),res.KF$r_smooth[,1:2]),
  N   = matrix(0,dim(res.KF$r)[1],J),
  N_1 = matrix(0,dim(res.KF$r)[1],J)
)
PD.no.contagion.no.macro.effect <- compute.proba.NB.def(Model.solved.no.contagion.no.macro.effect,
                                                        res.KF)


# ======================================================
# Load baseline model.
load(results.estim.KF)
param.4.grid <- .3
Filter    <- rep(1,length(THETA.FULL))
Filter[param.2.exclude.from.optim] <- 0
theta     <- THETA.FULL[Filter==1]
Model.solved <- make.Model(theta,
                           THETA.FULL,
                           Model,
                           DATASET,
                           targets,
                           nb.iter = nb.iter)
res.KF <- prepare.state.space(Model.solved,
                              DATASET,indic.smooth = 1)
loglik.baseline <- res.KF$loglik
print(paste("Log-likelihood: ",res.KF$loglik,sep=""))
X.complete <- list(
  F   = cbind(matrix(0,dim(res.KF$r)[1],J),res.KF$r_smooth[,1:2]),
  N   = matrix(0,dim(res.KF$r)[1],J),
  N_1 = matrix(0,dim(res.KF$r)[1],J)
)
PD.baseline <- compute.proba.NB.def(Model.solved,
                                    res.KF)

# Save models:
save(Model.solved,
     Model.solved.no.contagion,
     Model.solved.no.macro.effect,
     Model.solved.no.contagion.no.macro.effect,
     loglik.baseline,
     loglik.no.contagion,
     loglik.no.macro.effect,
     loglik.no.contagion.no.macro.effect,
     X.complete,
     X.complete.no.contagion,
     X.complete.no.macro.effect,
     X.complete.no.contagion.no.macro.effect,
     file="results/Saved_AlternativeSolvedModels/save_EstimatedAlternativeModels.Rdat")


