# =======================================
# DISASTROUS DEFAULTS
# =======================================
# Christian Gouriéroux, Alain Monfort,
# Jean-Paul Renne and Sarah Mouabbi
# Contact: jean-paul.renne@unil.ch
# =======================================
# This version: October 2020
# =======================================
# This script produces the chart showing
# the distribution of consumption.
# =======================================


print("")
print("")
print("==========================================================")
print(" Producing chart with uncond. distribution of consumption")
print("==========================================================")


# load baseline results
load(results.estim.KF)
Filter <- rep(1,length(THETA.FULL))
theta <- THETA.FULL[Filter==1]
loglik.KF(theta,
          THETA.FULL,
          Model,
          DATASET,
          targets,
          nb.iter = nb.iter)
Model.solved <- make.Model(theta,
                           THETA.FULL,
                           Model,
                           DATASET,
                           targets,
                           nb.iter = nb.iter)
moments <- compute.moments(Model.solved)

# Compute std dev of that component of Delta c that is accounted for by X_t (excluding eps_{c,t}):
stdv.delta.c <- sqrt(t(Model.solved$Mu.c$A)%*%moments$unc.var[1:5,1:5]%*%Model.solved$Mu.c$A)

V <- moments$unc.var
PHI <- moments$PHI
Var.X.q <- Model.solved$q * V
for(j in 1:(Model.solved$q-1)){
  Var.X.q <- Var.X.q + 2 * (Model.solved$q-j) * (PHI%^%j %*% V + V %*% t(PHI%^%j))
}
var.delta.c.annual <- t(Model.solved$Mu.c$A) %*% Var.X.q[1:5,1:5] %*% Model.solved$Mu.c$A +
  Model.solved$q * Model.solved$sigma.c^2


nb.sim <- 10000
res.simul <- simul.Model(Model.solved,nb.sim)

# Check variance formula:
cbind(V[1:5,1:5],var(res.simul$F)[1:5,1:5])



plot(res.simul$F[,1],type="l")
sim.delta.c      <- Model.solved$Mu.c$D + res.simul$F %*% Model.solved$Mu.c$A  +
  rnorm(nb.sim) * Model.solved$sigma.c
AUX <- Model.solved$Mu.c$A
AUX[1:3] <- 0
sim.delta.c.no.w <- Model.solved$Mu.c$D + res.simul$F %*% AUX +
  rnorm(nb.sim) * Model.solved$sigma.c
sim.delta.c.q <-
  sim.delta.c[Model.solved$q:nb.sim]+
  sim.delta.c[(Model.solved$q-1):(nb.sim-1)]+
  sim.delta.c[(Model.solved$q-2):(nb.sim-2)]+
  sim.delta.c[(Model.solved$q-3):(nb.sim-3)]+
  sim.delta.c[(Model.solved$q-4):(nb.sim-4)]+
  sim.delta.c[(Model.solved$q-5):(nb.sim-5)]
sim.delta.c.q.no.w <-
  sim.delta.c.no.w[Model.solved$q:nb.sim]+
  sim.delta.c.no.w[(Model.solved$q-1):(nb.sim-1)]+
  sim.delta.c.no.w[(Model.solved$q-2):(nb.sim-2)]+
  sim.delta.c.no.w[(Model.solved$q-3):(nb.sim-3)]+
  sim.delta.c.no.w[(Model.solved$q-4):(nb.sim-4)]+
  sim.delta.c.no.w[(Model.solved$q-5):(nb.sim-5)]
A <- density(sim.delta.c.q)
plot(A$x,A$y,type="l",xlim=c(-.03,.05))
A <- density(sim.delta.c.q.no.w)
lines(A$x,A$y,col="red")

#print(cbind(sd(sim.delta.c.q),sqrt(var.delta.c.annual)))


nb.syst.def <- res.simul$N[,1]-res.simul$N_1[,1]
sim.delta.c.q.NaN <- c(rep(NaN,Model.solved$q-1),sim.delta.c.q)
lag <- Model.solved$q
plot(nb.syst.def[1:(nb.sim-lag)],sim.delta.c.q.NaN[(lag+1):nb.sim])


# Calibrate standard deviation of Gaussian part of Delta(c):
sigma_c <- Model.solved$sigma.c


Maturity.4.indicator <- c(20) # in years

Model.aux <- Model.solved
Model.aux$Delta <- NULL
Model.aux$Eta <- NULL

Mu.c <- Model.solved$Mu.c

H <- matrix(Model.solved$q*Maturity.4.indicator,
            length(Maturity.4.indicator),1)

a    <- list(A = matrix(0,n.F,1),
             B = matrix(0,J,1),
             C = matrix(0,J,1),
             D = matrix(0,1,1))
b    <- list(A = matrix(Mu.c$A,n.F,1),
             B = matrix(Mu.c$B,ncol=1),
             C = matrix(Mu.c$C,J,1),
             D = matrix(0,1,1),
             E = matrix(Model$sigma.c,1,1) # GAUSSIAN TERM
)
a.no.w <- a
b.no.w <- b
b.no.w$A[1:2,] <- 0

vector.of.decrease.in.conso <- c(seq(-0.05,.07,by=.0025))

# Current value of state space vector:
XXX <- list(F   = matrix(rep(1,n.F),nrow=1),
            N   = matrix(0,1,3),
            N_1 = matrix(0,1,3))
XXX <- list(F   = matrix(moments$unc.mean[1:n.F],nrow=1),
            N   = matrix(moments$unc.mean[(n.F+1):(n.F+3)],1,3),
            N_1 = matrix(moments$unc.mean[(n.F+1):(n.F+3)],1,3))

CDF <- NULL
CDF.no.w <- NULL
for(threshold in vector.of.decrease.in.conso){
  print(paste("Computing cdf at ",toString(threshold),
              " (max is ",toString(max(vector.of.decrease.in.conso)),")",sep=""))
  
  y <- threshold - Model.solved$q * 1 * Mu.c$D
  
  YY <- g(Model.aux,a,b,y,H,XXX,min.log.v=-10,max.v=100000,step=.005,
          indic_cumul = 1,indic.for.one.year = Model.solved$q)
  YY.aux <- matrix(YY,ncol=1)
  CDF <- cbind(CDF,YY.aux)
  
  YY <- g(Model.aux,a.no.w,b.no.w,y,H,XXX,min.log.v=-10,max.v=100000,step=.005,
          indic_cumul = 1,indic.for.one.year = Model.solved$q)
  YY.aux <- matrix(YY,ncol=1)
  CDF.no.w <- cbind(CDF.no.w,YY.aux)
}


require(splines)
spl1 <- smooth.spline(vector.of.decrease.in.conso,CDF,nknots = 8)
step <- .001
xx <- seq(-.2,.06,by=step)
variable.spl1 <- predict(spl1,xx)$y
plot(vector.of.decrease.in.conso,CDF)
lines(xx,variable.spl1,col="red")
n <- length(variable.spl1)
pdf.spline <- (variable.spl1[2:n] - variable.spl1[1:(n-1)])/step

n <- length(CDF)
pdf      <- (CDF[2:n]-CDF[1:(n-1)])/(vector.of.decrease.in.conso[2:n]-vector.of.decrease.in.conso[1:(n-1)])
pdf.no.w <- (CDF.no.w[2:n]-CDF.no.w[1:(n-1)])/(vector.of.decrease.in.conso[2:n]-vector.of.decrease.in.conso[1:(n-1)])

expectation.based.on.pdf <- sum(pdf * vector.of.decrease.in.conso[2:n] * (vector.of.decrease.in.conso[2:n]-vector.of.decrease.in.conso[1:(n-1)]))
variance.based.on.pdf <- sum(pdf * (vector.of.decrease.in.conso[2:n]^2 - expectation.based.on.pdf^2) * (vector.of.decrease.in.conso[2:n]-vector.of.decrease.in.conso[1:(n-1)]))
sd.based.on.pdf <- sqrt(variance.based.on.pdf)

x.axis <- .5*vector.of.decrease.in.conso[1:(n-1)] + .5*vector.of.decrease.in.conso[2:n]
size.bin <- vector.of.decrease.in.conso[2:n] - vector.of.decrease.in.conso[1:(n-1)]
plot(x.axis,pdf,type="l")

# compute Expectation:
print(sum(x.axis*pdf*size.bin))
abline(h=0,col="grey")

awm19up18 <- read.csv("../data/AWM/awm19up18.csv")
T.awm <- dim(awm19up18)[1]
Delta.c.annual <- log(awm19up18$PCR[5:T.awm]/awm19up18$PCR[1:(T.awm-4)])

kernel.conso <- density(Delta.c.annual)
lines(kernel.conso$x,kernel.conso$y,col="blue")

dc.AWM <- log(awm19up18$PCR[2:T.awm]/awm19up18$PCR[1:(T.awm-1)])
var.quarterly.dc.AWM <- sd(dc.AWM)
moments.model.solved <- compute.moments(Model.solved)
aux <- matrix(c(Model.solved$Mu.c$A,Model.solved$Mu.c$B),ncol=1)
var.dc.model <- t(aux) %*% moments.model.solved$unc.var %*% aux
print(sqrt(cbind(var.quarterly.dc.AWM,var.dc.model)))

library(mFilter)
res.filter <- cffilter(dc.AWM,pl=2,pu=4)
plot(dc.AWM,type="l")
lines(res.filter$trend,col="red")
print(var(res.filter$cycle))
print(var(res.filter$trend))


# =================================
# Prepare plot
# =================================

FILE = "/figures/Figure_distri_conso.pdf"
pdf(file=paste(getwd(),FILE,sep=""),pointsize=7,width=6, height=2.5)

par(mfrow=c(1,2),plt=c(.1,.95,.2,.8))

plot(100*x.axis,pdf,
     ylim=c(0,1.2*max(kernel.conso$y)),
     type="l",xlab = "Year-on-year consumption growth (in percent)",ylab="",lwd=2,main="Panel (a) - P.d.f.")
abline(h=0,col="grey")
lines(100*kernel.conso$x,kernel.conso$y,col="black",lwd=3,lty=3)


legend("topleft", # places a legend at the appropriate place c("Health","Defense"), # puts text in the legend 
       c("Model","Data (AWM)"),#,"Model (without default effects)"),
       lty=c(1,3), # gives the legend appropriate symbols (lines)       
       lwd=c(1,3), # line width
       col=c("black","black"), # gives the legend lines the correct color and width
       bg="white",
       seg.len = 3
)


plot(100*x.axis,log(CDF[2:length(CDF)]),
     ylim=c(-6,2.5),yaxt="n",
     type="l",xlab = "Year-on-year consumption growth (in percent)",ylab="",lwd=2,main="Panel (b) - C.d.f.")

where <- c(.01,.02,.05,.25,.5,.95)
axis(side = 2,
     at = log(where),
     labels=FALSE, # because we will use mtext to choose the color
     col="black")
mtext(side = 2, text = paste(100*where,"%",sep=""), at = log(where),
      col = "black",
      line = 1,
      las=1 # vertical reading
)

abline(h=0,col="grey")
lines(100*x.axis,log(CDF.no.w[2:length(CDF)]),col="dark grey",lwd=2,lty=2)


legend("topleft", # places a legend at the appropriate place c("Health","Defense"), # puts text in the legend 
       c("Model",expression(paste("Model (without disastrous events, i.e. ",mu[c*','*w],"=0)",sep=""))),#,"Model (without default effects)"),
       lty=c(1,2), # gives the legend appropriate symbols (lines)       
       lwd=c(2,2), # line width
       col=c("black","dark grey"), # gives the legend lines the correct color and width
       bg="white",
       seg.len = 3
)

dev.off()

