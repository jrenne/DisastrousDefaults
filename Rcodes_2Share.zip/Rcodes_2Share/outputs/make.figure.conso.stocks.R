# =======================================
# DISASTROUS DEFAULTS
# =======================================
# Christian Gouriéroux, Alain Monfort,
# Jean-Paul Renne and Sarah Mouabbi
# Contact: jean-paul.renne@unil.ch
# =======================================
# This version: October 2020
# =======================================
# This script produces 3 charts:
#  1. the chart showing the fit of
#     consumption growth and stock returns.
#  2. the chart showing the fit of
#     consumption growth when contagion and/or macro effects are killed
#  3. the chart showing the fit of
#     consumption growth and stock returns for the
#     27 alternative specifications.
# =======================================


print("")
print("")
print("==========================================================")
print(" Producing figures of fit of consumption / stock returns")
print("==========================================================")



# Load baseline results:
load(results.estim.KF)
Filter <- rep(1,length(Filter))
Model.solved <- make.Model(THETA.FULL,
                           THETA.FULL,
                           Model,
                           DATASET,
                           targets,
                           nb.iter = nb.iter)
res.KF <- prepare.state.space(Model.solved,
                              DATASET,
                              indic.smooth = 1)
print(paste("Log-likelihood: ",res.KF$loglik,sep=""))



# =======================================
#  1. Chart showing the fit of
#     consumption growth and stock returns.
# =======================================



plot(res.KF$r_smooth[,1],type="l")
plot(res.KF$r_smooth[,2],type="l")

X.complete <- list(
  F   = cbind(matrix(0,dim(res.KF$r_smooth)[1],J),res.KF$r_smooth[,1:2]),
  N   = matrix(0,dim(res.KF$r_smooth)[1],J),
  N_1 = matrix(0,dim(res.KF$r_smooth)[1],J)
)

# compute modeled consumption growth:
delta.c.est <- (X.complete$F) %*% Model.solved$Mu.c$A +
  (X.complete$N) %*% Model.solved$Mu.c$B +
  (X.complete$N_1) %*% Model.solved$Mu.c$C + c(Model.solved$Mu.c$D)

# compute modeled stock returns:
XX   <- res.KF$r_smooth[,1:2]
XX_1 <- res.KF$r_smooth[,4:5]
r.star <- 100*( (XX -XX_1) %*% Model.solved$A.1$A[(J+1):(J+2)] +
                  XX %*% Model.solved$Mu.d$A[(J+1):(J+2)] + Model.solved$Mu.d$D)

d.EUROSTOXX <- 100*log(clean.DATA$EUROSTOXX50/c(clean.DATA$EUROSTOXX50[1],clean.DATA$EUROSTOXX50[1:(dim(XX)[1]-1)]))

# correlation between observed and modeled stock returns:
print(cor(d.EUROSTOXX,r.star))




FILE = paste("/figures/Figure_stock_returns2",suffix,".pdf",sep="")
pdf(file=paste(getwd(),FILE,sep=""),pointsize=7,width=6, height=2.5)

par(plt=c(.15,.95,.15,.85),mfrow=c(1,2))

plot(clean.DATA$Date,r.star,type="l",lwd=2,
     ylim=c(min(d.EUROSTOXX,r.star),max(d.EUROSTOXX,r.star)),xlab="",ylab="in percent",las=1,
     main="Panel (a) - Stock returns")
#points(clean.DATA$Date,r.star,pch=4,lwd=2)
abline(h=0,col="grey",lty=3)
lines(clean.DATA$Date,d.EUROSTOXX,lwd=2,col="dark grey")

legend("topright", # places a legend at the appropriate place c("Health","Defense"), # puts text in the legend 
       c("Data","Model"),
       lty=c(1,1), # gives the legend appropriate symbols (lines)       
       lwd=c(2,2), # line width
       col=c("dark grey","black"), # gives the legend lines the correct color and width
       pt.bg=c(NaN),
       #text.width = 2,
       #cex=1.0,# size of the text
       pch = c(NaN),#symbols,
       pt.cex = c(NaN),
       bg="white",
       seg.len = 2
)

plot(clean.DATA$Date,600*delta.c.est,type="l",lwd=2,
     ylim=c(-3,5),xlab="",ylab="in percent",las=1,
     main="Panel (b) - Consumption growth")
abline(h=0,col="grey",lty=3)
lines(clean.DATA$Date,600*clean.DATA$data.delta.c,lwd=2,lty=3,col="dark grey")
lines(macro_data$Date,400*macro_data$data.delta.c,col="dark grey",lwd=2,lty=1)

legend("topright", # places a legend at the appropriate place c("Health","Defense"), # puts text in the legend 
       c("Data (quarterly)","Data (bi-monthly)","Model"),
       lty=c(1,3,1), # gives the legend appropriate symbols (lines)       
       lwd=c(2,2,2), # line width
       col=c("dark grey","dark grey","black"), # gives the legend lines the correct color and width
       pt.bg=c(NaN),
       #text.width = 2,
       #cex=1.0,# size of the text
       pch = c(NaN),#symbols,
       pt.cex = c(NaN),
       bg="white",
       seg.len = 2
)

dev.off()







# =======================================
#  2. Chart showing the fit of
#     consumption growth when contagion and/or macro effects are killed
# =======================================

# Load alternative models:
FILE <- paste(file="results/Saved_AlternativeSolvedModels/save_EstimatedAlternativeModels.Rdat",sep="")
load(file=FILE)

# compute model-implied consumption growth:
delta.c.est.no.contagion <- (X.complete.no.contagion$F) %*% Model.solved.no.contagion$Mu.c$A +
  (X.complete.no.contagion$N) %*% Model.solved.no.contagion$Mu.c$B +
  (X.complete.no.contagion$N_1) %*% Model.solved.no.contagion$Mu.c$C + c(Model.solved.no.contagion$Mu.c$D)

delta.c.est.no.macro.effect <- (X.complete.no.macro.effect$F) %*% Model.solved.no.macro.effect$Mu.c$A +
  (X.complete.no.macro.effect$N) %*% Model.solved.no.macro.effect$Mu.c$B +
  (X.complete.no.macro.effect$N_1) %*% Model.solved.no.macro.effect$Mu.c$C + c(Model.solved.no.macro.effect$Mu.c$D)

delta.c.est.no.contagion.no.macro.effect <- (X.complete.no.contagion.no.macro.effect$F) %*% Model.solved.no.contagion.no.macro.effect$Mu.c$A +
  (X.complete.no.contagion.no.macro.effect$N) %*% Model.solved.no.contagion.no.macro.effect$Mu.c$B +
  (X.complete.no.contagion.no.macro.effect$N_1) %*% Model.solved.no.contagion.no.macro.effect$Mu.c$C + c(Model.solved.no.contagion.no.macro.effect$Mu.c$D)


FILE = paste("/figures/Figure_conso_fit_Alternative",suffix,".pdf",sep="")
pdf(file=paste(getwd(),FILE,sep=""),pointsize=7,width=7, height=4)

par(plt=c(.05,.95,.1,.95),
    mfrow=c(1,1))

plot(clean.DATA$Date,600*clean.DATA$data.delta.c,type="l",lwd=2,
     col="dark grey",
     ylim=c(-10,3),xlab="",ylab="in percent",
     las=1)
abline(h=0,col="grey",lty=3)
lines(clean.DATA$Date,600*delta.c.est,lwd=2,lty=1,col="black")
points(clean.DATA$Date,600*delta.c.est.no.contagion,lwd=1,
       pch=1,lty=3,col="black")
lines(clean.DATA$Date,600*delta.c.est.no.macro.effect,lwd=1,type="b",
       pch=2,col="black")
points(clean.DATA$Date,600*delta.c.est.no.contagion.no.macro.effect,lwd=1,
      pch=3,lty=3,col="black")

legend("bottomright", # places a legend at the appropriate place c("Health","Defense"), # puts text in the legend 
       c("Data (bi-monthly smoothed consumption)",
         "Baseline model (I)",
         "Model with no contagion (II)",
         "Model with no macro effects (III)",
         "Model with no contagion and no macro effect (IV)"),
       lty=c(1,1,NaN,NaN,NaN), # gives the legend appropriate symbols (lines)       
       lwd=c(2,2,1,1,1), # line width
       col=c("dark grey","black","black","black","black"), # gives the legend lines the correct color and width
       pt.bg=c(NaN),
       #text.width = 2,
       #cex=1.0,# size of the text
       pch = c(NaN,NaN,1,2,3),#symbols,
       pt.cex = c(1),
       bg="white",
       seg.len = 2
)

dev.off()







# =======================================
#  3. Chart showing the fit of
#     consumption growth and stock returns for the
#     27 alternative specifications.
# =======================================

logl.Diff.max <- 100


nb.default.rate            <- length(vec.of.target.default.rate)
nb.stdv.delta.c            <- length(vec.of.stdv.delta.c.yoy)
nb.gamma                   <- length(vec.of.gamma)
all.parameterizations      <- matrix(NaN,nb.default.rate*nb.stdv.delta.c*nb.gamma,3)
all.parameterizations[,1]  <- vec.of.target.default.rate %x% rep(1,nb.stdv.delta.c)  %x% rep(1,nb.gamma)
all.parameterizations[,2]  <- rep(1,nb.default.rate) %x% vec.of.stdv.delta.c.yoy  %x% rep(1,nb.gamma)
all.parameterizations[,3]  <- rep(1,nb.default.rate) %x% rep(1,nb.stdv.delta.c)  %x% vec.of.gamma

nb.parameterizations <- dim(all.parameterizations)[1]

all.model.r.star      <- NULL
all.model.delta.c.est <- NULL
all.loglik            <- NULL

for(JJJ in 1:nb.parameterizations){
  
  print(paste("Model No",toString(JJJ)," (out of ",toString(nb.parameterizations),")",sep=""))
  
  targets$target.default.rate <- all.parameterizations[JJJ,1]
  targets$stdv.delta.c.yoy    <- all.parameterizations[JJJ,2]
  Model$gamma                 <- all.parameterizations[JJJ,3]
  
  FILE <- paste("results/save_DefRate",toString(targets$target.default.rate),
                "_stdvDc",toString(targets$stdv.delta.c.yoy),
                "_gamma",toString(Model$gamma),".Rdat",sep="")
  load(file = FILE)
  
  Filter <- rep(1,length(Filter))
  Model.solved <- make.Model(THETA.FULL,
                             THETA.FULL,
                             Model,
                             DATASET,
                             targets,
                             nb.iter = nb.iter)
  
  # Use of Kalman filter to compute condi. proba of no default:
  res.KF <- prepare.state.space(Model.solved,
                                DATASET,
                                indic.smooth = 1)
  
  all.loglik <- c(all.loglik,
                  res.KF$loglik)
  
  X.complete <- list(
    F   = cbind(matrix(0,dim(res.KF$r_smooth)[1],J),
                res.KF$r_smooth[,1:2]),
    N   = matrix(0,dim(res.KF$r)[1],J),
    N_1 = matrix(0,dim(res.KF$r)[1],J)
  )
  
  # compute modeled consumption growth:
  delta.c.est <- (X.complete$F) %*% Model.solved$Mu.c$A +
    (X.complete$N) %*% Model.solved$Mu.c$B +
    (X.complete$N_1) %*% Model.solved$Mu.c$C + c(Model.solved$Mu.c$D)
  
  # compute modeled stock returns:
  XX   <- res.KF$r_smooth[,1:2]
  XX_1 <- res.KF$r_smooth[,4:5]
  r.star <- 100*( (XX -XX_1) %*% Model.solved$A.1$A[(J+1):(J+2)] +
                    XX %*% Model.solved$Mu.d$A[(J+1):(J+2)] + Model.solved$Mu.d$D)
  
  all.model.r.star      <- cbind(all.model.r.star,r.star)
  all.model.delta.c.est <- cbind(all.model.delta.c.est,delta.c.est)
}




indic.baseline       <- round(nb.parameterizations/2+1)
r.star.baseline      <- all.model.r.star[,indic.baseline]
delta.c.est.baseline <- all.model.delta.c.est[,indic.baseline]
loglik.baseline      <- all.loglik[indic.baseline]



FILE = paste("/figures/Figure_stock_returns_27",suffix,".pdf",sep="")
pdf(file=paste(getwd(),FILE,sep=""),pointsize=7,width=7, height=3)

par(plt=c(.15,.95,.1,.85),mfrow=c(1,2))

plot(clean.DATA$Date,r.star.baseline,type="l",lwd=3,
     ylim=c(min(d.EUROSTOXX,r.star),max(d.EUROSTOXX,r.star.baseline)),
     xlab="",ylab="in percent",las=1,
     lty=3,
     main="Panel (a) - Stock returns")
#points(clean.DATA$Date,r.star,pch=4,lwd=2)
abline(h=0,col="grey",lty=3)
lines(clean.DATA$Date,d.EUROSTOXX,lwd=2,col="black")

for(JJJ in 1:nb.parameterizations){
  lines(clean.DATA$Date,all.model.r.star[,JJJ],col="#44444477")
}
lines(clean.DATA$Date,r.star.baseline,lwd=3,lty=3)

legend("bottomright", # places a legend at the appropriate place c("Health","Defense"), # puts text in the legend 
       c("Data","Baseline model","Alternative models"),
       lty=c(1,3,1), # gives the legend appropriate symbols (lines)       
       lwd=c(2,3,2), # line width
       col=c("black","black","#44444477"), # gives the legend lines the correct color and width
       pt.bg=c(NaN),
       #text.width = 2,
       #cex=1.0,# size of the text
       pch = c(NaN),#symbols,
       pt.cex = c(NaN),
       bg="white",
       seg.len = 3
)




plot(clean.DATA$Date,600*delta.c.est.baseline,type="l",
     lwd=3,lty=3,
     ylim=c(-5,3),xlab="",ylab="in percent",las=1,
     main="Panel (b) - Consumption growth")
abline(h=0,col="grey",lty=3)
lines(clean.DATA$Date,600*clean.DATA$data.delta.c,
      lwd=2,lty=1,
      col="black")
#lines(macro_data$Date,400*macro_data$data.delta.c,col="dark grey",lwd=2,lty=1)

for(JJJ in 1:nb.parameterizations){
  if(all.loglik[JJJ]<loglik.baseline - logl.Diff.max){
    lines(clean.DATA$Date,600*all.model.delta.c.est[,JJJ],lwd=2,
          col="#44444477",lty=3)
  }else{
    lines(clean.DATA$Date,600*all.model.delta.c.est[,JJJ],lwd=2,
          col="#44444477")
  }
}
lines(clean.DATA$Date,600*delta.c.est.baseline,lwd=3,lty=3)

legend("bottomright", # places a legend at the appropriate place c("Health","Defense"), # puts text in the legend 
       c("Data (bi-monthly)","Baseline model","Alternative models","Alternative models (low log-Lik.)"),
       lty=c(1,3,1,3), # gives the legend appropriate symbols (lines)       
       lwd=c(2,3,2,2), # line width
       col=c("black","black","#44444477","#44444477"), # gives the legend lines the correct color and width
       pt.bg=c(NaN),
       #text.width = 2,
       #cex=1.0,# size of the text
       pch = c(NaN),#symbols,
       pt.cex = c(NaN),
       bg="white",
       seg.len = 3
)

dev.off()




