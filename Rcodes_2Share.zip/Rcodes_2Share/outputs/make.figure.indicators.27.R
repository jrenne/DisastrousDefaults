# =======================================
# DISASTROUS DEFAULTS
# =======================================
# Christian Gouriéroux, Alain Monfort,
# Jean-Paul Renne and Sarah Mouabbi
# Contact: jean-paul.renne@unil.ch
# =======================================
# This version: October 2020
# =======================================
# This script computes the indicators for
#  the 27 models (different calibrations).
# =======================================


print("")
print("")
print("==========================================================")
print(" Producing indicators for 27 models")
print("==========================================================")


# =============================
# Settings:

# First chart: proba of default of X iTraxx constituents:
Maturity.4.indicator.1stChart <- c(2)
nb.def.iTraxx.constitu <- 10

# Second chart: large decreases of consumption
Maturity.4.indicator.2ndChart <- c(1) # in years
vector.of.decrease.in.conso <- c(-.10)
# =============================



nb.default.rate            <- length(vec.of.target.default.rate)
nb.stdv.delta.c            <- length(vec.of.stdv.delta.c.yoy)
nb.gamma                   <- length(vec.of.gamma)
all.parameterizations      <- matrix(NaN,nb.default.rate*nb.stdv.delta.c*nb.gamma,3)
all.parameterizations[,1]  <- vec.of.target.default.rate %x% rep(1,nb.stdv.delta.c)  %x% rep(1,nb.gamma)
all.parameterizations[,2]  <- rep(1,nb.default.rate) %x% vec.of.stdv.delta.c.yoy  %x% rep(1,nb.gamma)
all.parameterizations[,3]  <- rep(1,nb.default.rate) %x% rep(1,nb.stdv.delta.c)  %x% vec.of.gamma

nb.parameterizations <- dim(all.parameterizations)[1]

all.loglik       <- NULL
all.proba        <- NULL

y.iTraxx <- NULL
y.conso  <- NULL


for(JJJ in 1:nb.parameterizations){
  
  print(paste("Model No",toString(JJJ)," (out of ",toString(nb.parameterizations),")",sep=""))
  
  targets$target.default.rate <- all.parameterizations[JJJ,1]
  targets$stdv.delta.c.yoy    <- all.parameterizations[JJJ,2]
  Model$gamma                 <- all.parameterizations[JJJ,3]
  
  FILE <- paste("results/save_DefRate",toString(targets$target.default.rate),
                "_stdvDc",toString(targets$stdv.delta.c.yoy),
                "_gamma",toString(Model$gamma),".Rdat",sep="")
  load(file = FILE)
  
  Filter <- rep(1,length(Filter))
  
  Model.solved <- make.Model(THETA.FULL,
                             THETA.FULL,
                             Model,
                             DATASET,
                             targets,
                             nb.iter = nb.iter)
  
  # Use of Kalman filter to compute condi. proba of no default:
  res.KF <- prepare.state.space(Model.solved,
                                DATASET,
                                indic.smooth = 1)
  
  X.complete <- list(
    F   = cbind(matrix(0,dim(res.KF$r_smooth)[1],J),
                res.KF$r_smooth[,1:2]),
    N   = matrix(0,dim(res.KF$r)[1],J),
    N_1 = matrix(0,dim(res.KF$r)[1],J)
  )

  # Store log-likelihood:
  all.loglik <- c(all.loglik,
                  res.KF$loglik)
  AUX <- function.compute.param.4.stdv.computation(THETA.FULL,
                                                   THETA.FULL,
                                                   Model,
                                                   DATASET,targets,
                                                   nb.iter=nb.iter)
  transf.param <- AUX$vector.of.param
  beta <- transf.param[2]
  all.proba <- c(all.proba,
                 prod(exp(-beta*res.KF$r[,2])))
  
  
  # Kill prices of risk (work under the physical dynamics):
  Model.aux <- Model.solved
  Model.aux$Delta <- NULL
  Model.aux$Eta <- NULL
  
  # A - Defaults of iTraxx constituents
  
  H <- matrix(DATASET$q*Maturity.4.indicator.1stChart,ncol=1)
  v <- c(1,0,0)
  a    <- list(A = matrix(0,n.F,1),
               B = matrix(0,J,1),
               C = matrix(0,J,1),
               D = matrix(0,1,1))
  b    <- list(A = matrix(0,n.F,1),
               B = matrix(v,ncol=1),
               C = matrix(0,J,1),
               D = matrix(0,1,1))
  
  Y <- g(Model.aux,a,b,nb.def.iTraxx.constitu,
         H,X.complete,min.log.v=-10,max.v=500,step=.001)
  
  y.iTraxx <- cbind(y.iTraxx,1-Y)
  
  
  # B - Large decreases in consumption
  
  H <- matrix(DATASET$q*Maturity.4.indicator.2ndChart,ncol=1)
  a    <- list(A = matrix(0,n.F,1),
               B = matrix(0,J,1),
               C = matrix(0,J,1),
               D = matrix(0,1,1))
  b    <- list(A = matrix(Model.solved$Mu.c$A,n.F,1),
               B = matrix(Model.solved$Mu.c$B,ncol=1),
               C = matrix(Model.solved$Mu.c$C,J,1),
               D = matrix(0,1,1))
  
  y <- vector.of.decrease.in.conso - DATASET$q * Maturity.4.indicator.2ndChart * Model.solved$Mu.c$D
  YY <- g(Model.aux,a,b,y,H,X.complete,
          min.log.v=-10,max.v=10000,step=.001,indic_cumul = 1)
  
  y.conso <- cbind(y.conso,YY)
  
}

proba.threshold <- .01
indic.2.remove <- which(all.proba<proba.threshold)

y.lim.iTraxx <- c(0,100*1.2*max(y.iTraxx))
y.lim.conso  <- c(0,100*1.2*max(y.conso))



# ================================
# Prepare pdf figure
# ================================

FILE = paste("/figures/Figure_indicator_27.pdf",sep="")
pdf(file=paste(getwd(),FILE,sep=""),pointsize=7,width=6, height=6)

par(mfrow=c(2,1),plt=c(.1,.95,.1,.85))

# -----------------------------------------------
# Panel A - Proba of default of serval iTraxx constitutents

plot(clean.DATA$Date,100*(y.iTraxx[,1]),type="l",lwd=2,col="white",
     xlab="",ylab="in percent",
     las=1,ylim=y.lim.iTraxx,
     main=paste("Probability of at least ",toString(nb.def.iTraxx.constitu)," iTraxx constituents defaulting before 24 months",
                sep=""))
for(i in 1:nb.parameterizations){
  lines(clean.DATA$Date,100*y.iTraxx[,i],col="#44444444",lwd=2)
        #lty = ifelse(i %in% indic.2.remove,2,1))
}
lines(clean.DATA$Date,100*y.iTraxx[,round(nb.parameterizations/2)],
      lwd=4,col="black",lty=3)

abline(h=0,col="grey")


# -----------------------------------------------
# Panel B - Consumption falls

plot(clean.DATA$Date,100*y.conso[,1],type="l",lwd=2,
     xlab="",ylab="in percent",las=1,ylim=y.lim.conso,col="white",
     main="Probability of consumption dropping by more than 10% (horizon = 12 months)")
for(i in 1:nb.parameterizations){
  lines(clean.DATA$Date,100*y.conso[,i],col="#44444444",lwd=2)
        #lty = ifelse(i %in% indic.2.remove,2,1))
}
lines(clean.DATA$Date,100*y.conso[,round(nb.parameterizations/2)],
      lwd=4,col="black",lty=3)

abline(h=0,col="grey")


dev.off()




