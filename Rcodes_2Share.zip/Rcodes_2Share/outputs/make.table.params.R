# =======================================
# DISASTROUS DEFAULTS
# =======================================
# Christian Gouriéroux, Alain Monfort,
# Jean-Paul Renne and Sarah Mouabbi
# Contact: jean-paul.renne@unil.ch
# =======================================
# This version: October 2020
# =======================================
# This script prepares the table showing parameter estimates
# =======================================


print("")
print("")
print("==========================================================")
print(" Producing table with baseline model parameterization")
print("==========================================================")


# Load baseline results:
load(results.estim.KF)

Filter <- rep(1,length(THETA.FULL))
Filter[param.2.exclude.from.optim]  <- 0
theta <- THETA.FULL[Filter==1]

AUXX <- function.compute.param.4.stdv.computation(theta,
                                                 THETA.FULL,
                                                 Model,
                                                 DATASET,targets,
                                                 nb.iter=nb.iter)
transf.param <- AUXX$vector.of.param
eps <- rep(0.00001,length(THETA.FULL))
grad.matrix <- grad.function.compute.param.4.stdv.computation(theta,
                                                              THETA.FULL,
                                                              Model,eps,
                                                              DATASET,targets,
                                                              nb.iter=nb.iter)
grad.matrix <- grad.matrix[,detect.has.impact]

mat.cov.matrix.of.transf.param <- grad.matrix %*% Mat.var.cov.reduced %*% t(grad.matrix)
stdv.of.transf.param <- sqrt(diag(mat.cov.matrix.of.transf.param))

cbind(AUXX$latex.names.of.param,
      round(transf.param,6),
      round(stdv.of.transf.param,6),
      round(transf.param/stdv.of.transf.param,6))


latex.table <- NULL

this.line <- NULL

first.line <- "\\multicolumn{2}{c}{Panel (a) -- Calibrated parameters}&&\\multicolumn{2}{c}{Panel (b) -- Estimated parameters}\\\\"
first.line <- "&\\multicolumn{2}{c}{Essai}&&\\multicolumn{2}{c}{Essai}\\\\"
first.line <- NULL

latex.table <- rbind(first.line,
                     #"\\hline",
                     paste("$\\gamma$&&$",round.fixed.length(Model.solved$gamma,0),
                           "$&&$c_{j}\\quad j \\in \\{1,2\\}$&&$",round.fixed.length(transf.param[1],2),
                           "$&[",round.fixed.length(stdv.of.transf.param[1],2),"]\\\\",sep=""),
                     paste("$\\delta$&&$",round.fixed.length(Model.solved$delta,3),
                           "$\\\\",sep=""),
                     paste("EIS&&$",toString(1),
                           "$&&$\\beta_{j}\\quad j \\in \\{1,2\\}$&$(\\times 10^2)$&$",round.fixed.length(10^2*transf.param[2],2),
                           "$&[",round.fixed.length(10^2*stdv.of.transf.param[2],2),"]\\\\",sep=""),
                     paste("&&$",
                           "$\\\\",sep=""),
                     paste("&&$",
                           "$&&$\\mu_w$&$(\\times 10^{-2})$&$",round.fixed.length(.01*transf.param[3],2),
                           "$&[",round.fixed.length(.01*stdv.of.transf.param[3],2),"]\\\\",sep=""),
                     paste("$\\mathbb{E}(\\Delta c_t)$&$(\\times 6)$&$",round.fixed.length(10^2*targets$mu.c.annual,2),"\\%",
                           "$&&$\\xi_w$&$(\\times 10^{2})$&$",round.fixed.length(100*transf.param[4],2),
                           "$&[",round.fixed.length(100*stdv.of.transf.param[4],2),"]\\\\",sep=""),
                     paste("$s.d.(\\Delta c_t+\\dots+\\Delta c_{t-5})$&&$",round.fixed.length(round(10^2*targets$stdv.delta.c.yoy),2),"\\%",
                           "$\\\\",sep=""),
                     paste("&&&&$\\mu_x$&$(\\times 10^2)$&$",round.fixed.length(100*transf.param[5],2),
                           "$&[",round.fixed.length(100*stdv.of.transf.param[5],2),"]\\\\",sep=""),
                     paste("$\\mathbb{E}(g_{d,t})$&$(\\times 6)$&$",round.fixed.length(10^2*targets$mu.c.annual,2),"\\%",
                           "$&&$\\mu_y$&$(\\times 10^2)$&$",round.fixed.length(100*transf.param[6],2),
                           "$&[",round.fixed.length(100*stdv.of.transf.param[6],2),"]\\\\",sep=""),
                     paste("\\\\"),
                     paste("&&$",
                           "$&&$\\rho_x$&&$",round.fixed.length(transf.param[7],3),
                           "$&[",round.fixed.length(stdv.of.transf.param[7],2),"]\\\\",sep=""),
                     paste("&&$",
                           "$&&$\\rho_y$&&$",round.fixed.length(transf.param[8],3),
                           "$&[",round.fixed.length(stdv.of.transf.param[8],2),"]\\\\",sep=""),
                     #                     paste("\\\\"),
                     #                      paste("&&&&$\\chi$&&$",round.fixed.length(Model.solved$Mu.d$A[1]/Model.solved$Mu.c$A[1],2),
                     #                            "$\\\\",sep=""),
                     paste("\\\\",sep=""),
                     # paste("&&&&$\\mu_{c,x} $&$(\\times 10^4)$&$",round.fixed.length(10^4*transf.param[9],2),
                     #       "$&[",round.fixed.length(10^4*stdv.of.transf.param[9],2),"]\\\\",sep=""),
                     paste("&&&&$\\mu_{c,y} $&$(\\times 10^4)$&$",round.fixed.length(10^4*transf.param[10],2),
                           "$&[",round.fixed.length(10^4*stdv.of.transf.param[10],2),"]\\\\",sep=""),
                     paste("&&&&$\\mu_{c,w} $&$(\\times 10^4)$&$",round.fixed.length(10^4*transf.param[11],2),
                           "$&[",round.fixed.length(10^4*stdv.of.transf.param[11],2),"]\\\\",sep=""),
                     paste("&&$",
                           "$&&$\\sigma_{c} $&$(\\times 10^2)$&$",round.fixed.length(10^2*transf.param[16],2),
                           "$&[",round.fixed.length(10^2*stdv.of.transf.param[16],2),"]\\\\",sep=""),
                     paste("\\\\",sep=""),
                     # paste("&&&&$\\mu_{d,x} $&$(\\times 10^4)$&$",round.fixed.length(10^4*transf.param[12],2),
                     #       "$&[",round.fixed.length(10^4*stdv.of.transf.param[12],2),"]\\\\",sep=""),
                     paste("&&&&$\\mu_{d,y} $&$(\\times 10^4)$&$",round.fixed.length(10^4*transf.param[13],2),
                           "$&[",round.fixed.length(10^4*stdv.of.transf.param[13],2),"]\\\\",sep=""),
                     paste("&&$",
                           "$&&$\\mu_{d,w} $&$(\\times 10^4)$&$",round.fixed.length(10^4*transf.param[14],2),
                           "$&[",round.fixed.length(10^4*stdv.of.transf.param[14],2),"]\\\\",sep=""),
                     paste("\\\\"),
                     "\\hline")


latex.file <- paste("tables/table_params.txt",sep="")
write(latex.table, file = latex.file)




