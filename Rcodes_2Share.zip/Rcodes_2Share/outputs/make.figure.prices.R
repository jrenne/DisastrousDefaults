# =======================================
# DISASTROUS DEFAULTS
# =======================================
# Christian Gouriéroux, Alain Monfort,
# Jean-Paul Renne and Sarah Mouabbi
# Contact: jean-paul.renne@unil.ch
# =======================================
# This version: October 2020
# =======================================
# This script produces figures illustrating the fit of the model.
# iTraxx main indices, iTraxx tranches, equity options.
# =======================================


print("")
print("")
print("==========================================================")
print(" Producing figures with prices")
print("==========================================================")


# Load baseline results:
load(results.estim.KF)
Filter <- rep(1,length(THETA.FULL))
theta <- THETA.FULL[Filter==1]
Model.solved <- make.Model(theta,
                           THETA.FULL,
                           Model,
                           DATASET,
                           targets,
                           nb.iter = nb.iter)

res.KF <- prepare.state.space(Model.solved,
                              DATASET,
                              indic.smooth = 1)
print(paste("Log-likelihood: ",res.KF$loglik,sep=""))# 4235.077 in last version
X.complete <- list(
  F   = cbind(matrix(0,dim(res.KF$r_smooth)[1],J),res.KF$r_smooth[,1:2]),
  N   = matrix(0,dim(res.KF$r_smooth)[1],J),
  N_1 = matrix(0,dim(res.KF$r_smooth)[1],J)
)
res <- compute.prices.for.given.X(Model.solved,
                                  X.complete,v,
                                  DATASET)





# =====================================
# 1. iTraxx main indices:
# =====================================

FILE = paste("/figures/Figure_fit_itraxx",suffix,".pdf",sep="")
pdf(file=paste(getwd(),FILE,sep=""),pointsize=7,width=6, height=3)

par(mfrow=c(1,1),plt=c(.1,.95,.1,.95))

v <- c(1,rep(0,J-1)) # consider only first type of entities (systemic ones)
all.modeled.itraxx <- compute.model.implied.itraxx(X.complete,v,
                                                   Model.solved,DATASET)

plot(clean.DATA$Date,10000*DATASET$ITRAXX.main[,1],type="l",las=1,xlab="",ylab="in basis points",
     ylim=c(0,10000*max(all.modeled.itraxx)),col=rgb(0,0,0))
points(clean.DATA$Date,10000*all.modeled.itraxx[,1],col=rgb(0,0,0),pch=1)
lines(clean.DATA$Date,10000*DATASET$ITRAXX.main[,4],type="l",col=rgb(0.75,0.75,0.75))
points(clean.DATA$Date,10000*all.modeled.itraxx[,4],col=rgb(0.75,0.75,0.75),pch=4)
lines(clean.DATA$Date,10000*DATASET$ITRAXX.main[,2],col=rgb(0.25,0.25,0.25))
points(clean.DATA$Date,10000*all.modeled.itraxx[,2],col=rgb(0.25,0.25,0.25),pch=2)
lines(clean.DATA$Date,10000*DATASET$ITRAXX.main[,3],type="l",col=rgb(0.5,0.5,0.5))
points(clean.DATA$Date,10000*all.modeled.itraxx[,3],col=rgb(0.5,0.5,0.5),pch=3)

names.itraxx <- NULL
for(i in 1:length(DATASET$H.in.years.4.itraxx.indices)){
  names.itraxx <- c(names.itraxx,
                    paste(toString(DATASET$H.in.years.4.itraxx.indices[i])," years",sep=""))
}

legend("topright", # places a legend at the appropriate place c("Health","Defense"), # puts text in the legend 
       names.itraxx,
       lty=c(1,1,1,1,NaN,1), # gives the legend appropriate symbols (lines)       
       lwd=c(1), # line width
       col=c(rgb(0,0,0),rgb(0.25,0.25,0.25),rgb(0.5,0.5,0.5),rgb(0.75,0.75,0.75)), # gives the legend lines the correct color and width
       pt.bg=c(1),
       #text.width = 2,
       #cex=1.0,# size of the text
       pch = c(1,2,3,4),#symbols,
       pt.cex = c(1),
       bg="white",
       seg.len = 4
)

dev.off()


FILE = paste("/figures/Figure_fit_itraxx2",suffix,".pdf",sep="")
pdf(file=paste(getwd(),FILE,sep=""),pointsize=7,width=5, height=5)

par(mfrow=c(2,2),plt=c(.1,.95,.1,.8))

v <- c(1,rep(0,J-1)) # consider only first type of entities (systemic ones)
all.modeled.itraxx <- compute.model.implied.itraxx(X.complete,v,
                                                   Model.solved,DATASET)

Model.P <- Model.solved
Model.P$Delta <- NULL
all.modeled.itraxx.P <- compute.model.implied.itraxx(X.complete,v,
                                                     Model.P,DATASET)

for(i in 1:4){
  plot(clean.DATA$Date,10000*all.modeled.itraxx[,i],
       type="l",las=1,xlab="",ylab="in basis points",col="dark grey",lwd=2,
       main=paste("Maturity: ",toString(DATASET$H.in.years.4.itraxx.indices[i])," years",sep=""),
       ylim=c(0,12000*max(DATASET$ITRAXX.main[,i],all.modeled.itraxx[,i])))
  points(clean.DATA$Date,10000*DATASET$ITRAXX.main[,i],col="black",pch=19)
  
  lines(clean.DATA$Date,10000*all.modeled.itraxx.P[,i],col="black",lwd=1,lty=2)# Data

  legend("topright", # places a legend at the appropriate place c("Health","Defense"), # puts text in the legend 
         c("Data","Model","Model (under P)"),
         lty=c(NaN,1,2), # gives the legend appropriate symbols (lines)       
         lwd=c(2), # line width
         col=c("black","dark grey","black"), # gives the legend lines the correct color and width
         pt.bg=c(1),
         #text.width = 2,
         #cex=1.0,# size of the text
         pch = c(19,NaN,NaN),#symbols,
         pt.cex = c(1),
         bg="white",
         seg.len = 3)
}

dev.off()






# =====================================
# 2. Main iTraxx + risk premia
# =====================================


maturities.for.RP.chart <- c(5,10)


FILE = paste("/figures/Figure_RP",suffix,".pdf",sep="")
pdf(file=paste(getwd(),FILE,sep=""),pointsize=7,width=7, height=5)

par(mfrow=c(1,length(maturities.for.RP.chart)),plt=c(.15,.95,.1,.85))

DATASET.aux <- DATASET
DATASET.aux$H.in.years.4.itraxx.indices <- maturities.for.RP.chart

for(j in 1:length(maturities.for.RP.chart)){
  
  for(i in 1:2){
    if(i==1){
      v <- c(1,rep(0,J-1)) # consider only first type of entities (systemic ones)
      all.modeled.itraxx.Q <- compute.model.implied.itraxx(X.complete,v,
                                                           Model.solved,DATASET.aux)
      Model.P <- Model.solved
      Model.P$Delta <- NULL
      all.modeled.itraxx.P <- compute.model.implied.itraxx(X.complete,v,
                                                           Model.P,DATASET.aux)
    }else{
      Model.aux <- Model.solved
      
      # Define the exposure of third-type entities:
      
      Model.aux$c.matrix[1:(J-1),J] <- .5 * Model.aux$c.matrix[1:(J-1),1]
      Model.aux$beta.matrix[n.F,J] <- moments$unc.mean[n.F+1] * (1 - sum(Model.aux$c.matrix[1:(J-1),J]))

      Model.aux.save <- Model.aux
      
      v <- c(rep(0,J-1),1) # non-systemic entity
      all.modeled.itraxx.Q <- compute.model.implied.itraxx(X.complete,v,
                                                           Model.aux,DATASET.aux)
      Model.P.aux <- Model.aux
      Model.P.aux$Delta <- NULL
      all.modeled.itraxx.P <- compute.model.implied.itraxx(X.complete,v,
                                                           Model.P.aux,DATASET.aux)
    }
    
    if(i==1){
      plot(clean.DATA$Date,10000*all.modeled.itraxx.Q[,j],type="l",las=1,xlab="",ylab="in basis points",
           ylim=c(0,13000*max(all.modeled.itraxx.Q[,j])),col="black",lwd=2,
           main=paste("Maturity: ",toString(maturities.for.RP.chart[j])," years",sep=""))
      lines(clean.DATA$Date,10000*all.modeled.itraxx.P[,j],lwd=2,col="dark grey")
    }else{
      points(clean.DATA$Date,10000*all.modeled.itraxx.Q[,j],pch=2,lwd=1,col="black")
      points(clean.DATA$Date,10000*all.modeled.itraxx.P[,j],pch=2,lwd=1,col="dark grey")
    }
  }
  legend("topright", # places a legend at the appropriate place c("Health","Defense"), # puts text in the legend 
         c("Systemic entity (under Q)","Systemic entity (under P)",
           "Non-systemic (segment-3) entity (under Q)","Non-systemic (segment-3) entity (under P)"),
         lty=c(1,1,NaN,NaN), # gives the legend appropriate symbols (lines)       
         lwd=c(2,2,1,1), # line width
         col=c("black","dark grey"), # gives the legend lines the correct color and width
         pt.bg=c(1),
         #text.width = 2,
         #cex=1.0,# size of the text
         pch = c(NaN,NaN,2,2),#symbols,
         #pt.cex = c(1),
         bg="white",
         seg.len = 4
  )
}
dev.off()






# =====================================
# 3. Equity options
# =====================================


Model.P <- Model.solved
Model.P$Delta <- NULL

K.over.P <- rep(1-DATASET$decrease.in.percent.4.stock.options/100,dim(res.KF$r_smooth)[1])

option.prices.P <- Equity.option.pricing(Model.P,
                                         DATASET$H.in.years.4.stock.options,
                                         X.complete,
                                         v,K.over.P,
                                         min.log.v=-10,max.v=10000,step=.01)
all.model.implied.vol.P <- NULL
count <- 0
for(h in DATASET$H.in.years.4.stock.options){
  count <- count + 1
  all.model.implied.vol.P <- cbind(all.model.implied.vol.P,
                                   compute.implied.vol(
                                     relative.prices=option.prices.P$Put[,count],
                                     K.over.S=K.over.P,
                                     maturities.in.years=h,
                                     riskfree.rates=0,
                                     nb.iterations=10))
}

print("===================================")
print("Prepare stock option figure")

FILE = paste("/figures/Figure_fit_stockoptions",suffix,".pdf",sep="")
pdf(file=paste(getwd(),FILE,sep=""),pointsize=7,width=6, height=4)

par(mfrow=c(1,length(DATASET$H.in.years.4.stock.options)),plt=c(.1,.9,.1,.85))


count <- 0

for(h in DATASET$H.in.years.4.stock.options){
  count <- count + 1
  
  plot(clean.DATA$Date,100*res$all.model.implied.vol[,count],type="l",
       ylim=c(10,65),
       col="dark grey",
       lwd=2,
       xlab="",ylab="",las=1,
       main=paste("Maturity: ",toString(12*h)," months",sep="")
  )# Model
  lines(clean.DATA$Date,100*DATASET$IV[,count],col="black",lwd=3,lty=3)# Data
  lines(clean.DATA$Date,100*all.model.implied.vol.P[,count],col="black",lwd=1,lty=2)# Data
  
  legend("topright", # places a legend at the appropriate place c("Health","Defense"), # puts text in the legend 
         c("Data","Model","Model (under P)"),
         lty=c(3,1,2), # gives the legend appropriate symbols (lines)       
         lwd=c(3,2,1), # line width
         col=c("black","dark grey","black"), # gives the legend lines the correct color and width
         pt.bg=c(NaN),
         #text.width = 2,
         #cex=1.0,# size of the text
         pch = c(NaN),#symbols,
         pt.cex = c(NaN),
         bg="white",
         seg.len = 3
  )
  
}

dev.off()

print("Stock option figure done")
print("===================================")








# =====================================
# 4. Itraxx Tranche prices
# =====================================



print("===================================")
print("Computing tranche prices")

U <- NaN

res.tranche.pricing <- Tranche.pricing(Model.solved,
                                       max.H=max(DATASET$H.in.years.4.tranches),
                                       X.complete,v,
                                       DATASET$vec.a.b.4.tranches,
                                       U=NaN,
                                       du=0.0001,
                                       min.log.v=-8,
                                       max.v=10000,
                                       step=.01)

Model.P <- Model.solved
Model.P$Delta <- NULL

res.tranche.pricing.P <- Tranche.pricing(Model.P,max.H=max(DATASET$H.in.years.4.tranches),
                                         X.complete,v,
                                         DATASET$vec.a.b.4.tranches,
                                         U=NaN,
                                         du=0.0001,
                                         min.log.v=-8,
                                         max.v=10000,
                                         step=.01)

print("End of computation")
print("===================================")
print("Prepare tranche figures")


for(matur.in.year in DATASET$H.in.years.4.tranches){
  
  nb.tranche <- 1
  
  eval(parse(text = gsub(" ","",paste("observations <- clean.DATA$Tranche_",names.tranches.2[nb.tranche],"_",
                                      toString(matur.in.year),"YR", sep=""))))
  
  FILE = paste("/figures/Figure_fit_tranche_",toString(matur.in.year),"years",suffix,".pdf",sep="")
  pdf(file=paste(getwd(),FILE,sep=""),pointsize=7,width=5, height=6)
  
  par(mfrow=c(3,2),plt=c(.1,.9,.1,.85))
  
  plot(clean.DATA$Date,10000*res.tranche.pricing$S.a.b[,matur.in.year*DATASET$q,1],type="l",
       ylim=c(0,max(12000*res.tranche.pricing$S.a.b[,matur.in.year*DATASET$q,1])),col="dark grey",lwd=2,
       xlab="",ylab="",las=1,
       main=paste("Tranche: ",toString(0),"%-",toString(100*DATASET$vec.a.b.4.tranches[1]),"%",sep=""))
  lines(clean.DATA$Date,10000*res.tranche.pricing.P$S.a.b[,matur.in.year*DATASET$q,1],col="dark grey",lwd=2,lty=2)
  
  
  points(clean.DATA$Date,observations,pch=19,col="black")
  
  for(nb.tranche in 2:length(DATASET$vec.a.b.4.tranches)){
    eval(parse(text = gsub(" ","",paste("observations <- clean.DATA$Tranche_",names.tranches.2[nb.tranche],"_",
                                        toString(matur.in.year),"YR", sep=""))))
    
    #lines(dates,10000*res.tranche.pricing$S.a.b[,matur.in.year*DATASET$q,nb.tranche],col=nb.tranche)
    plot(clean.DATA$Date,10000*res.tranche.pricing$S.a.b[,matur.in.year*DATASET$q,nb.tranche],type="l",
         ylim=c(0,max(12000*res.tranche.pricing$S.a.b[,matur.in.year*DATASET$q,nb.tranche])),
         col="dark grey",lwd=2,xlab="",ylab="",las=1,
         main=paste("Tranche: ",toString(100*DATASET$vec.a.b.4.tranches[nb.tranche-1]),"%-",toString(100*DATASET$vec.a.b.4.tranches[nb.tranche]),"%",sep=""))
    
    lines(clean.DATA$Date,10000*res.tranche.pricing.P$S.a.b[,matur.in.year*DATASET$q,nb.tranche],col="dark grey",lwd=2,lty=2)
    
    points(clean.DATA$Date,observations,pch=19,col="black")
  }
  
  dev.off()
  
}




# =====================================
# 4.bis Itraxx Tranche prices
# =====================================

FILE = paste("/figures/Figure_fit_tranche",suffix,".pdf",sep="")
pdf(file=paste(getwd(),FILE,sep=""),pointsize=7,width=10, height=6)

par(mfrow=c(3,5),plt=c(.15,.95,.1,.85))

for(matur.in.year in DATASET$H.in.years.4.tranches){
  
  nb.tranche <- 1
  
  eval(parse(text = gsub(" ","",paste("observations <- clean.DATA$Tranche_",names.tranches.2[nb.tranche],"_",
                                      toString(matur.in.year),"YR", sep=""))))
  
  
  plot(clean.DATA$Date,10000*res.tranche.pricing$S.a.b[,matur.in.year*DATASET$q,1],type="l",
       ylim=c(0,max(12000*res.tranche.pricing$S.a.b[,matur.in.year*DATASET$q,1])),col="dark grey",lwd=2,
       xlab="",ylab="",las=1,
       main=paste("Maturity: ",toString(matur.in.year),"yrs / Tranche: ",toString(0),"%-",toString(100*DATASET$vec.a.b.4.tranches[1]),"%",sep=""))
  lines(clean.DATA$Date,10000*res.tranche.pricing.P$S.a.b[,matur.in.year*DATASET$q,nb.tranche],col="black",lwd=1,lty=2)
  
  points(clean.DATA$Date,observations,pch=19,col="black")
  
  for(nb.tranche in 2:length(DATASET$vec.a.b.4.tranches)){
    eval(parse(text = gsub(" ","",paste("observations <- clean.DATA$Tranche_",names.tranches.2[nb.tranche],"_",
                                        toString(matur.in.year),"YR", sep=""))))
    
    #lines(dates,10000*res.tranche.pricing$S.a.b[,matur.in.year*DATASET$q,nb.tranche],col=nb.tranche)
    plot(clean.DATA$Date,10000*res.tranche.pricing$S.a.b[,matur.in.year*DATASET$q,nb.tranche],type="l",
         ylim=c(0,max(12000*res.tranche.pricing$S.a.b[,matur.in.year*DATASET$q,nb.tranche])),
         col="dark grey",lwd=2,xlab="",ylab="",las=1,
         main=paste("Maturity: ",toString(matur.in.year),"yrs / Tranche: ",toString(100*DATASET$vec.a.b.4.tranches[nb.tranche-1]),"%-",toString(100*DATASET$vec.a.b.4.tranches[nb.tranche]),"%",sep=""))
    
    lines(clean.DATA$Date,10000*res.tranche.pricing.P$S.a.b[,matur.in.year*DATASET$q,nb.tranche],col="black",lwd=1,lty=2)
    
    points(clean.DATA$Date,observations,pch=19,col="black")
  }
  
}

dev.off()



print("Tranche figures done")
print("===================================")




