# =======================================
# DISASTROUS DEFAULTS
# =======================================
# Christian Gouriéroux, Alain Monfort,
# Jean-Paul Renne and Sarah Mouabbi
# Contact: jean-paul.renne@unil.ch
# =======================================
# This version: October 2020
# =======================================
# This script produces the contourplot
# illustrating the size of credit risk premiums
# depending on the type of exposure.
# =======================================


print("")
print("")
print("==========================================================")
print(" Producing contourplot (Q/P ratios)")
print("==========================================================")



require(grDevices) # for colours


# Load baseline results:
load(results.estim.KF)
Filter <- rep(1,length(THETA.FULL))
Filter[param.2.exclude.from.optim]  <- 0
theta <- THETA.FULL[Filter==1]
# Solve model:
Model.solved <- make.Model(theta,
                           THETA.FULL,
                           Model,
                           DATASET,
                           targets,
                           nb.iter)
# Use Kalman smoother:
res.KF <- prepare.state.space(Model.solved,
                              DATASET,
                              indic.smooth = 1)
print(res.KF$loglik)



# Step 1: prepare matrix of CDS prices
vec.exposure.F2 <- exp(seq(log(.001),log(.2),by=.2))
vec.exposure.syst <- exp(seq(log(.001),log(2),by=.2))

all.prices    <- matrix(NaN,length(vec.exposure.F2),length(vec.exposure.syst))
all.prices.P  <- matrix(NaN,length(vec.exposure.F2),length(vec.exposure.syst))
all.def.rates <- matrix(NaN,length(vec.exposure.F2),length(vec.exposure.syst))

maturities.for.contour.chart <- 10 # in years

Model.aux <- Model.solved
Model.aux.P <- Model.solved
Model.aux.P$Delta <- NULL

v <- c(rep(0,J-1),1) # non-systemic entity

moments <- compute.moments(Model.solved)
X.mean <- list(
  F = matrix(moments$unc.mean[1:n.F],nrow=1),
  N = matrix(moments$unc.mean[(n.F+1):(n.F+J)],nrow=1),
  N_1 = matrix(0,1,J)
)

for(i in 1:length(vec.exposure.F2)){
  print(paste(toString(i)," / ",toString(length(vec.exposure.F2)),sep=""))
  for(j in 1:length(vec.exposure.syst)){
    
    Model.aux$beta.matrix[n.F,J] <- vec.exposure.F2[i]
    Model.aux$c.matrix[1:(J-1),J] <- vec.exposure.syst[j]
    
    Model.aux.P$beta.matrix[n.F,J] <- vec.exposure.F2[i]
    Model.aux.P$c.matrix[1:(J-1),J] <- vec.exposure.syst[j]
    
    DATASET.aux <- DATASET
    DATASET.aux$H.in.years.4.itraxx.indices <- maturities.for.contour.chart
    all.modeled.itraxx.Q <- compute.model.implied.itraxx(X.mean,v,
                                                         Model.aux,DATASET.aux)
    all.modeled.itraxx.P <- compute.model.implied.itraxx(X.mean,v,
                                                         Model.aux.P,DATASET.aux)
    
    moments <- compute.moments(Model.aux)
    cum.delta.N <- 0
    x <- c(moments$unc.mean[1:n.F],
           moments$unc.mean[(n.F+1):(n.F+J)])
    for(ii in 1:DATASET$q*horiz.default.rate){
      x <- moments$MU + moments$PHI %*% x
      cum.delta.N <- cum.delta.N + x[n.F+J]
    }

    all.def.rates[i,j] <- cum.delta.N/DATASET$I.iTraxx

    all.prices[i,j] <- 10000*all.modeled.itraxx.Q
    all.prices.P[i,j] <- 10000*all.modeled.itraxx.P
  }
}

all.ratios <- all.prices/all.prices.P



FILE = "/figures/Figure_contour.pdf"
pdf(file=paste(getwd(),FILE,sep=""),pointsize=5,width=4, height=2.5)

par(plt=c(.13,.95,.15,.95))
par(mfrow = c(1, 1))
contour(vec.exposure.F2,vec.exposure.syst,all.ratios,
        vfont = c("sans serif", "bold"),
        xlab=expression(paste("Exposure to ",y[t]," (i.e. ",beta[j],")",sep="")),
        ylab=expression(paste("Exposure to systemic defaults (i.e. ",c[j],")",sep="")),
        lwd=1,col="black",
        labcex=1)
par(new=TRUE)
contour(vec.exposure.F2,vec.exposure.syst,100*all.def.rates,
        vfont = c("sans serif", "bold"),cex=2,
        xaxt="n",yaxt="n",lty=2,lwd=1,col="dark grey",
        labcex=1)
legend("topright", 
       c("Q/P Ratio","One-year proba. of default"),
       lty=c(1,2), # gives the legend appropriate symbols (lines)       
       lwd=c(1), # line width
       col=c("black","dark grey"), # gives the legend lines the correct color and width
       bg="white",
       seg.len = 3
)

points(Model.solved$beta.matrix[n.F,1],Model.solved$c.matrix[1,1],pch=2,cex=1.7,lwd=2)
Model.aux <- Model.solved
Model.aux$c.matrix[1:(J-1),J] <- .5 * Model.aux$c.matrix[1:(J-1),1]
Model.aux$beta.matrix[n.F,J] <- moments$unc.mean[n.F+1] * (1 - sum(Model.aux$c.matrix[1:(J-1),J]))
points(Model.aux$beta.matrix[n.F,J],Model.aux$c.matrix[1,J],pch=0,cex=1.7,lwd=2)

dev.off()

