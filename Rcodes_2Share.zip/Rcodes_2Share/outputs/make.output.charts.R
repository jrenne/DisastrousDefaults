


Filter <- rep(1,length(THETA.FULL))
THETA.KF <- THETA.FULL

# ============================
# Main ITRAXX:


#H.in.years.4.stock.options <- matrix(c(.5,1),ncol=1)

# ============================
# ITRAXX tranches:

# tranche that will be considered:
#vec.a.b <- c(.03,.06,.09,.12,.22,1)

vec.a.b <- c(.03,.06,.09,.12,.22,1)
names.tranches <- c("0-3","3-6","6-9","9-12","12-22","22-100")
names.tranches.2 <- c("0.3","3.6","6.9","9.12","12.22","22.100")

vec.a.b <- c(.03,.06,.09,.12,.22)
names.tranches <- c("0-3","3-6","6-9","9-12","12-22")
names.tranches.2 <- c("0.3","3.6","6.9","9.12","12.22")

# For data extraction:
time.window <- 1.0 # in years



print("===================================")
print("Running Kalman Filter")

Model.solved <- make.Model(THETA.KF,
                           THETA.FULL,
                           Model,
                           DATASET,
                           targets,
                           nb.iter)


# ===== for counterfactual analyses: =====

# No contagion (but still same average PDef):
THETA.KF.no.contagion <- THETA.KF
THETA.KF.no.contagion[2] <- -10
Model.solved.no.contagion <- make.Model(THETA.KF.no.contagion,
                                        THETA.KF.no.contagion,
                                        Model,
                                        DATASET,
                                        targets,
                                        nb.iter)


moments <- compute.moments(Model.solved.no.contagion)
V <- moments$unc.var
PHI <- moments$PHI
Var.X.q <- DATASET$q * V
for(j in 1:(DATASET$q-1)){
  Var.X.q <- Var.X.q + 2 * (DATASET$q-j) * (PHI%^%j %*% V + V %*% t(PHI%^%j))
}
var.delta.c.one.year <-
  t(Model.solved$Mu.c$A) %*% Var.X.q[1:n.F,1:n.F] %*% Model.solved$Mu.c$A + DATASET$q * Model.solved$sigma.c^2
targets.saved <- targets
targets$stdv.delta.c.yoy <- sqrt(var.delta.c.one.year)
Model.solved.no.contagion <- make.Model(THETA.KF.no.contagion,
                                        THETA.KF.no.contagion,
                                        Model,
                                        DATASET,
                                        targets,
                                        nb.iter)
# Reload saved targets (before change):
targets <- targets.saved

Model.solved.no.macro.effect <- Model.solved
Model.solved.no.macro.effect$Mu.c$A[1:2] <- 0
moments <- compute.moments(Model.solved.no.macro.effect)
V <- moments$unc.var
PHI <- moments$PHI
Var.X.q <- DATASET$q * V
for(j in 1:(DATASET$q-1)){
  Var.X.q <- Var.X.q + 2 * (DATASET$q-j) * (PHI%^%j %*% V + V %*% t(PHI%^%j))
}
var.delta.c.one.year <-
  t(Model.solved.no.macro.effect$Mu.c$A) %*% Var.X.q[1:n.F,1:n.F] %*%
  Model.solved.no.macro.effect$Mu.c$A + DATASET$q * Model.solved$sigma.c^2
targets.saved <- targets
targets$stdv.delta.c.yoy <- sqrt(var.delta.c.one.year)
THETA.KF.no.macro.effect <- THETA.KF
THETA.KF.no.macro.effect[4] <- -20
Model.solved.no.macro.effect <- make.Model(THETA.KF.no.macro.effect,
                                           THETA.KF.no.macro.effect,
                                           Model,
                                           DATASET,
                                           targets,
                                           nb.iter)
# Reload saved targets (before change):
targets <- targets.saved
# ========================================






