# =======================================
# DISASTROUS DEFAULTS
# =======================================
# Christian Gouriéroux, Alain Monfort,
# Jean-Paul Renne and Sarah Mouabbi
# Contact: jean-paul.renne@unil.ch
# =======================================
# This version: October 2020
# =======================================
# This script prepares an Rdat file,
# namely "results/Saved_AlternativeSolvedModels/save_EstimatedAlternativeModels.Rdat",
# that contains the parameterizations of the CALIBRATED
# alternative models (w/o contagion and macro-effects).
# These models are named I, II, III and IV in the paper.
# In these models, contagion and/or macro-effects are simply switched off,
# with no re-estimation of the model.
# =======================================



# ======================================================
# Load baseline model.
load(results.estim.KF)
param.4.grid <- .3
Filter    <- rep(1,length(THETA.FULL))
Model.solved <- make.Model(THETA.FULL,
                           THETA.FULL,
                           Model,
                           DATASET,
                           targets,
                           nb.iter = nb.iter)
res.KF <- prepare.state.space(Model.solved,
                              DATASET,indic.smooth = 1)
print(paste("Log-likelihood: ",res.KF$loglik,sep=""))
X.complete <- list(
  F   = cbind(matrix(0,dim(res.KF$r)[1],J),res.KF$r_smooth[,1:2]),
  N   = matrix(0,dim(res.KF$r)[1],J),
  N_1 = matrix(0,dim(res.KF$r)[1],J)
)
PD.baseline <- compute.proba.NB.def(Model.solved,
                                    res.KF)


# ======================================================
# Load model no contag.

Model.solved.no.contagion <- Model.solved
Model.solved.no.contagion$c.matrix[,] <- 0
moments <- compute.moments(Model.solved.no.contagion)
V <- moments$unc.var
PHI <- moments$PHI
Var.X.q <- DATASET$q * V
for(j in 1:(DATASET$q-1)){
  Var.X.q <- Var.X.q + 2 * (DATASET$q-j) * (PHI%^%j %*% V + V %*% t(PHI%^%j))
}
var.delta.c.one.year <-
  t(Model.solved.no.contagion$Mu.c$A) %*% Var.X.q[1:n.F,1:n.F] %*% Model.solved.no.contagion$Mu.c$A +
  DATASET$q * Model.solved.no.contagion$sigma.c^2
targets.saved <- targets
targets$stdv.delta.c.yoy <- sqrt(var.delta.c.one.year)
THETA.KF.no.contagion <- THETA.FULL
THETA.KF.no.contagion[2] <- -10 # kill contagion
Model.solved.no.contagion <- make.Model(THETA.KF.no.contagion,
                                        THETA.KF.no.contagion,
                                        Model,
                                        DATASET,
                                        targets,
                                        nb.iter)
# Reload saved targets (before change):
targets <- targets.saved

X.complete.no.contagion <- X.complete

PD.no.contagion <- compute.proba.NB.def(Model.solved.no.contagion,
                                        res.KF)




# ======================================================
# Load model no macro effects.

Model.solved.no.macro.effect <- Model.solved
moments <- compute.moments(Model.solved.no.macro.effect)
V <- moments$unc.var
PHI <- moments$PHI
Var.X.q <- DATASET$q * V
for(j in 1:(DATASET$q-1)){
  Var.X.q <- Var.X.q + 2 * (DATASET$q-j) * (PHI%^%j %*% V + V %*% t(PHI%^%j))
}
Model.solved.no.macro.effect$Mu.c$A[1:2] <- 0 # kill macro effects
var.delta.c.one.year <-
  t(Model.solved.no.macro.effect$Mu.c$A) %*% Var.X.q[1:n.F,1:n.F] %*%
  Model.solved.no.macro.effect$Mu.c$A + DATASET$q * Model.solved.no.macro.effect$sigma.c^2
targets.saved <- targets
targets$stdv.delta.c.yoy <- sqrt(var.delta.c.one.year)
THETA.KF.no.macro.effect <- THETA.FULL
THETA.KF.no.macro.effect[4] <- -30 # kill macro effect
Model.solved.no.macro.effect <- make.Model(THETA.KF.no.macro.effect,
                                           THETA.KF.no.macro.effect,
                                           Model,
                                           DATASET,
                                           targets,
                                           nb.iter)
# Reload saved targets (before change):
targets <- targets.saved

X.complete.no.macro.effect <- X.complete

PD.no.macro.effect <- compute.proba.NB.def(Model.solved.no.macro.effect,
                                           res.KF)



# ======================================================
# Load model no macro effects, no contagion.

Model.solved.no.contagion.no.macro.effect <- Model.solved
Model.solved.no.contagion.no.macro.effect$Mu.c$A[1:2] <- 0 # kill macro effects
Model.solved.no.contagion.no.macro.effect$c.matrix[,] <- 0 # kill contagion
moments <- compute.moments(Model.solved.no.contagion.no.macro.effect)
V <- moments$unc.var
PHI <- moments$PHI
Var.X.q <- DATASET$q * V
for(j in 1:(DATASET$q-1)){
  Var.X.q <- Var.X.q + 2 * (DATASET$q-j) * (PHI%^%j %*% V + V %*% t(PHI%^%j))
}
var.delta.c.one.year <-
  t(Model.solved.no.contagion.no.macro.effect$Mu.c$A) %*% Var.X.q[1:n.F,1:n.F] %*% Model.solved.no.contagion.no.macro.effect$Mu.c$A +
  DATASET$q * Model.solved.no.contagion.no.macro.effect$sigma.c^2
targets.saved <- targets
targets$stdv.delta.c.yoy <- sqrt(var.delta.c.one.year)
THETA.KF.no.contagion.no.macro.effect <- THETA.FULL
THETA.KF.no.contagion.no.macro.effect[2] <- -10 # kill contagion
THETA.KF.no.contagion.no.macro.effect[4] <- -30 # kill macro effects
Model.solved.no.contagion.no.macro.effect <- make.Model(THETA.KF.no.contagion.no.macro.effect,
                                                        THETA.KF.no.contagion.no.macro.effect,
                                                        Model,
                                                        DATASET,
                                                        targets,
                                                        nb.iter)
# Reload saved targets (before change):
targets <- targets.saved

X.complete.no.contagion.no.macro.effect <- X.complete

PD.no.contagion.no.macro.effect <- compute.proba.NB.def(Model.solved.no.contagion.no.macro.effect,
                                                        res.KF)

# Save models:
save(Model.solved,
     Model.solved.no.contagion,
     Model.solved.no.macro.effect,
     Model.solved.no.contagion.no.macro.effect,
     X.complete,
     X.complete.no.contagion,
     X.complete.no.macro.effect,
     X.complete.no.contagion.no.macro.effect,
     file="results/Saved_AlternativeSolvedModels/save_ModifiedAlternativeModels.Rdat")





