# =======================================
# DISASTROUS DEFAULTS
# =======================================
# Christian Gouriéroux, Alain Monfort,
# Jean-Paul Renne and Sarah Mouabbi
# Contact: jean-paul.renne@unil.ch
# =======================================
# This version: October 2020
# =======================================
# Impulse Response Functions obtained for models
# obtained when switching channels off (contagion, macro effects).
# Panel A uses the baseline model, modified by
#     switching off some channels.
# Panel B uses the models re-estimated after having
#     switched off channels.
# Note: This script makes use of models saved in 
#    results/Saved_AlternativeSolvedModels/save_EstimatedAlternativeModels.Rdat
#          and
#    results/Saved_AlternativeSolvedModels/save_ModifiedAlternativeModels.Rdat
# =======================================


# Length of shock, in years:
Horiz <- 3

shock <- c(rep(0,n.F),c(1,rep(0,J-1)))
nb.sim <- DATASET$q * Horiz


FILE = paste("/figures/Figure_IRFs_OnOff_channels.pdf",sep="")
pdf(file=paste(getwd(),FILE,sep=""),pointsize=10,width=8, height=9)

par(mfrow=c(2,1))
par(plt=c(.1,.9,.1,.86))
plot.new()
title("Panel A - Baseline model (switching off contagion and/or macroeconomic effects)")
plot.new()
title("Panel B - Re-estimated models (where contagion and/or macroeconomic effects are not allowed)")


par(mfrow=c(2,3),plt=c(.1,.9,.15,.8))

count.panel <- 0

for(Type.of.modif in c("Estimated","Modified")){
  
  count.panel <- count.panel + 1
  
  # Load different models
  FILE <- paste(file="results/Saved_AlternativeSolvedModels/save_",
                Type.of.modif,
                "AlternativeModels.Rdat",sep="")
  load(file=FILE)
  
  # Baseline model:
  IRFs.baseline <- make.IRFs(Model.solved,nb.sim,shock)
  all.res               <- IRFs.baseline$all.res
  impact.on.ns          <- cumsum(all.res[n.F+1,]+all.res[n.F+2,])
  impact.on.Delta.c     <- IRFs.baseline$impact.on.cumsum.Delta.c
  impact.on.var.Delta.c <- IRFs.baseline$impact.on.stdv.var.Delta.c
  impact.on.g.d         <- IRFs.baseline$impact.on.g.d
  impact.on.stock.index <- IRFs.baseline$impact.on.stock.index
  impact.on.var.r_s     <- IRFs.baseline$impact.on.stdv.var.r_s
  
  # With no contagion:
  IRFs.no.contagion <- make.IRFs(Model.solved.no.contagion,
                                 nb.sim,shock)
  all.res.no.contagion               <- IRFs.no.contagion$all.res
  impact.on.ns.no.contagion          <- cumsum(all.res.no.contagion[n.F+1,]+
                                                 all.res.no.contagion[n.F+2,])
  impact.on.Delta.c.no.contagion     <- IRFs.no.contagion$impact.on.cumsum.Delta.c
  impact.on.var.Delta.c.no.contagion <- IRFs.no.contagion$impact.on.stdv.var.Delta.c
  impact.on.g.d.no.contagion         <- IRFs.no.contagion$impact.on.g.d
  impact.on.stock.index.no.contagion <- IRFs.no.contagion$impact.on.stock.index
  impact.on.var.r_s.no.contagion     <- IRFs.no.contagion$impact.on.stdv.var.r_s
  
  # With no macro effect:
  IRFs.no.macro.effect <- make.IRFs(Model.solved.no.macro.effect,
                                    nb.sim,shock)
  all.res.no.macro.effect               <- IRFs.no.macro.effect$all.res
  impact.on.ns.no.macro.effect          <- cumsum(all.res.no.macro.effect[n.F+1,]+
                                                    all.res.no.macro.effect[n.F+2,])
  impact.on.Delta.c.no.macro.effect     <- IRFs.no.macro.effect$impact.on.cumsum.Delta.c
  impact.on.var.Delta.c.no.macro.effect <- IRFs.no.macro.effect$impact.on.stdv.var.Delta.c
  impact.on.g.d.no.macro.effect         <- IRFs.no.macro.effect$impact.on.g.d
  impact.on.stock.index.no.macro.effect <- IRFs.no.macro.effect$impact.on.stock.index
  impact.on.var.r_s.no.macro.effect     <- IRFs.no.macro.effect$impact.on.stdv.var.r_s
  
  # With no contagion and no macro effect:
  IRFs.no.contagion.no.macro.effect <- make.IRFs(Model.solved.no.contagion.no.macro.effect,
                                                 nb.sim,shock)
  all.resno.contagion.no.macro.effect               <- IRFs.no.contagion.no.macro.effect$all.res
  impact.on.ns.no.contagion.no.macro.effect          <- cumsum(all.resno.contagion.no.macro.effect[n.F+1,]+
                                                                 all.resno.contagion.no.macro.effect[n.F+2,])
  impact.on.Delta.c.no.contagion.no.macro.effect     <- IRFs.no.contagion.no.macro.effect$impact.on.cumsum.Delta.c
  impact.on.var.Delta.c.no.contagion.no.macro.effect <- IRFs.no.contagion.no.macro.effect$impact.on.stdv.var.Delta.c
  impact.on.g.d.no.contagion.no.macro.effect         <- IRFs.no.contagion.no.macro.effect$impact.on.g.d
  impact.on.stock.index.no.contagion.no.macro.effect <- IRFs.no.contagion.no.macro.effect$impact.on.stock.index
  impact.on.var.r_s.no.contagion.no.macro.effect     <- IRFs.no.contagion.no.macro.effect$impact.on.stdv.var.r_s
  
  
  
  # First plot: Effect on n_s:
  
  par(mfg=c(count.panel,1))
  plot((0:nb.sim)/DATASET$q,impact.on.ns,
       xlab="Time after shock (h, in years)",ylab="",las=1,
       ylim=c(0,1.4*max(impact.on.ns,
                        impact.on.ns.no.contagion,
                        impact.on.ns.no.macro.effect,
                        impact.on.ns.no.contagion.no.macro.effect)),
       #type="b",
       lwd=1,pch=1,cex=1.5,
       main=expression(paste("Number of systemic defaults",sep="")))
  points((0:nb.sim)/DATASET$q,impact.on.ns.no.contagion,
         lwd=1,pch=3,cex=1.5,col="black")
  points((0:nb.sim)/DATASET$q,impact.on.ns.no.macro.effect,
         lwd=1,pch=4,cex=1.5,col="black")
  points((0:nb.sim)/DATASET$q,impact.on.ns.no.contagion.no.macro.effect,
         lwd=1,pch=5,cex=1.5,col="black")

  legend("topleft", # places a legend at the appropriate place c("Health","Defense"), # puts text in the legend 
         c("Baseline (I)","No contagion (II)",
           "No macro effect (III)","No contagion & no macro effect (IV)"),
         lty=c(NaN), # gives the legend appropriate symbols (lines)       
         lwd=c(1), # line width
         col=c("black","black","black","black"), # gives the legend lines the correct color and width
         #pt.bg=c(NaN),
         #text.width = 2,
         #cex=1.0,# size of the text
         pch = c(1,3,4,5),#symbols,
         pt.cex = c(1.3),
         bg="white",
         seg.len = 2
  )
  
  
  # Second plot: Effect on consumption:
  
  par(mfg=c(count.panel,2))
  plot((0:nb.sim)/DATASET$q,impact.on.Delta.c,
       xlab="Time after shock (h, in years)",ylab="",las=1,
       ylim=c(1.2*min(impact.on.Delta.c,
                  impact.on.Delta.c.no.contagion,
                  impact.on.Delta.c.no.macro.effect,
                  impact.on.Delta.c.no.contagion.no.macro.effect),
              0),
       lwd=1,pch=1,cex=1.5,
       main=expression(paste("Consumption",sep="")))
  points((0:nb.sim)/DATASET$q,impact.on.Delta.c.no.contagion,
         lwd=1,pch=3,cex=1.5,col="black")
  points((0:nb.sim)/DATASET$q,impact.on.Delta.c.no.macro.effect,
         lwd=1,pch=4,cex=1.5,col="black")
  points((0:nb.sim)/DATASET$q,impact.on.Delta.c.no.contagion.no.macro.effect,
         lwd=1,pch=5,cex=1.5,col="black")
  
  
  # Third plot: Effect on stock prices:
  
  par(mfg=c(count.panel,3))
  plot((0:nb.sim)/DATASET$q,impact.on.stock.index,
       xlab="Time after shock (h, in years)",ylab="",las=1,
       ylim=c(1.2*min(impact.on.stock.index,
                  impact.on.stock.index.no.contagion,
                  impact.on.stock.index.no.macro.effect,
                  impact.on.stock.index.no.contagion.no.macro.effect),
              0),
       lwd=1,pch=1,cex=1.5,
       main=expression(paste("Stock prices",sep="")))
  points((0:nb.sim)/DATASET$q,impact.on.stock.index.no.contagion,
         lwd=1,pch=3,cex=1.5,col="black")
  points((0:nb.sim)/DATASET$q,impact.on.stock.index.no.macro.effect,
         lwd=1,pch=4,cex=1.5,col="black")
  points((0:nb.sim)/DATASET$q,impact.on.stock.index.no.contagion.no.macro.effect,
         lwd=1,pch=5,cex=1.5,col="black")
  
  
}

dev.off()
