# =======================================
# DISASTROUS DEFAULTS
# =======================================
# Christian Gouriéroux, Alain Monfort,
# Jean-Paul Renne and Sarah Mouabbi
# Contact: jean-paul.renne@unil.ch
# =======================================
# This version: October 2020
# =======================================
# This script prepares the dataset.
# It loads csv files saved in
# folder "/data/csvfiles/"
# =======================================


par(plt=c(.1,.9,.1,.9))

clean.DATA <- read.csv("data/csvfiles/dates.csv")
clean.DATA$Date <- as.Date(clean.DATA$Date,"%d/%m/%y")



# ================================
# Load ITRAXX data:
# ================================


# ================================
# A. Tranche products

DATA <- read.csv("data/csvfiles/data4R.csv")
DATA$Date <- as.Date(DATA$Date,"%d/%m/%y")

DATA$Ask.corrected <- NaN
DATA$Bid.corrected <- NaN

# Convert all quotes into spreads:
for(i in 1:dim(DATA)[1]){
  
  if(DATA$Indic_pricing[i]==4){
    if(DATA$Tranche[i]=="0-3"){
      DATA$Ask.corrected[i] <- 500 + DATA$Ask[i]*10000/DATA$Maturity_year[i]
      DATA$Bid.corrected[i] <- 500 + DATA$Bid[i]*10000/DATA$Maturity_year[i]
    }else{
      DATA$Ask.corrected[i] <- DATA$Ask[i]
      DATA$Bid.corrected[i] <- DATA$Bid[i]
    }
  }
  
  if(DATA$Indic_pricing[i]==3){
    if((DATA$Tranche[i]=="0-3")|DATA$Tranche[i]=="3-6"|DATA$Tranche[i]=="6-9"){
      DATA$Ask.corrected[i] <- 500 + DATA$Ask[i]*10000/DATA$Maturity_year[i]
      DATA$Bid.corrected[i] <- 500 + DATA$Bid[i]*10000/DATA$Maturity_year[i]
    }else{
      DATA$Ask.corrected[i] <- DATA$Ask[i]
      DATA$Bid.corrected[i] <- DATA$Bid[i]
    }
  }
  
  if(DATA$Indic_pricing[i]==2){
    if(DATA$Tranche[i]=="0-3"){
      DATA$Ask.corrected[i] <- 500 + DATA$Ask[i]*10000/DATA$Maturity_year[i]
      DATA$Bid.corrected[i] <- 500 + DATA$Bid[i]*10000/DATA$Maturity_year[i]
    }else if((DATA$Tranche[i]=="3-6")|(DATA$Tranche[i]=="6-9")){
      DATA$Ask.corrected[i] <- 300 + DATA$Ask[i]/DATA$Maturity_year[i]
      DATA$Bid.corrected[i] <- 300 + DATA$Bid[i]/DATA$Maturity_year[i]
    }else if((DATA$Tranche[i]=="9-12")|(DATA$Tranche[i]=="12-22")){
      DATA$Ask.corrected[i] <- 100 + DATA$Ask[i]/DATA$Maturity_year[i]
      DATA$Bid.corrected[i] <- 100 + DATA$Bid[i]/DATA$Maturity_year[i]
    }else{
      DATA$Ask.corrected[i] <- DATA$Ask[i]
      DATA$Bid.corrected[i] <- DATA$Bid[i]
    }
  }
  
  if(DATA$Indic_pricing[i]==1){
    if((DATA$Tranche[i]=="0-3")|(DATA$Tranche[i]=="3-6")|(DATA$Tranche[i]=="6-9")){
      DATA$Ask.corrected[i] <- 500 + DATA$Ask[i]*10000/DATA$Maturity_year[i]
      DATA$Bid.corrected[i] <- 500 + DATA$Bid[i]*10000/DATA$Maturity_year[i]
    }else if((DATA$Tranche[i]=="9-12")|(DATA$Tranche[i]=="12-22")){
      DATA$Ask.corrected[i] <- 100 + DATA$Ask[i]/DATA$Maturity_year[i]
      DATA$Bid.corrected[i] <- 100 + DATA$Bid[i]/DATA$Maturity_year[i]
    }else{
      DATA$Ask.corrected[i] <- DATA$Ask[i]
      DATA$Bid.corrected[i] <- DATA$Bid[i]
    }
  }
  
  if(DATA$Indic_pricing[i]==0){
    if((DATA$Tranche[i]=="0-3")|(DATA$Tranche[i]=="3-6")){
      DATA$Ask.corrected[i] <- 500 + DATA$Ask[i]*10000/DATA$Maturity_year[i]
      DATA$Bid.corrected[i] <- 500 + DATA$Bid[i]*10000/DATA$Maturity_year[i]
    }else if(DATA$Tranche[i]=="6-9"){
      DATA$Ask.corrected[i] <- 300 + DATA$Ask[i]*10000/DATA$Maturity_year[i]
      DATA$Bid.corrected[i] <- 300 + DATA$Bid[i]*10000/DATA$Maturity_year[i]
    }else if((DATA$Tranche[i]=="9-12")|(DATA$Tranche[i]=="12-22")){
      DATA$Ask.corrected[i] <- 100 + DATA$Ask[i]/DATA$Maturity_year[i]
      DATA$Bid.corrected[i] <- 100 + DATA$Bid[i]/DATA$Maturity_year[i]
    }else{
      DATA$Ask.corrected[i] <- DATA$Ask[i]
      DATA$Bid.corrected[i] <- DATA$Bid[i]
    }
  }
  
  if(DATA$Indic_pricing[i]==-1){
    if((DATA$Tranche[i]=="0-3")|(DATA$Tranche[i]=="3-6")){
      DATA$Ask.corrected[i] <- 500 + DATA$Ask[i]*10000/DATA$Maturity_year[i]
      DATA$Bid.corrected[i] <- 500 + DATA$Bid[i]*10000/DATA$Maturity_year[i]
    }else if(DATA$Tranche[i]=="6-9"){
      DATA$Ask.corrected[i] <- 300 + DATA$Ask[i]*10000/DATA$Maturity_year[i]
      DATA$Bid.corrected[i] <- 300 + DATA$Bid[i]*10000/DATA$Maturity_year[i]
    }else if((DATA$Tranche[i]=="9-12")|(DATA$Tranche[i]=="12-22")|(DATA$Tranche[i]=="22-100")){
      DATA$Ask.corrected[i] <- 100 + DATA$Ask[i]/DATA$Maturity_year[i]
      DATA$Bid.corrected[i] <- 100 + DATA$Bid[i]/DATA$Maturity_year[i]
    }
  }
}

DATA.tranche <- DATA
DATA.tranche$Date <- as.Date(
  paste("15-",
        as.integer(format(DATA.tranche$Date,"%m")),
        "-",
        as.integer(format(DATA.tranche$Date,"%y")),sep=""),
  "%d-%m-%y")


# Create time series of tranche prices.

names.tranches   <- c("0-3","3-6","6-9","9-12","12-22","22-100")
names.tranches.2 <- c("0.3","3.6","6.9","9.12","12.22","22.100")
all.maturities <- c(3,5,7)
time.window <- 1

count <- 0
for(TRANCHE in names.tranches){
  count <- count + 1
  for(matur.in.year in all.maturities){
    series <- rep(NaN,dim(clean.DATA)[1])
    
    DATA.reduced <- subset(DATA.tranche,(Maturity_year>matur.in.year-time.window)&
                             (Maturity_year<matur.in.year+time.window)&(Version=="V1")&(Tranche==TRANCHE))
    
    all.dates <- levels(as.factor(DATA.reduced$Date))
    for(ddates in all.dates){
      indic.date.in.clean.DATA <- which(clean.DATA$Date==ddates)
      DATA.reduced.reduced <- subset(DATA.reduced,Date==ddates)
      if(dim(DATA.reduced.reduced)[1]>1){
        distance.2.maturity <- abs(DATA.reduced.reduced$Maturity_year - matur.in.year)
        indic.closest.2.maturity <- which(distance.2.maturity==min(distance.2.maturity))
        aux <- .5*(DATA.reduced.reduced$Ask.corrected[indic.closest.2.maturity] +
                     DATA.reduced.reduced$Bid.corrected[indic.closest.2.maturity])
        series[indic.date.in.clean.DATA] <- aux[1]
      }else{
        series[indic.date.in.clean.DATA] <- .5*(DATA.reduced.reduced$Ask.corrected +
                                                  DATA.reduced.reduced$Bid.corrected)
      }
    }
    
    eval(parse(text = gsub(" ","",paste("clean.DATA$Tranche_",names.tranches.2[count],"_",
                                        toString(matur.in.year),"YR <- series", sep=""))))
  }
}




# ================================
# B. Main Indices

ITRAXX.main <- read.csv("data/csvfiles/ITRAXX4R.csv")
ITRAXX.main$Date <- as.Date(ITRAXX.main$Date,"%d/%m/%y")

ITRAXX.main$Date <- as.Date(
  paste("15-",
        as.integer(format(ITRAXX.main$Date,"%m")),
        "-",
        as.integer(format(ITRAXX.main$Date,"%y")),sep=""),
  "%d-%m-%y")


plot(ITRAXX.main$Date,ITRAXX.main$ITRAXX3Y,col="black",type="l")
lines(ITRAXX.main$Date,ITRAXX.main$ITRAXX10Y,col="blue")

clean.DATA <- merge(clean.DATA,ITRAXX.main,by="Date")




# ================================
# Euro Stoxx 50 (Source: Datastream)
# ================================

maturity.in.month <- 12
decrease.in.percent <- 20

res.load.stock.options <- load.stock.option.data(maturity.in.month,
                                                 decrease.in.percent)

DATA <- res.load.stock.options$DATA

DATA$Date <- as.Date(
  paste("15-",
        as.integer(format(DATA$Date,"%m")),
        "-",
        as.integer(format(DATA$Date,"%y")),sep=""),
  "%d-%m-%y")

DATA.without.all.options <- data.frame(Date=DATA$Date,EUROSTOXX50=DATA$EUROSTOXX50,
                                       EURIBOR3M=DATA$EURIBOR3M,EURIBOR6M=DATA$EURIBOR6M,
                                       swap1y=DATA$swap1y,swap1y=DATA$swap2y,swap1y=DATA$swap3y,
                                       swap1y=DATA$swap4y,swap1y=DATA$swap5y,swap1y=DATA$swap7y,
                                       swap10y=DATA$swap10y)


vec.decreases.in.percent <- c(30)
vec.h.in.years <- c(.5,1)

for(decrease.in.percent in vec.decreases.in.percent){
  for(h in vec.h.in.years){
    print(paste("Decrease in %: ",toString(decrease.in.percent),", Maturity in mths: ",toString(12*h),sep=""))
    res.load.stock.options <- load.stock.option.data(maturity.in.month=12*h,decrease.in.percent)
    relative.price <- res.load.stock.options$relative.price
    
    # Compute implied vol (data)
    implied.vol <- compute.implied.vol(
      relative.prices=relative.price,
      K.over.S=1-decrease.in.percent/100,
      maturities.in.years=h,
      riskfree.rates=0,
      nb.iterations=10)
    
    eval(parse(text = gsub(" ","",paste("DATA.without.all.options$IV_",toString(decrease.in.percent),"_",
                                        toString(12*h),"mths <- implied.vol", sep=""))))
    
  }
}

clean.DATA <- merge(clean.DATA,DATA.without.all.options,by="Date")








maturity.in.month <- 12
decrease.in.percent <- 20

res.load.stock.options <- load.stock.option.data(maturity.in.month,
                                                 decrease.in.percent)

DATA <- res.load.stock.options$DATA
DATA$Date <- as.Date(
  paste("15-",
        as.integer(format(DATA$Date,"%m")),
        "-",
        as.integer(format(DATA$Date,"%y")),sep=""),
  "%d-%m-%y")


relative.price <- res.load.stock.options$relative.price

par(mfrow=c(2,1))
plot(DATA$Date,relative.price,type="l")
par(new=TRUE)
plot(DATA$Date,DATA$EUROSTOXX50,type="l",col="red",yaxt="n")


plot(ITRAXX.main$Date,ITRAXX.main$ITRAXX5Y,type="l")
lines(DATA$Date,
      mean(ITRAXX.main$ITRAXX5Y,na.rm = TRUE)+
        sd(ITRAXX.main$ITRAXX5Y,na.rm = TRUE)*
        (relative.price-mean(relative.price,na.rm = TRUE))/sd(relative.price,na.rm = TRUE),
      type="l",col="red")




# Make figure illustrating the correlation between 
# out-of-the-money stock options and ITRAXX main indices
FILE = "/figures/Figure_motivation.pdf"
pdf(file=paste(getwd(),FILE,sep=""),pointsize=7,width=6, height=3)  

par(mfrow=c(1,1),plt=c(.1,.9,.1,.95))


first.date <- which(abs(DATA$Date[1]-ITRAXX.main$Date)<2)
last.date <- dim(ITRAXX.main)[1]

plot(ITRAXX.main$Date[first.date:last.date],ITRAXX.main$ITRAXX5Y[first.date:last.date],type="l",
     las=1,xlab="",ylab="ITRAXX 5Y, in bps",lwd=2)

par(new=TRUE)

plot(DATA$Date,100*relative.price,
     type="l",col="dark grey",xlab="",ylab="",
     las=1,xaxt="n",yaxt="n",col.axis="dark grey",lwd=2)
axis(side = 4,
     labels=FALSE, # because we will use mtext to choose the color
     col="dark grey")
mtext("OTM option price, in pp of stock index price", side=4, line=3,col="black")
at = axTicks(2)
mtext(side = 4, text = at, at = at,
      col = "dark grey",
      line = 1,
      las=1 # vertical reading
)



dev.off()





# ================================
# Macro Data
# ================================

macro_data <- read.csv2("data/csvfiles/macro_data.csv")
macro_data$Date <- as.Date(macro_data$Date,"%d.%m.%Y")
macro_data$data.delta.c <- c(NaN,log(macro_data$PCR[2:length(macro_data$PCR)]/
                                       macro_data$PCR[1:(length(macro_data$PCR)-1)]))
plot(macro_data$Date,
     6*macro_data$data.delta.c,type="l")
abline(h=mean(6*macro_data$data.delta.c,na.rm=TRUE))

# Change frequency

spl <- smooth.spline(as.numeric(macro_data$Date),macro_data$PCR,all.knots = TRUE)
PCR.spl <- predict(spl,as.numeric(clean.DATA$Date))$y
plot(macro_data$Date,macro_data$PCR)
lines(clean.DATA$Date,PCR.spl)

clean.DATA$PCR <- PCR.spl
clean.DATA$data.delta.c <- c(NaN,log(clean.DATA$PCR[2:length(clean.DATA$PCR)]/
                                       clean.DATA$PCR[1:(length(clean.DATA$PCR)-1)]))

Dc_KS <- read.csv("data/csvfiles/Dc_KS.csv")
Dc_KS$Date <- as.Date(Dc_KS$Date,"%Y-%m-%d")


fst.date.clean.data <- clean.DATA$Date[1]
clean.DATA <- merge(clean.DATA,Dc_KS,by="Date")
index.fst.date.clean.data <- which(clean.DATA$Date==fst.date.clean.data)
clean.DATA <- clean.DATA[index.fst.date.clean.data:dim(clean.DATA)[1],]

plot(clean.DATA$Date,6*clean.DATA$data.delta.c,type="l",ylim=c(-.03,.04))
lines(Dc_KS$Date,6*Dc_KS$Dc_KS,col="red")

# =============================================
# Keep bi-monthly series based on Chow & Lin (1971):
clean.DATA$data.delta.c <- clean.DATA$Dc_KS
# =============================================






# ===========================================================
# Construct final set of observable data.
# ===========================================================

d.EUROSTOXX <- 100*log(clean.DATA$EUROSTOXX50/c(clean.DATA$EUROSTOXX50[1],clean.DATA$EUROSTOXX50[1:(dim(clean.DATA)[1]-1)]))

DATASET <- list(Date = clean.DATA$Date,
                
                d.EUROSTOXX = d.EUROSTOXX,
                
                ITRAXX.main = cbind(clean.DATA$ITRAXX3Y,clean.DATA$ITRAXX5Y,
                                    clean.DATA$ITRAXX7Y,clean.DATA$ITRAXX10Y)/10000,
                H.in.years.4.itraxx.indices = c(3,5,7,10),
                
                ITRAXX.tranches = cbind(
                  clean.DATA$Tranche_0.3_3YR,clean.DATA$Tranche_0.3_5YR,clean.DATA$Tranche_0.3_7YR,
                  clean.DATA$Tranche_3.6_3YR,clean.DATA$Tranche_3.6_5YR,clean.DATA$Tranche_3.6_7YR,
                  clean.DATA$Tranche_6.9_3YR,clean.DATA$Tranche_6.9_5YR,clean.DATA$Tranche_6.9_7YR,
                  clean.DATA$Tranche_9.12_3YR,clean.DATA$Tranche_9.12_5YR,clean.DATA$Tranche_9.12_7YR,
                  clean.DATA$Tranche_12.22_3YR,clean.DATA$Tranche_12.22_5YR,clean.DATA$Tranche_12.22_7YR
                )/10000,
                H.in.years.4.tranches = c(3,5,7),
                vec.a.b.4.tranches = c(.03,.06,.09,.12,.22),
                
                IV = cbind(clean.DATA$IV_30_6mths,clean.DATA$IV_30_12mths),
                H.in.years.4.stock.options = matrix(c(.5,1),ncol=1),
                decrease.in.percent.4.stock.options = 30,
                
                delta.c = clean.DATA$data.delta.c,
                
                multipl.factors = c(.5,1.5,2),
                # (1) ITRAXX indices, (2) Stock options, (3) Tranches
                
                multipl.factors.delta.c = 1, # multipl factor for standard deviation of consumption growth
                
                vec.stdv = NaN,
                
                observables = NaN,
                
                I.iTraxx = 125,
                
                RR = .4,
                
                q = 6 # number of periods per year
)

DATASET <- make.observables.and.vec.stdv(DATASET)

# Add n_s:
DATASET$observables <- cbind(DATASET$observables,
                             rep(0,dim(DATASET$observables)[1]))
DATASET$vec.stdv <- c(DATASET$vec.stdv,0)

# Add stock returns:
DATASET$observables <- cbind(DATASET$observables,
                             DATASET$d.EUROSTOXX)
DATASET$vec.stdv <- c(DATASET$vec.stdv,sqrt(.1)*sd(DATASET$d.EUROSTOXX))


# Moody's, 
# Annual Default Study: Corporate Default and Recovery Rates, 1920-2016 - Excel data
# Exhibit 32:
# Baa	0.3	0.7	1.3	1.9	2.6	3.2	3.8	4.5	5.1	5.8	6.4	7.1	7.8	8.4	9.0	9.6	10.2	10.7	11.2	11.7
cum.def.rates.BBB <- c(
  0.3,0.7,1.3,1.9,2.6,3.2,3.8,4.5,5.1,5.8,
  6.4,7.1,7.8,8.4,9.0,9.6,10.2,10.7,11.2,11.7
)
# plot(cum.def.rates.BBB)


horiz.default.rate <- 1

targets <- list(
  target.ratio = 3, # First guess of the ratio of Q-to-P spreads (is estimated later on)
  
  target.avg.r = .02,
  target.stdv.r = .01,
  
  maturity.4.level.cds = 3, # expressed in years
  target.level.cds = 0.005,
  
  horiz.default.rate = horiz.default.rate, # in years
  target.default.rate = cum.def.rates.BBB[horiz.default.rate]/100,

  target.avg.slope = .004, # expressed without unit (i.e. .01=1% or 100 bps).
  
  maturity.4.ratio = 10, # in years
  maturities.4.slope = c(3,10), # in years
  
  target.itraxx.short = mean(clean.DATA$ITRAXX3Y)/10000,
  target.itraxx.long = mean(clean.DATA$ITRAXX10Y)/10000,
  
  target.itraxx.short = 40/10000,
  target.itraxx.long = 80/10000,
  
  stdv.delta.c.yoy = .05,
  
  mu.c.annual = 0.015
)

