
# This script constructs a bi-monthly consumption time series.
# Consumption is available at the quarterly freauency.
# In order to get intermediary estimates, we make use of the European Sentiment Index (ESI).

# Load macro (AWM) data:
macro_data <- read.csv2("data/csvfiles/macro_data.csv")
macro_data$Date <- as.Date(macro_data$Date,"%d.%m.%Y")

# Load ESI data:
ESI <- read.csv("data/csvfiles/ESI.csv", dec=",",sep=";", comment.char="#")
ESI$Date <- as.Date(ESI$Date,"%d.%m.%Y")
stdv.ESI <- sd(ESI$EA.ESI,na.rm=TRUE)
# modify dates (15th of each month):
ESI$Date <- as.Date(
  paste("15-",
        as.integer(format(ESI$Date,"%m")),
        "-",
        as.integer(format(ESI$Date,"%Y")),sep=""),
  "%d-%m-%Y")

# Compute quarterly growth rate of consumption:
macro_data$data.delta.c <- c(NaN,log(macro_data$PCR[2:length(macro_data$PCR)]/
                                       macro_data$PCR[1:(length(macro_data$PCR)-1)]))

# Merge ESI and AWM data:
DATA_AUX <- merge(macro_data,ESI,by="Date",all=TRUE)

# Check relationship between consumption growth and ESI:
par(mfrow=c(1,2))
plot(macro_data$Date,6*macro_data$data.delta.c,type="l")
abline(h=mean(6*macro_data$data.delta.c,na.rm=TRUE))
lines(DATA_AUX$Date,(DATA_AUX$EA.ESI-90)/400,col="red")

# Reduce database:
first.date <- as.Date("2000-01-15","%Y-%m-%d")
first.date <- which(DATA_AUX$Date==first.date)
DATA_AUX <- DATA_AUX[first.date:dim(DATA_AUX)[1],]

# State-space model parameterization:
mu <- mean(DATA_AUX$data.delta.c,na.rm=TRUE)
stdv.Dc.q <- sd(macro_data$data.delta.c,na.rm = TRUE)
stdv.Dc.m <- stdv.Dc.q/3
phi.x <- .95
phi.y <- .8

share.Dc.acc4.by.x <- .8
sigma.x <- stdv.Dc.m * sqrt(share.Dc.acc4.by.x*(1 - phi.x^2))
sigma.eps <- stdv.Dc.m * sqrt(1-share.Dc.acc4.by.x)

share.ESI.acc4.by.x <- .8
alpha.0 <- mean(ESI$EA.ESI)
alpha.1 <- sqrt(stdv.ESI^2 * share.ESI.acc4.by.x / (sigma.x^2/(1-phi.x^2)))
sigma.y <- stdv.ESI * sqrt((1 - share.ESI.acc4.by.x)*(1-phi.y^2))


Y_t <- cbind(log(DATA_AUX$PCR),DATA_AUX$EA.ESI)
TTT <- dim(Y_t)[1]
nu_t <- matrix(0,TTT,6)
nu_t[,1] <- mu
H <- matrix(0,6,6)
H[1,5] <- phi.x
H[2,1] <- 1
H[3,2] <- 1
H[4,3] <- 1
H[4,4] <- 1
H[5,5] <- phi.x
H[6,6] <- phi.y
N <- matrix(0,6,3)
N[1,1] <- sigma.eps
N[1,2] <- sigma.x
N[5,2] <- sigma.x
N[6,3] <- sigma.y

mu_t <- matrix(0,TTT,2)
mu_t[,1] <- log(3)
mu_t[,2] <- alpha.0

G <- matrix(0,2,6)
G[1,1] <- 1/3
G[1,2] <- 2/3
G[1,3] <- 3/3
G[1,4] <- 1
G[2,5] <- alpha.1
G[2,6] <- 1

M <- rep(.0001,2)

Sigma_0 <- .0001 * diag(6)
gamma.0.x <- sigma.x^2/(1-phi.x^2)
gamma.1.x <- phi.x * sigma.x^2/(1-phi.x^2)
gamma.2.x <- phi.x^2 * sigma.x^2/(1-phi.x^2)
Sigma_0[1:3,1:3] <- diag(rep(gamma.0.x+sigma.eps^2,3))
Sigma_0[2,1] <- gamma.1.x
Sigma_0[1,2] <- gamma.1.x
Sigma_0[3,2] <- gamma.1.x
Sigma_0[2,3] <- gamma.1.x
Sigma_0[3,1] <- gamma.2.x
Sigma_0[1,3] <- gamma.2.x
Sigma_0[5,5] <- gamma.0.x
Sigma_0[5,1] <- gamma.0.x
Sigma_0[1,5] <- gamma.0.x
Sigma_0[5,2] <- gamma.1.x
Sigma_0[2,5] <- gamma.1.x
Sigma_0[5,3] <- gamma.2.x
Sigma_0[3,5] <- gamma.2.x
Sigma_0[6,6] <- sigma.y^2/(1-phi.y^2)

rho_0 <- rep(0,6)
if(!is.na(Y_t[1,1])){
  rho_0[4] <- log(exp(Y_t[1,1])/3)
}else if(!is.na(Y_t[2,1])){
  rho_0[4] <- log(exp(Y_t[2,1])/3)
}else{
  rho_0[4] <- log(exp(Y_t[3,1])/3)
}

Rfunction <- function(M,rho,aux){
  # compute covariance matrix of measurement errors
  # indices.of.addit.var indicate to which basic measurement eq. relate the addiitonal ones.
  R <- diag(M^2)
  return(R)
}
Qfunction <- function(N,rho,aux){  # ask if we remove aux
  Q <- N %*% t(N)
  return(Q)
}

# Run Kalman filter and smoother:
res.KF <- Kalman_filter(Y_t,nu_t,H,N,mu_t,G,M,Sigma_0,rho_0)
res.KS <- Kalman_smoother(Y_t,nu_t,H,N,mu_t,G,M,Sigma_0,rho_0)

par(mfrow=c(1,2))
for(i in 1:dim(Y_t)[2]){
  plot(Y_t[,i])
  lines(res.KF$fitted.obs[,i],col="red")
}

# Get latent factors:
X <- res.KS$r_smooth

# Check relationship between ESI and x:
plot(Y_t[,2],type="l")
lines(alpha.0+alpha.1*X[,5],col="red")

# construct monthly consumption series:
Cm <- exp(X[,4]+(X[,1]+X[,2]+X[,3]))
plot(Cm,type="l")

# construct 2-month MA consumption series:
Cm_MA2 <- c(NaN,Cm[2:TTT]+Cm[1:(TTT-1)])

# construct 3-month MA consumption series:
Cm_MA3 <- c(NaN,NaN,Cm[3:TTT]+Cm[2:(TTT-1)]+Cm[1:(TTT-2)])

DATA_AUX$Cm     <- Cm
DATA_AUX$Cm_MA2 <- Cm_MA2
DATA_AUX$Cm_MA3 <- Cm_MA3

# Check that Cm_MA3 # PCR
plot(DATA_AUX$PCR)
lines(DATA_AUX$Cm_MA3,col="red")


# Previous approach: cubic spline
DATA_AUX2 <- read.csv("data/csvfiles/dates.csv")
DATA_AUX2$Date <- as.Date(DATA_AUX2$Date,"%d/%m/%y")
spl <- smooth.spline(as.numeric(macro_data$Date),macro_data$PCR,all.knots = TRUE)
PCR.spl <- predict(spl,as.numeric(DATA_AUX2$Date))$y
DATA_AUX2$PCR <- PCR.spl
DATA_AUX2$Dc.spline <- c(NaN,log(DATA_AUX2$PCR[2:length(DATA_AUX2$PCR)]/
                                   DATA_AUX2$PCR[1:(length(DATA_AUX2$PCR)-1)]))

# DATA_tempo is essentially aimed at comparing spline and Kalman approches:
DATA_tempo <- merge(DATA_AUX2,DATA_AUX,by="Date")

DATA_tempo$Dc_KS <- c(NaN,log(DATA_tempo$Cm_MA2[2:length(DATA_tempo$Cm_MA2)]/
                                DATA_tempo$Cm_MA2[1:(length(DATA_tempo$Cm_MA2)-1)]))

plot(DATA_AUX2$Date,6*DATA_AUX2$Dc.spline,type="l",ylim=c(-.05,.05))
lines(macro_data$Date,4*macro_data$data.delta.c,col="red")
lines(DATA_tempo$Date,6*DATA_tempo$Dc_KS,col="blue")

# Prepare dataframe to be saved:
DATA.CONSO <- data.frame(Date = DATA_tempo$Date,
                         Dc_KS = DATA_tempo$Dc_KS)

if(indic.save.bimonthlyconso==1){
  write.csv(DATA.CONSO,file="data/csvfiles/Dc_KS.csv")
}


# Prepare charts for paper:

FILE = paste("/figures/Figure_ConstructBiMonthlyConso.pdf",sep="")
pdf(file=paste(getwd(),FILE,sep=""),pointsize=10,width=10, height=5)

start.date <- 40
end.date <- length(macro_data$data.delta.c)

par(mfrow=c(1,2))

par(plt=c(.15,.85,.1,.9))

plot(macro_data$Date[start.date:end.date],
     400*macro_data$data.delta.c[start.date:end.date],type="l",
     xlab="",ylab="Annualized consumption growth (in percent)",
     main=expression(paste("Panel A. ESI (red line) vs ",Delta,c[t]," (black line)",sep="")))
abline(h=0,col="grey",lty=3)
par(new=TRUE)
lines(DATA_AUX$Date,(DATA_AUX$EA.ESI-90)/8,col="red",lwd=2)
aux <- seq(50,150,by=25)
aux.str <- NULL
for(i in 1:length(aux)){
  aux.str <- cbind(aux.str,toString(aux[i]))
}
mtext("European Sentiment Index", side=4, line=3,col = "red")
axis(side=4, at=(aux-90)/8, labels=aux.str,col="red",
     col.ticks = "red",
     col.axis = "red",
     las=1)

par(plt=c(.2,.9,.1,.9))

plot(DATA_AUX2$Date,6*DATA_AUX2$Dc.spline,type="l",ylim=c(-.05,.05),
     col="white",
     main = expression(paste("Panel B. Quaterly (black line) vs bimonthly (grey line)",Delta,c[t],sep="")),
     lty=3,
     xlab="",ylab="Annualized consumption growth (in percent)")
abline(h=0,col="grey",lty=3)
lines(macro_data$Date,4*macro_data$data.delta.c,
      col="black")
lines(DATA_tempo$Date,6*DATA_tempo$Dc_KS,col="dark grey",lwd=2)


dev.off()





