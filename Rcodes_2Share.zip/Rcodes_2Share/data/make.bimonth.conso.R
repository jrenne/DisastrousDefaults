# =======================================
# DISASTROUS DEFAULTS
# =======================================
# Christian Gouriéroux, Alain Monfort,
# Jean-Paul Renne and Sarah Mouabbi
# =======================================
# This version: April 2020
# =======================================
# This script allows to produce a bi-monlthy
# (6 periods per year) time series of consumption.
# =======================================

# Clear environment and console
rm(list = ls(all = TRUE)) # clear environment 
cat("\014") # clear console

# =======================================
indic.save.bimonthlyconso <- 0 # set to 1 to save results
# =======================================



path <- '~/Dropbox/ITRAXX/Rcodes/'
setwd(path)

# Load Kalman filter and smoother:
source("procedures/proc_kalman.R")


source("data/auxiliary.make.conso.R")


