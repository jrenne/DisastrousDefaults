# =======================================
# DISASTROUS DEFAULTS
# =======================================
# Christian Gouriéroux, Alain Monfort,
# Jean-Paul Renne and Sarah Mouabbi
# Contact: jean-paul.renne@unil.ch
# =======================================
# This version: October 2020
# =======================================
# This script launches the estimation of 
# the model parameters, by maximizing the 
# log-likelihood obtained via Kalman filtering techniques.
# =======================================

print("")
print("")
print("==========================================================")
print(" Estimation of model parameterization by MLE")
print("==========================================================")


Filter <- rep(1,11)
theta.ini <- THETA.FULL[Filter==1]
Model.solved <- make.Model(theta.ini,
                           THETA.FULL,
                           Model,
                           DATASET,targets,
                           nb.iter)

# Check initial conditions:
res.KF <- prepare.state.space(Model.solved,
                              DATASET)
#print(res.KF$loglik)

if(res.KF$loglik < -1e+10){# Initial values are not satisfying.
  # Use fit-all parameters:
  THETA.FULL <- c(-2,-2,-2,-5,4,-15,.5,3,2,0,-6)
  Filter <- rep(1,11)
  theta.ini <- THETA.FULL[Filter==1]
}

# Check loglik function (Note: nb.iter can slightly affect the log-lik):
current.best <- loglik.KF(theta.ini,
                          THETA.FULL,
                          Model,
                          DATASET,targets,
                          nb.iter = nb.iter)
print(paste("Initial value of the log-Lik. function: ",toString(round(current.best,4)),sep=""))


if(nb.iter.KF>0){
  for(i in 1:nb.iter.KF){
    
    Filter <- rep(1,11)
    MAXIT.NlMd <- 500
    MAXIT.nlminb <- 3
    source("estimation/run.EKF.estim.R")
    
    Filter <- rep(0,11)
    Filter[c(1,2,3,4,5,11)] <- 1
    MAXIT.NlMd <- 200
    source("estimation/run.EKF.estim.R")
    
    Filter <- rep(0,11)
    Filter[c(6,7,8,9,10)] <- 1
    MAXIT.NlMd <- 200
    source("estimation/run.EKF.estim.R")
    
    parameters.2.consider <- 1:11
    if(indic.contagion==0){
      parameters.2.consider <- parameters.2.consider[-2] # remove 2
    }else if(indic.macro.effect==0){
      parameters.2.consider <- parameters.2.consider[-11] # remove 11
    }
    for(j in parameters.2.consider){
      Filter <- rep(0,11)
      Filter[j] <- 1
      MAXIT.NlMd <- 30
      MAXIT.nlminb <- 3
      source("estimation/run.EKF.estim.R")
    }
  }
}

save(THETA.FULL,
     targets,
     Model,
     DATASET,
     nb.iter,
     file = "results/save_tempo_KF.Rdat")

File = "results/save_DefRate0.003_stdvDc0.03_gamma5.Rdat"
File = "results/save_KF_noContag.Rdat"
File = "results/save_KF_noMacroEffect.Rdat"
File = "results/save_KF_noContag_noMacroEffect.Rdat"
#save(THETA.FULL,DATASET,targets,Model,nb.iter,param.2.exclude.from.optim,file = File)


