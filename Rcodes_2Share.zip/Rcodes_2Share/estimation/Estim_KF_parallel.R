
# ===========================================================
# Estimation of the model
# by means of Kalman filtering techniques
# ===========================================================
# Parallel estimations: different values of
#          targets$target.default.rate and targets$stdv.delta.c.yoy
# ===========================================================

# To be set to 1 if remove the baseline case from the estimation:
indic.remove.central.line <- 0

if(indic.test.parallel==1){
  nb.iter.KF            <- 1  # number of iterations in the estimation loop
  iteration.mult.factor <- 0 # determines the maximal number of iterations in numerical optimizations
  MAXIT.nlminb          <- 0  # number of nlminb iterations
}else{
  nb.iter.KF            <- 4  # number of iterations in the estimation loop
  iteration.mult.factor <- 50 # determines the maximal number of iterations in numerical optimizations
  MAXIT.nlminb          <- 3  # number of nlminb iterations
}


# # # Test ==========================================
# vec.of.target.default.rate <- c(.003)
# vec.of.stdv.delta.c.yoy    <- c(.02,.03,.05)
# vec.of.gamma               <- c(7)
# nb.iter.KF            <- 1  # number of iterations in the estimation loop
# iteration.mult.factor <- 10 # determines the maximal number of iterations in numerical optimizations
# MAXIT.nlminb          <- 2  # number of nlminb iterations
# # # Test ==========================================


nb.default.rate            <- length(vec.of.target.default.rate)
nb.stdv.delta.c            <- length(vec.of.stdv.delta.c.yoy)
nb.gamma                   <- length(vec.of.gamma)

all.parameterizations      <- matrix(NaN,nb.default.rate*nb.stdv.delta.c*nb.gamma,3)
all.parameterizations[,1]  <-  vec.of.target.default.rate %x% rep(1,nb.stdv.delta.c)  %x% rep(1,nb.gamma)
all.parameterizations[,2]  <- rep(1,nb.default.rate) %x% vec.of.stdv.delta.c.yoy  %x% rep(1,nb.gamma)
all.parameterizations[,3]  <- rep(1,nb.default.rate) %x% rep(1,nb.stdv.delta.c)  %x% vec.of.gamma

if(indic.remove.central.line==1){# remove baseline case:
  all.parameterizations <- all.parameterizations[-(.5*(nb.default.rate*nb.stdv.delta.c*nb.gamma)+.5),]
}

nb.parameterizations <- dim(all.parameterizations)[1]

cl <- makeCluster(number.of.cores)
registerDoParallel(cl)

save.image("estimation/tempo/toto.Rdata")
clusterEvalQ(cl,load("estimation/tempo/toto.Rdata"))

clusterEvalQ(cl,library(optimx))
clusterEvalQ(cl,library(MASS))
clusterEvalQ(cl,library(expm))
clusterEvalQ(cl,library(mFilter))
clusterEvalQ(cl,library(stringr))
clusterEvalQ(cl,library(doParallel))


AUX <- foreach(JJJ=1:nb.parameterizations,.combine=rbind) %dopar% {
  
  # Modify parameterization:
  targets$target.default.rate <- all.parameterizations[JJJ,1]
  targets$stdv.delta.c.yoy    <- all.parameterizations[JJJ,2]
  Model$gamma                 <- all.parameterizations[JJJ,3]
  
  FILE <- paste("results/save_DefRate",toString(targets$target.default.rate),
                "_stdvDc",toString(targets$stdv.delta.c.yoy),
                "_gamma",toString(Model$gamma),".Rdat",sep="")
  
  File.exists <- file.exists(FILE)

  if(File.exists){
    load(file = FILE)
    par(plt=c(.1,.9,.1,.9))
  }else{
    load(file = results.estim.KF)
    par(plt=c(.1,.9,.1,.9))
  }
  
  # Modify parameterization:
  targets$target.default.rate <- all.parameterizations[JJJ,1]
  targets$stdv.delta.c.yoy    <- all.parameterizations[JJJ,2]
  Model$gamma                 <- all.parameterizations[JJJ,3]
  
  Filter <- rep(1,11)
  theta.ini <- THETA.FULL[Filter==1]
  
  current.best <- loglik.KF(theta.ini,
                            THETA.FULL,
                            Model,
                            DATASET,targets,
                            nb.iter = nb.iter)
  
  # Check if better than ad-hoc parameterization:
  THETA.FULL.simple <- c(-2,-2,-2,-5,4,-15,.5,3,2,0,-6)
  Filter <- rep(1,11)
  theta.ini <- THETA.FULL.simple[Filter==1]
  current.best.check <- loglik.KF(theta.ini,
                                  THETA.FULL,
                                  Model,
                                  DATASET,targets,
                                  nb.iter = nb.iter)
  
  if(current.best.check<current.best){
    THETA.FULL <- THETA.FULL.simple
  }
  
  for(i in 1:nb.iter.KF){
    
    Filter <- rep(1,11)

    MAXIT.NlMd <- sum(Filter) * iteration.mult.factor
    source("estimation/run.EKF.estim.R", local = TRUE)
    
    Filter <- rep(0,11)
    Filter[c(7,8,9,11)] <- 1
    MAXIT.NlMd <- sum(Filter) * iteration.mult.factor
    source("estimation/run.EKF.estim.R", local = TRUE)
    
    Filter <- rep(0,11)
    Filter[c(1,2,3,5)] <- 1
    MAXIT.NlMd <- sum(Filter) * iteration.mult.factor
    source("estimation/run.EKF.estim.R", local = TRUE)
    
    for(j in c(1:3,5,7,8,9,11)){
      Filter <- rep(0,11)
      Filter[j] <- 1
      MAXIT.NlMd <- sum(Filter) * iteration.mult.factor
      source("estimation/run.EKF.estim.R", local = TRUE)
    }
    
    if(indic.test.parallel==0){
      save(THETA.FULL,DATASET,targets,Model,nb.iter,
           file = paste("results/save_tempo_DefRate",toString(targets$target.default.rate),
                        "_stdvDc",toString(targets$stdv.delta.c.yoy),
                        "_gamma",toString(Model$gamma),
                        ".Rdat",sep=""))
    }
    
  }
  
  if(indic.test.parallel==0){
    FILE <- paste("results/save_DefRate",toString(targets$target.default.rate),
                  "_stdvDc",toString(targets$stdv.delta.c.yoy),
                  "_gamma",toString(Model$gamma),".Rdat",sep="")
    save(THETA.FULL,DATASET,targets,Model,nb.iter,
         file = FILE)
  }else{
    FILE.TEST <- paste("results/save_DefRate",toString(targets$target.default.rate),
                       "_stdvDc",toString(targets$stdv.delta.c.yoy),
                       "_gamma",toString(Model$gamma),
                       "_TEST",
                       ".Rdat",sep="")
    save(THETA.FULL,DATASET,targets,Model,nb.iter,
         file = FILE.TEST)
  }
  
}

stopCluster(cl)

