# =======================================
# DISASTROUS DEFAULTS
# =======================================
# Christian Gouriéroux, Alain Monfort,
# Jean-Paul Renne and Sarah Mouabbi
# Contact: jean-paul.renne@unil.ch
# =======================================
# This version: October 2020
# =======================================
# This script computes the covariance
# matrix of parameter estimates
# =======================================

print("")
print("")
print("==========================================================")
print(" Computing covariance matrix of parameter estimates")
print("==========================================================")


Filter <- rep(1,length(THETA.FULL))
Filter[param.2.exclude.from.optim]  <- 0

theta <- THETA.FULL[Filter==1]

Model.final.solved <- make.Model(theta,
                                 THETA.FULL,
                                 Model,
                                 DATASET,targets,
                                 nb.iter)

# Baseline value of log-likelihood:
logL0 <- loglik.KF(theta,
                   THETA.FULL,
                   Model,
                   DATASET = DATASET,
                   targets = targets,
                   nb.iter = nb.iter,
                   indic.vector = 0)
print(logL0)

print("Computation of time vector of loglik components (ML estimate).")
res.LogL <- loglik.KF(theta,
                      THETA.FULL,
                      Model,
                      DATASET = DATASET,
                      targets = targets,
                      nb.iter = nb.iter,
                      indic.vector = 1)
vec.logl.0 <- res.LogL$vector
sca.logl.0 <- res.LogL$scalar

nb.param <- length(theta)

eps    <- rep(0.001,nb.param)
eps[2] <- .0001 # thinner for contagion parameter

dlogL <- NULL

print(" # ================================" )

print("Computation of time vector of loglik components (perturbated vector of parameters).")

par(mfrow=c(3,4))

for(i in 1:nb.param){
  print(paste("Parameter number ",toString(i)," out of ",toString(nb.param)," parameters",sep=""))
  theta.i.plus  <- theta
  theta.i.minus <- theta
  theta.i.plus[i]  <- theta[i] + eps[i]
  theta.i.minus[i] <- theta[i] - eps[i]
  res.LogL <- loglik.KF(theta.i.plus,
                        THETA.FULL,
                        Model,
                        DATASET = DATASET,
                        targets = targets,
                        nb.iter = nb.iter,
                        indic.vector = 1)
  vec.logl.i.plus <- res.LogL$vector
  sca.logl.i.plus <- res.LogL$scalar
  
  res.LogL <- loglik.KF(theta.i.minus,
                        THETA.FULL,
                        Model,
                        DATASET = DATASET,
                        targets = targets,
                        nb.iter = nb.iter,
                        indic.vector = 1)
  vec.logl.i.minus <- res.LogL$vector
  sca.logl.i.minus <- res.LogL$scalar
  
  dlogL <- cbind(dlogL,
                 (vec.logl.i.plus - vec.logl.i.minus)/(2*eps[i]))
}

print(" # ================================" )



# Detect parameters that have no impact:
length.smpl <- dim(dlogL)[1]
sum.zeros <- apply(dlogL,2,function(x){sum(x==0)})
detect.has.impact <- which(sum.zeros!=length.smpl)


AUX <- dlogL[,detect.has.impact]
M <- NW.LongRunVariance(dlogL[,detect.has.impact],q = q.4.NW)
Mat.var.cov.reduced <- solve(M)
Mat.var.cov <- matrix(0,nb.param,nb.param)
Mat.var.cov[detect.has.impact,detect.has.impact] <- Mat.var.cov.reduced

print(
  cbind(
    (1:length(THETA.FULL))[Filter==1],
    theta,
    sqrt(diag(Mat.var.cov)),
    theta/sqrt(diag(Mat.var.cov))
  )
)

THETA.FULL.save <- THETA.FULL

if(indic.save.CovMat == 1){
  File = "results/save_CovMatrix.Rdat"
  save(Mat.var.cov,
       Mat.var.cov.reduced,
       THETA.FULL.save,
       theta,
       param.2.exclude.from.optim,
       detect.has.impact,
       file = str_c(path,File))
}


AUXX <- function.compute.param.4.stdv.computation(theta,
                                                  THETA.FULL,
                                                  Model,
                                                  DATASET,targets,
                                                  nb.iter=nb.iter)
transf.param <- AUXX$vector.of.param
eps <- rep(0.00001,length(THETA.FULL))
grad.matrix <- grad.function.compute.param.4.stdv.computation(theta,
                                                              THETA.FULL,
                                                              Model,eps,
                                                              DATASET,targets,
                                                              nb.iter=nb.iter)
grad.matrix <- grad.matrix[,detect.has.impact]

mat.cov.matrix.of.transf.param <- grad.matrix %*% Mat.var.cov.reduced %*% t(grad.matrix)
stdv.of.transf.param <- sqrt(diag(mat.cov.matrix.of.transf.param))

print(
  cbind(AUXX$latex.names.of.param,
        round(transf.param,6),
        round(stdv.of.transf.param,6),
        round(transf.param/stdv.of.transf.param,6))
)




