# =======================================
# DISASTROUS DEFAULTS
# =======================================
# Christian Gouriéroux, Alain Monfort,
# Jean-Paul Renne and Sarah Mouabbi
# Contact: jean-paul.renne@unil.ch
# =======================================
# This version: October 2020
# =======================================
# This script calls numerical optimization algorithms
# to maximize the log-likelihood function.
# =======================================


if(indic.contagion == 0){
  # Consider a model without contagion effects
  Filter[2] <- 0
  THETA.FULL[2] <- -10
}

if(indic.macro.effect == 0){
  # Consider a model without macro effect of defaults
  Filter[11] <- 0 # This parameter is then not optimized on
  THETA.FULL[4] <- -30
}

# Potentially remove other parameters:
Filter[param.2.exclude.from.optim] <- 0


if(sum(Filter)>0){
  if(MAXIT.nlminb>0){
    theta.ini <- THETA.FULL[Filter==1]
    
    res.optim <- optimx(theta.ini,
                        loglik.KF,
                        THETA.FULL=THETA.FULL,
                        Model = Model,
                        DATASET = DATASET,
                        targets = targets,
                        nb.iter = nb.iter,
                        method = "nlminb",
                        control=list(trace=1, maxit = MAXIT.nlminb,
                                     kkt = FALSE))
    
    if(sum(is.na(as.matrix(res.optim)[1:length(theta.ini)]))==0){
      if(res.optim$value<current.best){
        theta.ext.est     <- c(as.matrix(res.optim)[1:length(theta.ini)])
        THETA.FULL[Filter==1] <- theta.ext.est
        current.best <- res.optim$value
      }
    }
  }
  
  if(MAXIT.NlMd>0){
    theta.ini <- THETA.FULL[Filter==1]
    
    res.optim <- optim(theta.ini,
                       loglik.KF,
                       THETA.FULL=THETA.FULL,
                       Model = Model,
                       DATASET = DATASET,
                       targets = targets,
                       nb.iter = nb.iter,
                       gr = NULL,
                       method="Nelder-Mead",
                       control=list(trace=TRUE,
                                    maxit=MAXIT.NlMd),
                       hessian=FALSE)
    
    if(res.optim$value<current.best){
      theta.ext.est <- res.optim$par
      THETA.FULL[Filter==1] <- theta.ext.est
      current.best <- res.optim$value
    }
  }
}
