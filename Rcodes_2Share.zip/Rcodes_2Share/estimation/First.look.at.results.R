# =======================================
# DISASTROUS DEFAULTS
# =======================================
# Christian Gouriéroux, Alain Monfort,
# Jean-Paul Renne and Sarah Mouabbi
# Contact: jean-paul.renne@unil.ch
# =======================================
# This version: October 2020
# =======================================
# This script computes a few model outputs
# to check validity of specififed/estimated model.
# =======================================




Filter <- rep(1,length(THETA.FULL))
theta <- THETA.FULL[Filter==1]

result.timing <- system.time({
  logl <- loglik.KF(theta,
                    THETA.FULL,
                    Model,
                    DATASET,
                    targets,
                    nb.iter = nb.iter)
})

Model.solved <- make.Model(theta,
                           THETA.FULL,
                           Model,
                           DATASET,
                           targets,
                           nb.iter = nb.iter)

res.moments <- compute.moments(Model.solved)

print("Validity of model solutions: (Ok if close to zero):")
print(Model.solved$min.fun2min.4.sdf)
print(Model.solved$min.fun2min.4.r_s)

res.KF            <- prepare.state.space(Model.solved,
                                         DATASET,
                                         indic.smooth = 1)

res.proba <- compute.proba.NB.def(Model.solved,res.KF)
print("=================================")
print("Conditional proba. that 0, 1 or 2 defaults on estimation sample:")
print(paste(round(res.proba$P0,3),", ",round(res.proba$P1,3),", ",
            round(res.proba$P2,3),sep=""))


X.complete <- list(
  F   = cbind(matrix(0,dim(res.KF$r_smooth)[1],J),
              res.KF$r_smooth[,1:2]),
  N   = matrix(0,dim(res.KF$r)[1],J),
  N_1 = matrix(0,dim(res.KF$r)[1],J)
)


res.KF$all.prices <- compute.prices.for.given.X(Model.solved,
                                                X.complete,v,
                                                DATASET)$all.prices

delta.c.est <- (X.complete$F) %*% Model.solved$Mu.c$A +
  (X.complete$N) %*% Model.solved$Mu.c$B +
  (X.complete$N_1) %*% Model.solved$Mu.c$C + c(Model.solved$Mu.c$D)

# compute modeled stock returns:
XX   <- res.KF$r_smooth[,1:2]
XX_1 <- res.KF$r_smooth[,4:5]
r.star <- 100*( (XX -XX_1) %*% Model.solved$A.1$A[(J+1):(J+2)] +
                  XX %*% Model.solved$Mu.d$A[(J+1):(J+2)] + Model.solved$Mu.d$D)


par(mfrow=c(3,as.integer(dim(DATASET$observables)[2]/3 +1)))
for(i in 1:dim(DATASET$observables)[2]){
  if(i<dim(DATASET$observables)[2]-2){
    plot(DATASET$observables[,i],pch=19,
         ylim=c(
           min(DATASET$observables[,i],
               res.KF$fitted.obs[,i],
               res.KF$all.prices[,i],
               na.rm = TRUE),
           max(DATASET$observables[,i],
               res.KF$fitted.obs[,i],
               res.KF$all.prices[,i],
               na.rm = TRUE)
         ))
    lines(res.KF$fitted.obs[,i],col="red")
    lines(res.KF$all.prices[,i],col="blue")
  }else{
    plot(DATASET$observables[,i],pch=19,
         ylim=c(
           min(DATASET$observables[,i],
               res.KF$fitted.obs[,i],
               na.rm = TRUE),
           max(DATASET$observables[,i],
               res.KF$fitted.obs[,i],
               na.rm = TRUE)
         ))
    lines(res.KF$fitted.obs[,i],col="red")
    if(i==22){
      lines(delta.c.est,col="blue")
    }
    if(i==24){
      lines(r.star,col="blue")
    }
  }
}


print("=================================")
print("Log-likelihood:")
print(paste(round(res.KF$loglik,2)," (Check: ",toString(round(logl,2)),")",sep=""))

print(paste("Time to compute log-Likelihood: ",toString(round(result.timing[1],2))," seconds",sep=""))
print("=================================")

