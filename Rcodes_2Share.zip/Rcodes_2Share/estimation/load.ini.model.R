# =======================================
# DISASTROUS DEFAULTS
# =======================================
# Christian Gouriéroux, Alain Monfort,
# Jean-Paul Renne and Sarah Mouabbi
# Contact: jean-paul.renne@unil.ch
# =======================================
# This version: October 2020
# =======================================
# This script builds an initial, ad hoc,
# model parameterization.
# =======================================



# Define the number of segments:
J <- 2+1 # The last sector corresponds to small/non-systemic firms

# Grid startfor x and y in EKF:
if((indic.macro.effect==0)&(indic.contagion==1)){
  param.4.grid <- .5
}else{
  param.4.grid <- .3
}

# Define default selection vector of "priced" entities:
v <- c(1,rep(0,J-1))

# Define the number of factors:
nb.addit.n.F <- 2
n.F <- J + nb.addit.n.F

# Declare model object:
Model <- NULL

# Number of systemic entities:
Model$I    <- rep(DATASET$I.iTraxx,J)

# Recovery rate:
Model$RR   <- DATASET$RR

# Model fre quency (number of periods per year):
Model$q    <- DATASET$q



# =============================================================
# Parameterization of Model:


# ==================================
# x and y factors:

select.var.F1 <- .7

# The "counter" factors (w) are the first J factors in F:
# each column of the matrix gives the exposures of one factor.
Model$zeta.0 <- rep(0,J+2)
Model$zeta.F <- matrix(0,n.F,n.F)
rho_1 <- 0.988
rho_2 <- 0.83
mu_1 <- select.var.F1*(1-rho_1)
zeta_11F <- rho_1/mu_1
nu_1 <- (1-rho_1)/mu_1

mu_2 <- .06
zeta_22F <- rho_2/mu_2
zeta_12F <- (1 - rho_2)/mu_2

Model$zeta.F[J+1,J+1] <- zeta_11F
Model$zeta.F[J+2,J+2] <- zeta_22F
Model$zeta.F[J+1,J+2] <- zeta_12F

Model$mu     <- rep(3.110237e+02,n.F)
Model$mu[J+1] <- mu_1
Model$mu[J+2] <- mu_2
Model$nu     <- c(rep(0,J),1.45,.19)
Model$nu[J+1] <- nu_1

Model$beta.matrix <- matrix(0,n.F,J)
Model$beta.matrix[J+2,] <- 0.014 # exposure to F_2

# Mutual and Self-excitation (each column corresponds to the exposure of one sector):
Model$c.matrix    <- matrix(0,J,J) # mutual excitation
Model$c.matrix[1:2,1:2] <- .38 # cross and self-excitation in the two systemic segments
Model$c.matrix[1:2,3] <- .38 # cross-excitation (from systemic to non-systemic segments)

Model$gamma.vec   <- rep(0,J)

Model$zeta.n <- matrix(0,J,n.F) # This is not permanent; this is just to allow for the moment computation.
diag(Model$zeta.n) <- 0.05

moments <- compute.moments(Model)

E.n1 <- moments$unc.mean[J+2+1] # for the systemic entities
E.n2 <- moments$unc.mean[J+2+3] # for the non-systemic entities

rho_Z <- 0

diag(Model$zeta.F[1:J,1:J]) <- rho_Z/Model$mu[1:J]

Model$zeta.n <- matrix(0,J,n.F)
diag(Model$zeta.n[1:J,1:J]) <- (1-rho_Z)/Model$mu[1:J]/c(E.n1,E.n1,E.n2)

# Compute model-implied moments:
res.mom <- compute.moments(Model)


# ==================================
# Consumption process:

Model$stdv.delta.c.yoy <- .03
Model$sigma.c <- .005

mu.c <- .015/Model$q

Mu.c = list(A= matrix(c(rep(-0.00005,J-1),0,c(-.00005,0)),ncol=1),
            B= matrix(-0/100,nrow=J,ncol=1),
            C= matrix(0/100,nrow=J,ncol=1),
            D= 0)

V <- res.mom$unc.var
PHI <- res.mom$PHI
Var.X.q <- Model$q * V
for(j in 1:(Model$q-1)){
  Var.X.q <- Var.X.q + 2 * (Model$q-j) * (PHI%^%j %*% V + V %*% t(PHI%^%j))
}

var.delta.c.one.year.no.sigmac.before.adjust <-
  t(Mu.c$A) %*% Var.X.q[1:n.F,1:n.F] %*% Mu.c$A

targetted.variance.Mu.c <- (Model$stdv.delta.c.yoy)^2 - Model$q*(Model$sigma.c)^2

adjustment.stdv.factor <- c(sqrt(targetted.variance.Mu.c / var.delta.c.one.year.no.sigmac.before.adjust))

Mu.c$A <- Mu.c$A * adjustment.stdv.factor
Mu.c$B <- Mu.c$B * adjustment.stdv.factor
Mu.c$C <- - Mu.c$B
Mu.c$D <- targets$mu.c.annual/Model$q - sum(
  c(Mu.c$A,Mu.c$B) * res.mom$unc.mean
)
Model$Mu.c  <- Mu.c



# ==================================
# Dividend process:

mult.fact <- 3
Model$Mu.d  <- list(
  A = mult.fact*Model$Mu.c$A,
  B = mult.fact*Model$Mu.c$B,
  C = mult.fact*Model$Mu.c$C,
  D = Model$Mu.c$D
)


# ==================================
# Agents preferences:

gamma <- 3 # as in Wachter (2013)

delta <- (1 - .012)^(1/Model$q) # consistent with Wachter (2013) (1.2% py)
z.bar <- 5.3

Model$gamma <- gamma
Model$delta <- delta
Model$z.bar <- z.bar



# ==================================
# Check model solution:

nb.iter <- 60
Model <- run.solve.model(Model,nb.iter)


# ===============================================
# This model is used to initilize calibration:
Model.ini <- Model
# ===============================================


