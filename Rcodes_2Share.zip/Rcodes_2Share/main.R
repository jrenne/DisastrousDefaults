# =======================================
# DISASTROUS DEFAULTS
# =======================================
# Christian Gouriéroux, Alain Monfort,
# Jean-Paul Renne and Sarah Mouabbi
# Contact: jean-paul.renne@unil.ch
# =======================================
# This version: October 2020
# =======================================


# Clear environment and console
rm(list = ls(all = TRUE)) # clear environment 
cat("\014") # clear console

# ============================================================
# Set working directory:
path <- '~/Dropbox/ITRAXX/Rcodes/'
setwd(path)
# ============================================================

# Indicate whether Kalman-filter estimation is run:
indic.estim.KF <- 0

# Indicate whether contagion is allowed:
indic.contagion <- 1

# Indicate whether macro effect of defaults is allowed (mu_{c,w}):
indic.macro.effect <- 1

# Covariance matrix of parameter estimates:
indic.compute.CovMat <- 0
indic.save.CovMat    <- 0

# Indicate whether parallel estimations (other values of average default frequency
#    and uncond variance of consumption growth)
indic.parallel      <- 0
indic.test.parallel <- 0 # set to 1 if want to check that estimation works (very small number of iterations in optim algo)
number.of.cores     <- 6 # if parallel estimations, number of cores employed (= simultaneous estimations)

# Indicate whether price figures are generated:
indic.produce.outputs <- 0

# Define 27 alternative specifications:
vec.of.target.default.rate <- c(.002,.003,.004)
vec.of.stdv.delta.c.yoy    <- c(.02,.03,.05)
vec.of.gamma               <- c(3,5,7)

# Maximum absolute value of parameters:
Max.abs.value.param <- 16

# set seed of random number generator (for exact replication of Monte-Carlo ex.):
set.seed(123)


# Load libraries:
library(stringr)
library(optimx)
library(MASS)
library(mFilter)
library(expm)
library(doParallel)

# Load procedures:
source(str_c(path,'procedures/proc_ARG.R'))
source(str_c(path,'procedures/proc_credderiv.R'))
source(str_c(path,'procedures/proc_macromodel.R'))
source(str_c(path,'procedures/proc_data.R'))
source(str_c(path,'procedures/proc_outputs.R'))
source(str_c(path,'procedures/proc_statespace.R'))
source(str_c(path,'procedures/proc_kalman.R'))

# Saved results:
results.estim.KF <-
  "results/save_DefRate0.003_stdvDc0.03_gamma5.Rdat" # baseline results
results.estim.KF.noContag <-
  "results/save_KF_noContag.Rdat" # results with no contagion
results.estim.KF.noMacroEffect <-
  "results/save_KF_noMacroEffect.Rdat" # results with no macro effect
results.estim.KF.noContag.noMacroEffect <-
  "results/save_KF_noContag_noMacroEffect.Rdat" # results with no contagion and no macro effect

# Location of the covariance matrix of parameter estimates
#       (for thre baseline model only):
results.covariance.matrix <- "results/save_CovMatrix.Rdat" # load Mat.var.cov

# Load data:
source(str_c(path,'data/load.data.R'), echo=FALSE)

# Load initial model (defines the structure of the model):
source(str_c(path,'estimation/load.ini.model.R'), echo=FALSE)

# Load model depending on the specification (indic.contagion and indic.macro.effect):
if((indic.contagion == 0)&(indic.macro.effect == 1)){# No contagion
  load(file = results.estim.KF.noContag)
}else if((indic.contagion == 1)&(indic.macro.effect == 0)){ # No macro effect
  load(file = results.estim.KF.noMacroEffect)
}else if((indic.contagion == 0)&(indic.macro.effect == 0)){ # No contagion and no macro effect
  load(file = results.estim.KF.noContag.noMacroEffect)
}else{ # Baseline case
  load(file = results.estim.KF)
}

# Estimation (one model only):
param.2.exclude.from.optim <- c(4,6) # Parameters that will not be optimzed on
nb.iter.KF <- 10 # number of iterations in the estimation loop
if(indic.estim.KF==1){
  source(str_c(path,'estimation/Estim_KF.R'), echo=FALSE)
}
if(indic.compute.CovMat == 1){
  q.4.NW <- Model$q # for Newey-West formula
  source(str_c(path,'estimation/Compute_CovMat.R'), echo=FALSE)
}else{
  load(results.covariance.matrix)
}

# Run parallel estimations:
if(indic.parallel){
  source(str_c(path,'estimation/Estim_KF_parallel.R'))
}

# Check model implications:
source('estimation/First.look.at.results.R', echo=FALSE)


# Generate outputs:
suffix <- "noContag"
suffix <- "" # put a suffix not to overwrite existing figures
if(indic.produce.outputs==1){
  
  # Build Models I, II, III and IV
  #  (with and without contagion and macro-effect channels, with or without re-estimation)
  # source("outputs/load.alternative.estimated.models.R")
  # source("outputs/load.alternative.modified.models.R")
  
  # Tables:
  source('outputs/make.table.params.R', echo=FALSE) # effect of different types of exposures
  source('outputs/make.table.counterfactuals.R', echo=FALSE) # effect of different types of exposures
  
  # Figures:
  source('outputs/make.figure.prices.R', echo=FALSE) # fit of prices
  
  source('outputs/make.figure.conso.stocks.R', echo=FALSE) # fit of cons. growth and stopck returns
  
  source('outputs/make.figure.IRF.R', echo=FALSE) # fit of prices
  source('outputs/make.figure.IRF.AlternativeModels.R', echo=TRUE)
  
  # =============================
  # Settings for Monte-Carlo simulations:
  #  (used for make.figure.factors.R and make.figure.indicators.R):
  # Confidence band = Number of std dev:
  mult.fact.stdv <- 1.64
  # Number of paths:
  nb.replications <- 500
  # Log-Lik. threshold:
  Threshold.logL <- 500
  # Settings for indicators:
  # First chart: proba of default of X iTraxx constituents:
  Maturity.4.indicator.1stChart <- c(1,2)
  nb.def.iTraxx.constitu <- 10
  # Second chart: large decreases of consumption
  Maturity.4.indicator.2ndChart <- c(1) # in years
  vector.of.decrease.in.conso <- c(-.10,-.20)
  # =============================
  source('outputs/run.MonteCarlo.models.R', echo=FALSE)
  # =============================
  
  source('outputs/make.figure.factors.R', echo=FALSE) # x and yfactors
  
  source('outputs/make.figure.indicators.R', echo=FALSE) # disasters probabilities
  source('outputs/make.figure.indicators.27.R', echo=FALSE) # disasters probabilities

  source('outputs/make.figure.contourplot.R', echo=FALSE) # effect of different types of exposures
  source('outputs/make.figure.distri.conso.R', echo=FALSE) # Unconditional distribution of consumption
  
}


